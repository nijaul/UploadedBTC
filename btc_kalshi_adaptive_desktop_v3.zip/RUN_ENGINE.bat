@echo off
cd /d "%~dp0"
py engine.py
if errorlevel 1 pause
