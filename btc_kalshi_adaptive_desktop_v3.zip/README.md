# BTC + Kalshi BTC 15-Minute Adaptive Desktop Engine

This Windows desktop build uses Kalshi's public API as the authoritative Kalshi source. Optional desktop OCR is included as a diagnostic/capture layer and never replaces Kalshi API data.

## Live market inputs

The program keeps **Coinbase BTC-USD** and **Kalshi BTC 15-minute prediction markets** as independent live data sources.

### Main graph
- **Blue line:** Coinbase BTC/USD live price.
- **Green line:** BRTI BTC/USD from optional desktop OCR.
- **Orange line:** Kalshi YES 15-minute contract price/probability.
- **Yellow dashed horizontal line:** **BASE BTC PRICE** for the active 15-minute contract.
- Coinbase and BRTI use the left BTC/USD axis; Kalshi uses the right cents/probability axis.
- OCR never replaces or overrides Coinbase/Kalshi API data.

The two lines are intentionally not forced onto the same numeric scale.

## Automatic Kalshi ticker discovery

No ticker is entered manually.

At startup and on rollover the program queries the public Kalshi markets endpoint, selects an active Bitcoin 15-minute market based on market metadata/timing, and switches to the next contract automatically.

The active contract's open/close timestamps drive the round lifecycle and time-remaining display.

## Kalshi data collected

For the active contract the collector attempts to obtain and continuously refresh:

- market title/subtitle
- series ticker and event ticker
- open/close/expiration time
- status/result/settlement fields when present
- YES and NO bid/ask
- last/YES price
- total volume and 24h volume when exposed
- open interest
- liquidity when exposed
- order-book levels on YES and NO
- total visible YES/NO depth
- order-book depth imbalance
- recent public trades
- trade count/size
- buy/sell trade-flow totals when side information is available
- trade-flow imbalance
- last trade timestamp
- raw market/order-book/event/series JSON for audit/forward compatibility

A secondary microstructure graph shows live order-book depth imbalance and trade-flow imbalance.

## Multi-factor signal and persistent learning

The engine stores its observations under `data/` and keeps the raw/derived Kalshi data locally:

- `market_engine_ticks.csv` — combined Coinbase/Kalshi time series
- `kalshi_market_snapshots.csv` — market metadata and raw JSON
- `kalshi_trades.csv` — newly observed public trades
- `kalshi_orderbook_snapshots.csv` — book levels/depth and raw JSON
- `quarter_history.csv` — completed-contract outcomes
- `session_rounds.csv` — per-round model state and Kalshi features
- `sessions.csv` — session performance
- `adaptive_predictions.csv` — completed examples used for the learner
- `adaptive_model.json` — persistent online-model weights/state

The live BUY UP / BUY DOWN engine does not use a simple $1 threshold. It evaluates direction over time and requires persistent evidence.

The live signal uses:
- Coinbase multi-horizon momentum/returns, volatility, and trend slope
- Kalshi YES/NO probability, bid/ask and spread
- Kalshi price momentum at multiple horizons
- order-book depth imbalance at 1/3/5/10 levels and top-of-book size
- recent trade count, trade rate, buy/sell flow and flow imbalance
- volume, 24h volume, open interest and liquidity
- time remaining in the actual Kalshi contract
- recent resolved markets in the same series
- Coinbase/Kalshi agreement
- optional BRTI-to-Coinbase divergence as a secondary confirmation only

Before a BUY signal, the direction must persist across multiple live updates, have sufficient model/Kalshi edge and confidence, and avoid a recent reversal. Otherwise the engine deliberately displays `NO EDGE / WAIT`.

The adaptive learner updates only after completed 15-minute contracts. It stores a 51-feature vector and trains from representative opening/mid/late snapshots from the completed contract, so it learns from how the market behaved rather than a single opening tick. The persistent learner changes feature weights based on actual outcomes.

Raw Kalshi market, series, event, order-book and trade payloads are also kept for research/forward compatibility. The signal does not wait for learning data before using the live features; the hand-tuned multi-factor signal is active immediately, and the learned component is blended in after the configured minimum sample count.

## Base price

By default the engine captures a Coinbase BTC price near the **Kalshi contract open time** and uses it as the active contract's base price.

That base is drawn as a horizontal line across the main graph.

A manual base can still be entered for research/testing. Press **Auto Base** to return control to automatic contract-open base capture.

## Windows

Run:

`RUN_ENGINE.bat`

The desktop program uses only public market-data endpoints and does not place trades.

## API note

The code is written to tolerate common Kalshi v2 response field names and saves raw payloads so the data can be inspected when schemas change. This package was produced without live web verification in the build environment, so Kalshi's current public endpoint availability/rate limits should be validated when deployed.


## Optional BRTI OCR capture

BRTI OCR can run simultaneously with the Kalshi API and Coinbase feed. It is a **third, independent live BTC/USD reference feed**.

- **Select BRTI Region** lets you drag-select the BRTI price on your desktop.
- **Start / Stop OCR** enables or disables continuous BRTI capture.
- **Capture OCR Now** performs one manual capture.
- The **green BRTI OCR line** is drawn live on the BTC/USD axis.
- The API/coinbase feeds remain authoritative for the model and adaptive learning.
- OCR observations are stored separately in `data/ocr_captures.csv` for comparison/audit.
- The selected OCR screen region is saved back to `config.json`.
- `mss`, `pytesseract`, and `Pillow` are used only for the optional OCR layer.

Configure the capture rectangle under the `ocr.region` object:

```json
"ocr": {
  "enabled": false,
  "interval_seconds": 1.0,
  "region": {
    "left": 0,
    "top": 0,
    "width": 400,
    "height": 120
  }
}
```

Set `enabled` to `true` to have OCR begin automatically at launch, or leave it false and use the desktop buttons when desired.


## Signal behavior

The engine is designed to avoid reacting to a single $1 or single-tick movement. A transient move can therefore result in `NO EDGE / WAIT` while the system collects more confirmation. `BUY UP` or `BUY DOWN` appears only when the directional score, model probability, Kalshi edge, persistence, and confirmation checks agree.

The live Kalshi feed is the central prediction-market input. Coinbase remains the underlying BTC/USD market input. BRTI OCR is a third independent BTC/USD reference line and is optional.
