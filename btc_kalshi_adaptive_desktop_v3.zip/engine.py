import csv
import json
import math
import time
import tkinter as tk
from collections import deque
from pathlib import Path

import customtkinter as ctk

from market_data import CoinbaseFeed, KalshiBTC15Feed, BRTIOCRCapture

BASE = Path(__file__).resolve().parent
CFG = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
DATA = BASE.parent / "data"
DATA.mkdir(exist_ok=True)

HIST = DATA / "quarter_history.csv"
SESSION_CSV = DATA / "sessions.csv"
SESSION_ROUNDS_CSV = DATA / "session_rounds.csv"
MARKET_TICKS_CSV = DATA / "market_engine_ticks.csv"
KALSHI_SNAPSHOTS_CSV = DATA / "kalshi_market_snapshots.csv"
KALSHI_TRADES_CSV = DATA / "kalshi_trades.csv"
KALSHI_BOOK_CSV = DATA / "kalshi_orderbook_snapshots.csv"
ADAPTIVE_STATE = DATA / "adaptive_model.json"
ADAPTIVE_PREDICTIONS = DATA / "adaptive_predictions.csv"
OCR_CAPTURES_CSV = DATA / "ocr_captures.csv"
OCR_FIELDS = [
    "timestamp", "kalshi_ticker", "api_yes", "ocr_value",
    "difference_cents", "ocr_text", "ocr_status", "notes",
]

MIN_GRADED_FOR_CALIB = int(CFG.get("min_graded_for_calibration", 20))
CALIB_CAP = float(CFG.get("calibration_cap", 1.5))
MIN_EDGE = float(CFG.get("min_edge_probability", 0.04))
MIN_SIGNAL_SCORE = float(CFG.get("min_signal_score", 0.16))
MIN_PERSISTENCE = int(CFG.get("min_persistence_updates", 3))
MIN_CONFIDENCE = float(CFG.get("min_signal_confidence", 0.62))
ADAPTIVE_CFG = CFG.get("adaptive_model", {})

HIST_FIELDS = [
    "quarter_start_iso", "base", "price_open", "proj_open", "score_open",
    "direction_open", "price_close", "direction_actual", "correct",
]
SESSION_FIELDS = [
    "session_id", "session_start", "session_end", "quarters",
    "correct", "incorrect", "hit_rate",
]
ROUND_FIELDS = [
    "session_id", "quarter_start_iso", "quarter_end_iso", "base_price",
    "price_open", "price_close", "forecast_open", "momentum_score",
    "model_prob_up", "up_price", "down_price", "signal", "direction_called",
    "direction_actual", "correct", "edge_up", "edge_down", "confidence",
    "kalshi_ticker", "kalshi_yes", "kalshi_bid", "kalshi_ask",
    "kalshi_depth_imbalance", "kalshi_trade_imbalance", "kalshi_volume",
    "kalshi_open_interest", "seconds_left",
]
TICK_FIELDS = [
    "timestamp", "coinbase_price", "kalshi_ticker", "kalshi_yes",
    "kalshi_bid", "kalshi_ask", "kalshi_no_bid", "kalshi_no_ask",
    "kalshi_last_price", "kalshi_spread", "kalshi_volume", "kalshi_volume_24h",
    "kalshi_open_interest", "kalshi_liquidity",
    "kalshi_depth_yes", "kalshi_depth_no", "depth_imbalance",
    "depth_imbalance_1", "depth_imbalance_3", "depth_imbalance_5", "depth_imbalance_10",
    "trade_buy_volume", "trade_sell_volume", "trade_imbalance",
    "trade_imbalance_15s", "trade_imbalance_60s", "trade_rate_60s", "trade_volume_60s",
    "seconds_left", "series_up_rate", "series_history_count",
]
SNAPSHOT_FIELDS = [
    "timestamp", "ticker", "event_ticker", "series_ticker", "title",
    "subtitle", "status", "open_time", "close_time", "expiration_time",
    "result", "settlement_value", "volume", "volume_24h", "open_interest",
    "liquidity", "yes_bid", "yes_ask", "no_bid", "no_ask",
    "raw_market_json", "raw_event_json", "raw_series_json",
]
TRADE_FIELDS = [
    "captured_at", "ticker", "trade_id", "trade_timestamp",
    "yes_price", "size", "side", "raw_json",
]
BOOK_FIELDS = [
    "captured_at", "ticker", "yes_levels", "no_levels",
    "yes_depth_total", "no_depth_total", "depth_imbalance", "raw_json",
]
ADAPTIVE_FIELDS = [
    "timestamp", "ticker", "prediction", "actual", "correct",
    "feature_names", "features_json", "learner_error",
]


def append_dict(path, fields, row):
    new = not path.exists() or path.stat().st_size == 0
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        if new:
            writer.writeheader()
        writer.writerow(row)


def load_csv(path, n=None):
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    return rows[-n:] if n else rows


def safe_float(v, default=None):
    try:
        return float(v)
    except Exception:
        return default


def hist_append(row):
    append_dict(HIST, HIST_FIELDS, row)


def hist_load(n=500):
    return load_csv(HIST, n)


def append_session_round(row):
    append_dict(SESSION_ROUNDS_CSV, ROUND_FIELDS, row)


def save_session(start, total, correct, incorrect, session_id):
    append_dict(SESSION_CSV, SESSION_FIELDS, {
        "session_id": session_id,
        "session_start": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start)),
        "session_end": time.strftime("%Y-%m-%d %H:%M:%S"),
        "quarters": total,
        "correct": correct,
        "incorrect": incorrect,
        "hit_rate": (correct / total if total else ""),
    })


class AdaptiveLearner:
    """Persistent online logistic model over the full bounded feature vector."""
    DEFAULT_WEIGHTS = None

    def __init__(self):
        self.enabled = bool(ADAPTIVE_CFG.get("enabled", True))
        self.lr = float(ADAPTIVE_CFG.get("learning_rate", 0.035))
        self.l2 = float(ADAPTIVE_CFG.get("l2", 0.001))
        self.blend = float(ADAPTIVE_CFG.get("blend", 0.30))
        self.min_examples = int(ADAPTIVE_CFG.get("min_examples", 20))
        self.clip = float(ADAPTIVE_CFG.get("weight_clip", 3.5))
        self.feature_names = [
            "bias","coin_score","coin_ret_1s","coin_ret_5s","coin_ret_15s","coin_ret_30s",
            "coin_ret_60s","coin_ret_300s","coin_ret_900s","coin_vol","coin_slope",
            "kalshi_prob","kalshi_yes_bid","kalshi_yes_ask","kalshi_no_bid","kalshi_no_ask",
            "kalshi_last_price","kalshi_ret_5s","kalshi_ret_15s","kalshi_ret_30s","kalshi_ret_60s",
            "kalshi_ret_300s","kalshi_spread","yes_depth_total","no_depth_total",
            "best_bid_size","best_ask_size","depth_1","depth_3","depth_5","depth_10","top_depth",
            "trade_count_15s","trade_imb_15s","trade_imb_60s","trade_rate_60s","trade_volume_60s",
            "volume_level","volume_24h_level","volume_vs_history","oi_level","oi_vs_history",
            "liquidity_level","time_remaining","series_up_rate","series_abs_move",
            "series_history_count","brti_divergence","coin_kalshi_agreement",
            "flow_depth_agreement","reversal_penalty",
        ]
        self.weights = [0.0] + [0.0] * (len(self.feature_names)-1)
        self.n = 0
        self.loss_ema = None
        self.accuracy = None
        self._load()
        if not any(abs(w) > 1e-9 for w in self.weights[1:]):
            self.weights = [0.0] * len(self.feature_names)
            # Conservative starting priors; training can move all of these.
            pri = {
                "coin_score": 0.45, "coin_ret_60s": 0.35, "coin_slope": 0.20,
                "kalshi_prob": 0.55, "kalshi_ret_15s": 0.30, "kalshi_ret_60s": 0.40,
                "kalshi_spread": -0.10, "depth_5": 0.30, "trade_imb_60s": 0.45,
                "trade_rate_60s": 0.05, "volume_level": 0.05, "time_remaining": 0.10,
                "series_up_rate": 0.08, "brti_divergence": -0.10,
                "coin_kalshi_agreement": 0.25, "flow_depth_agreement": 0.15,
                "reversal_penalty": -0.35,
            }
            for n,v in pri.items():
                self.weights[self.feature_names.index(n)] = v

    @staticmethod
    def _sigmoid(z):
        z = max(-20.0, min(20.0, z))
        return 1.0 / (1.0 + math.exp(-z))

    @staticmethod
    def _clip(v, lo=-1.0, hi=1.0):
        try:
            return max(lo, min(hi, float(v)))
        except Exception:
            return 0.0

    def make_features(self, coin_score, x, k, brti_price=None):
        p = safe_float(k.get("price"), 0.5) or 0.5
        coin_ret = x.get("ret", {})
        # Convert percent returns to bounded directional features.
        def ret(name, scale):
            return self._clip((safe_float(coin_ret.get(name), 0.0) or 0.0) / scale)

        def kr(key, scale):
            return self._clip((safe_float(k.get(key), 0.0) or 0.0) / scale)

        spread = safe_float(k.get("spread"), 0.0) or 0.0
        vol = safe_float(x.get("vol"), 0.0) or 0.0
        slope = safe_float(x.get("slope"), 0.0) or 0.0
        seconds = safe_float(k.get("seconds_left"))
        time_remaining = self._clip((seconds / 900.0) if seconds is not None else 1.0)

        vh = safe_float(k.get("series_history_avg_volume"))
        oh = safe_float(k.get("series_history_avg_oi"))
        lh = safe_float(k.get("series_history_avg_liquidity"))
        volume = safe_float(k.get("volume"), 0.0) or 0.0
        oi = safe_float(k.get("open_interest"), 0.0) or 0.0
        liq = safe_float(k.get("liquidity"), 0.0) or 0.0
        volume_level = self._clip(volume / 20000.0, 0, 1)
        volume_vs_history = self._clip((volume / max(vh,1.0) - 1.0) / 3.0 if vh else 0.0)
        oi_vs_history = self._clip((oi / max(oh,1.0) - 1.0) / 3.0 if oh else 0.0)
        liquidity_level = self._clip(liq / 20000.0, 0, 1)

        series_up = safe_float(k.get("series_history_up_rate"))
        series_abs = safe_float(k.get("series_history_avg_abs_move"), 0.0) or 0.0
        brti_div = 0.0
        if brti_price is not None and x.get("price"):
            brti_div = self._clip((float(brti_price)/float(x["price"]) - 1.0) / 0.0025)
        coin_dir = self._clip(coin_score)
        kal_dir = self._clip((p - 0.5) * 2.0)
        kal_mom = self._clip(
            0.35*kr("kalshi_ret_5s", 0.015) +
            0.30*kr("kalshi_ret_15s", 0.025) +
            0.20*kr("kalshi_ret_30s", 0.04) +
            0.15*kr("kalshi_ret_60s", 0.06)
        )
        flow = self._clip(k.get("trade_imbalance_60s", k.get("trade_imbalance", 0.0)))
        depth = self._clip(k.get("depth_imbalance_5", k.get("depth_imbalance", 0.0)))
        v24 = safe_float(k.get("volume_24h"), 0.0) or 0.0
        trade_count_15 = safe_float(k.get("trade_count_15s"), 0.0) or 0.0
        trade_vol_60 = (safe_float(k.get("trade_buy_60s"),0.0) or 0.0) + (safe_float(k.get("trade_sell_60s"),0.0) or 0.0)
        feature = [
            1.0,
            coin_dir,
            ret(1000, 0.015), ret(5000, 0.03), ret(15000, 0.05), ret(30000, 0.07),
            ret(60000, 0.12), ret(300000, 0.25), ret(900000, 0.50),
            self._clip(vol / 0.50, 0, 1), self._clip(slope / 0.005),
            kal_dir,
            self._clip((safe_float(k.get("yes_bid"),p)-0.5)*2.0),
            self._clip((safe_float(k.get("yes_ask"),p)-0.5)*2.0),
            self._clip((safe_float(k.get("no_bid"),1-p)-0.5)*2.0),
            self._clip((safe_float(k.get("no_ask"),1-p)-0.5)*2.0),
            self._clip(((safe_float(k.get("last_price"),p) or p)-0.5)*2.0),
            kr("kalshi_ret_5s", 0.015), kr("kalshi_ret_15s", 0.025),
            kr("kalshi_ret_30s", 0.04), kr("kalshi_ret_60s", 0.06), kr("kalshi_ret_300s", 0.10),
            self._clip(spread / 0.08, 0, 1),
            self._clip((safe_float(k.get("depth_yes_total"),0.0) or 0.0)/20000.0, 0, 1),
            self._clip((safe_float(k.get("depth_no_total"),0.0) or 0.0)/20000.0, 0, 1),
            self._clip((safe_float(k.get("best_bid_size"),0.0) or 0.0)/2000.0, 0, 1),
            self._clip((safe_float(k.get("best_ask_size"),0.0) or 0.0)/2000.0, 0, 1),
            self._clip(k.get("depth_imbalance_1", depth)),
            self._clip(k.get("depth_imbalance_3", depth)),
            self._clip(k.get("depth_imbalance_5", depth)),
            self._clip(k.get("depth_imbalance_10", depth)),
            self._clip(k.get("top_depth_imbalance", depth)),
            self._clip(trade_count_15/100.0, 0, 1),
            self._clip(k.get("trade_imbalance_15s", flow)),
            flow,
            self._clip((safe_float(k.get("trade_rate_60s"),0.0) or 0.0)/100.0, 0, 1),
            self._clip(trade_vol_60/10000.0, 0, 1),
            volume_level,
            self._clip(v24/50000.0, 0, 1),
            volume_vs_history,
            self._clip(oi/20000.0, 0, 1),
            oi_vs_history,
            liquidity_level,
            time_remaining,
            self._clip((series_up or 0.5)*2.0 - 1.0),
            self._clip(series_abs/0.25, 0, 1),
            self._clip((safe_float(k.get("series_history_count"),0.0) or 0.0)/200.0, 0, 1),
            brti_div,
            self._clip(coin_dir*kal_dir),
            self._clip(flow*depth),
            0.0,
        ]
        return feature

    def predict(self, features):
        if not self.enabled:
            return 0.5
        z = sum(w*x for w,x in zip(self.weights, features))
        return self._sigmoid(z)

    def update(self, features, y, ticker=""):
        if not self.enabled:
            return None, None
        p = self.predict(features)
        error = float(y) - p
        for i,x in enumerate(features):
            self.weights[i] += self.lr * (error*x - self.l2*self.weights[i])
            self.weights[i] = max(-self.clip, min(self.clip, self.weights[i]))
        self.n += 1
        loss = -(y*math.log(max(p,1e-6)) + (1-y)*math.log(max(1-p,1e-6)))
        self.loss_ema = loss if self.loss_ema is None else 0.95*self.loss_ema + 0.05*loss
        # Running accuracy is based on predictions made immediately before updates.
        acc = 1.0 if (p >= 0.5) == (y >= 0.5) else 0.0
        self.accuracy = acc if self.accuracy is None else 0.98*self.accuracy + 0.02*acc
        self._save()
        return p, error

    def _save(self):
        ADAPTIVE_STATE.write_text(json.dumps({
            "weights": self.weights, "feature_names": self.feature_names,
            "n": self.n, "loss_ema": self.loss_ema, "accuracy": self.accuracy,
        }, indent=2), encoding="utf-8")

    def _load(self):
        try:
            obj = json.loads(ADAPTIVE_STATE.read_text(encoding="utf-8"))
            names = obj.get("feature_names")
            weights = obj.get("weights")
            if isinstance(names, list) and isinstance(weights, list):
                old = dict(zip(names, weights))
                self.weights = [float(old.get(name, 0.0)) for name in self.feature_names]
            elif isinstance(weights, list):
                # Compatibility with the prior 7-feature model.
                for i,v in enumerate(weights[:min(7,len(self.weights))]):
                    self.weights[i] = float(v)
            self.n = int(obj.get("n", 0))
            self.loss_ema = safe_float(obj.get("loss_ema"))
            self.accuracy = safe_float(obj.get("accuracy"))
        except Exception:
            pass

    def label(self):
        if not self.enabled:
            return "OFF"
        if self.n < self.min_examples:
            return f"LEARNING {self.n}/{self.min_examples}"
        return f"ADAPTIVE {self.n} samples • blend {self.blend:.0%} • acc {(self.accuracy or 0)*100:.1f}%"


COINBASE = CoinbaseFeed(CFG.get("exchange_product", "BTC-USD"))
KALSHI_CFG = CFG.get("kalshi", {})
KALSHI = KalshiBTC15Feed(
    poll_seconds=KALSHI_CFG.get("poll_seconds", 1.0),
    base_urls=KALSHI_CFG.get("api_base_urls"),
    depth_levels=KALSHI_CFG.get("depth_levels", 10),
    trade_limit=KALSHI_CFG.get("trade_limit", 100),
)
LEARNER = AdaptiveLearner()
OCR_CFG = CFG.get("ocr", {})
# Optional BRTI OCR reference feed. It does not drive the model.
BRTI_OCR = BRTIOCRCapture(
    region=OCR_CFG.get("region", {}),
    interval_seconds=OCR_CFG.get("interval_seconds", 1.0),
    min_price=OCR_CFG.get("min_price", 1000.0),
    max_price=OCR_CFG.get("max_price", 1000000.0),
    max_jump_pct=OCR_CFG.get("max_jump_pct", 2.0),
)
OCR_REGION_DESC = OCR_CFG.get("region", {})


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("BTC + Kalshi 15-Minute Adaptive Engine")
        self.geometry("1180x980")
        self.minsize(980, 720)
        self.protocol("WM_DELETE_WINDOW", self.quit)

        self.bind("<F9>", lambda e: self.pause())
        self.bind("<F10>", lambda e: self.quit())
        self.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind_all("<Button-4>", lambda e: self._scroll(-3), add="+")
        self.bind_all("<Button-5>", lambda e: self._scroll(3), add="+")

        self.base = None
        self.base_ts = None
        self.manual_base = False
        self.q_start = None
        self.q_open = None
        self.graph_points = deque(maxlen=1200)
        self.kalshi_points = deque(maxlen=1200)
        self.depth_points = deque(maxlen=500)
        self.flow_points = deque(maxlen=500)
        self.signal_points = deque(maxlen=20)
        self.signal_dir_points = deque(maxlen=20)
        self._last_signal_source_ts = None
        self.contract_learning_samples = deque(maxlen=600)

        self.session_start = time.time()
        self.session_id = time.strftime("%Y%m%d_%H%M%S", time.localtime(self.session_start))
        self.session_total = self.session_correct = self.session_incorrect = 0
        self.calib = 1.0
        self.hitrate = None
        self.hitn = 0
        self.paused = False
        self.last_log_ts = 0.0
        self.last_round_ticker = None
        self.last_round_close = None
        self._last_saved_ocr_ts = None

        # Dashboard variables
        vars_init = {
            "p": "—", "d": "WAITING", "prob": "—", "clock": "—",
            "baselbl": "auto base at each 15m boundary", "baseval": "—",
            "projp": "—", "vsbase": "—", "hitlbl": "no graded quarters yet",
            "calibvar": "×1.00 (inactive)", "lastq": "—", "yesvar": "—",
            "bidaskvar": "—", "tickervar": "searching…",
            "kstatusvar": "KALSHI: searching", "signal": "WAITING FOR DATA",
            "edgevar": "—", "coin_scorev": "—", "kalshi_scorev": "—",
            "mix_scorev": "—", "coin_status": "COINBASE: —",
            "sessionlbl": "0 / 0 correct", "alltimelbl": "0 / 0 correct",
            "confvar": "—", "depthvar": "—", "flowvar": "—",
            "volvar": "—", "oitvar": "—", "adaptivevar": LEARNER.label(),
            "bookvar": "—", "lasttradevar": "—", "datahealth": "WAITING",
            "ocr_status": "OCR OFF", "ocr_value": "—", "ocr_diff": "—", "ocr_text": "—",
        }
        for name, value in vars_init.items():
            setattr(self, name, ctk.StringVar(value=value))

        COINBASE.start()
        KALSHI.start()
        if OCR_CFG.get("enabled", False):
            BRTI_OCR.start()

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=4, pady=4)
        self._content = self.scroll
        self.make()
        self.recompute_calibration()
        self.update_all_time()
        self.after(250, self.refresh)

    def make(self):
        ctk.CTkLabel(
            self._content, text="₿ BTC + KALSHI 15-MINUTE ADAPTIVE ENGINE",
            font=("Arial", 25, "bold")
        ).pack(pady=(16, 3))
        ctk.CTkLabel(
            self._content,
            text="Coinbase BTC/USD + Kalshi BTC 15-minute API + optional BRTI OCR reference feed",
            text_color="#8b98a9",
        ).pack()

        ctk.CTkLabel(self._content, textvariable=self.p, font=("Arial", 42, "bold")).pack(pady=8)

        # Contract / timing strip
        top = ctk.CTkFrame(self._content); top.pack(fill="x", padx=18, pady=4)
        for title, var in [
            ("KALSHI TICKER", self.tickervar), ("TIME LEFT", self.clock),
            ("KALSHI STATUS", self.kstatusvar),
        ]:
            box = ctk.CTkFrame(top); box.pack(side="left", fill="both", expand=True, padx=4)
            ctk.CTkLabel(box, text=title, text_color="#8b98a9").pack(pady=(6, 0))
            ctk.CTkLabel(box, textvariable=var, font=("Arial", 15, "bold")).pack(pady=5)

        # Base
        bf = ctk.CTkFrame(self._content); bf.pack(fill="x", padx=18, pady=4)
        ctk.CTkLabel(bf, text="Base BTC price:").pack(side="left", padx=(8, 4))
        self.base_entry = ctk.CTkEntry(bf, placeholder_text="manual override", width=150)
        self.base_entry.pack(side="left", padx=4)
        self.base_entry.bind("<Return>", lambda e: self.set_base())
        ctk.CTkButton(bf, text="Set Base", width=90, command=self.set_base).pack(side="left", padx=4)
        ctk.CTkButton(bf, text="Auto Base", width=90, command=self.clear_base).pack(side="left", padx=4)
        ctk.CTkLabel(bf, textvariable=self.baseval, font=("Arial", 15, "bold")).pack(side="left", padx=10)
        ctk.CTkLabel(bf, textvariable=self.baselbl, text_color="#8b98a9").pack(side="left", padx=8)

        # Optional OCR capture — diagnostic only; Kalshi API remains authoritative.
        of = ctk.CTkFrame(self._content); of.pack(fill="x", padx=18, pady=4)
        ctk.CTkLabel(of, text="OPTIONAL OCR", text_color="#8b98a9").pack(side="left", padx=(8, 4))
        ctk.CTkButton(of, text="Select BRTI Region", width=125, command=self.select_brti_region).pack(side="left", padx=4)
        ctk.CTkButton(of, text="Start / Stop OCR", width=120, command=self.toggle_ocr).pack(side="left", padx=4)
        ctk.CTkButton(of, text="Capture OCR Now", width=120, command=self.capture_ocr).pack(side="left", padx=4)
        ctk.CTkLabel(of, textvariable=self.ocr_status, font=("Arial", 13, "bold")).pack(side="left", padx=10)
        ctk.CTkLabel(of, text="BRTI OCR:", text_color="#8b98a9").pack(side="left", padx=(12, 3))
        ctk.CTkLabel(of, textvariable=self.ocr_value).pack(side="left", padx=3)
        ctk.CTkLabel(of, text="vs Coinbase:", text_color="#8b98a9").pack(side="left", padx=(12, 3))
        ctk.CTkLabel(of, textvariable=self.ocr_diff).pack(side="left", padx=3)
        ctk.CTkLabel(of, text="BRTI screen region from config.json", text_color="#687487").pack(side="right", padx=8)

        # Main model row
        self._cards([
            ("FORECAST vs BASE", self.d),
            ("MODEL P(UP)", self.prob),
            ("PROJECTED @15m", self.projp),
            ("PROJECTED vs BASE", self.vsbase),
        ])
        self._cards([
            ("KALSHI YES", self.yesvar),
            ("YES BID / ASK", self.bidaskvar),
            ("DEPTH IMBALANCE", self.depthvar),
            ("TRADE FLOW", self.flowvar),
        ])
        self._cards([
            ("VOLUME", self.volvar),
            ("OPEN INTEREST", self.oitvar),
            ("BOOK TOP", self.bookvar),
            ("LAST TRADE", self.lasttradevar),
        ])
        self._cards([
            ("BRTI OCR PRICE", self.ocr_value),
            ("BRTI ↔ COINBASE", self.ocr_diff),
            ("OCR STATUS", self.ocr_status),
            ("OCR RAW TEXT", self.ocr_text),
        ])

        ctk.CTkLabel(
            self._content,
            text="LIVE GRAPH — 3 live feeds + horizontal BASE PRICE line  •  Coinbase = blue  •  BRTI OCR = green  •  Kalshi YES = orange  •  Base = yellow",
            text_color="#8b98a9",
        ).pack(pady=(10, 1))
        self.graph = ctk.CTkCanvas(
            self._content, height=330, background="#10151c",
            highlightthickness=1, highlightbackground="#293241",
        )
        self.graph.pack(fill="x", padx=18, pady=(2, 8))

        ctk.CTkLabel(
            self._content,
            text="KALSHI MICROSTRUCTURE — order-book depth and trade-flow imbalance",
            text_color="#8b98a9",
        ).pack(pady=(8, 1))
        self.micrograph = ctk.CTkCanvas(
            self._content, height=180, background="#10151c",
            highlightthickness=1, highlightbackground="#293241",
        )
        self.micrograph.pack(fill="x", padx=18, pady=(2, 8))

        self._cards([
            ("COINBASE SCORE 50%", self.coin_scorev),
            ("KALSHI SCORE 50%", self.kalshi_scorev),
            ("COMBINED", self.mix_scorev),
            ("CONFIDENCE", self.confvar),
        ])
        self._cards([
            ("SIGNAL", self.signal),
            ("EDGE", self.edgevar),
            ("LEARNING", self.adaptivevar),
            ("DATA HEALTH", self.datahealth),
        ])
        self._cards([
            ("HISTORICAL HIT RATE", self.hitlbl),
            ("SELF-CALIBRATION", self.calibvar),
            ("SESSION", self.sessionlbl),
            ("LAST 15M", self.lastq),
        ])

        self.info = ctk.CTkTextbox(self._content, height=250)
        self.info.pack(fill="both", expand=True, padx=18, pady=5)

        b = ctk.CTkFrame(self._content); b.pack(pady=7)
        ctk.CTkButton(b, text="Pause / Resume (F9)", command=self.pause).pack(side="left", padx=5)
        ctk.CTkButton(b, text="Quit (F10)", command=self.quit).pack(side="left", padx=5)
        ctk.CTkLabel(
            self._content,
            text="Analytics only — this program collects public market data and does not place trades.",
            text_color="#687487",
        ).pack(pady=6)

    def _cards(self, entries):
        row = ctk.CTkFrame(self._content); row.pack(fill="x", padx=18, pady=(4, 0))
        for title, var in entries:
            b = ctk.CTkFrame(row); b.pack(side="left", fill="both", expand=True, padx=4, pady=3)
            ctk.CTkLabel(b, text=title, text_color="#8b98a9").pack(pady=(6, 0))
            ctk.CTkLabel(b, textvariable=var, font=("Arial", 15, "bold")).pack(pady=5)

    def _save_ocr_region(self, region):
        try:
            CFG.setdefault("ocr", {})["region"] = dict(region)
            (BASE / "config.json").write_text(
                json.dumps(CFG, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def select_brti_region(self):
        def done(region):
            OCR_REGION_DESC.clear()
            OCR_REGION_DESC.update(region)
            BRTI_OCR.set_region(region)
            self._save_ocr_region(region)
            self.ocr_status.set(
                f"REGION SET {region['width']}×{region['height']}"
            )
        Selector(self, done, label="Drag a box around the BRTI BTC price • Enter = confirm • Esc = cancel")

    def toggle_ocr(self):
        if BRTI_OCR.snapshot()["enabled"]:
            BRTI_OCR.stop()
        else:
            BRTI_OCR.start()

    def capture_ocr(self):
        BRTI_OCR.capture_once()
        snap = BRTI_OCR.snapshot()
        self._update_ocr_display(
            snap.get("price"),
            COINBASE.snapshot().get("price"),
            KALSHI.snapshot().get("price"),
        )

    def _update_ocr_display(self, ocrp, coinbase_p, api_yes):
        o = BRTI_OCR.snapshot()
        self.ocr_status.set(
            o.get("status", "OCR OFF") +
            (f" • {o.get('error')}" if o.get("error") else "")
        )
        self.ocr_value.set("—" if ocrp is None else f"${ocrp:,.2f}")
        self.ocr_text.set(o.get("raw") or "—")

        if ocrp is None or coinbase_p is None:
            diff_cb = None
        else:
            diff_cb = ocrp - coinbase_p
        if ocrp is None or api_yes is None:
            self.ocr_diff.set(
                "—" if diff_cb is None else f"{diff_cb:+,.2f} vs Coinbase"
            )
        else:
            self.ocr_diff.set(
                f"ΔCB ${diff_cb:+,.2f}" if diff_cb is not None else "—"
            )

        # BRTI OCR is stored separately for diagnostics and historical comparison.
        if o.get("ts") is not None and o.get("ts") != self._last_saved_ocr_ts:
            append_dict(OCR_CAPTURES_CSV, OCR_FIELDS, {
                "timestamp": time.strftime(
                    "%Y-%m-%dT%H:%M:%S",
                    time.localtime(o.get("ts") or time.time())
                ),
                "kalshi_ticker": KALSHI.snapshot().get("ticker"),
                "api_yes": api_yes,
                "ocr_value": ocrp,
                "difference_cents": (
                    None if diff_cb is None else diff_cb * 100.0
                ),
                "ocr_text": o.get("raw", ""),
                "ocr_status": o.get("status", ""),
                "notes": "BRTI reference-only; Coinbase/Kalshi API remain authoritative",
            })
            self._last_saved_ocr_ts = o.get("ts")

    def set_base(self):
        raw = self.base_entry.get().strip().replace(",", "").replace("$", "")
        try:
            value = float(raw)
            if value <= 0:
                raise ValueError
        except ValueError:
            self.baselbl.set("invalid base price")
            return
        self.base = value
        self.base_ts = time.time()
        self.manual_base = True
        self.baseval.set("$" + format(value, ",.2f"))
        self.baselbl.set("MANUAL BASE — stays until Auto Base")

    def clear_base(self):
        self.base = None
        self.base_ts = None
        self.manual_base = False
        self.base_entry.delete(0, "end")
        self.baseval.set("AUTO")
        self.baselbl.set("auto base from Coinbase at each 15m boundary")

    def coinbase_score(self, ex):
        ticks = ex.get("ticks", [])
        p = ex.get("price")
        if p is None or len(ticks) < 2:
            return None
        now = ex.get("last_ts") or int(time.time() * 1000)
        def ret(ms):
            old = next((v for t, v, _ in reversed(ticks) if t <= now - ms), None)
            return None if old is None or old == 0 else (p / old - 1) * 100
        score = 0.0
        for ms, w, scale in [
            (1000, .08, .20), (5000, .12, .20), (15000, .15, .25),
            (30000, .15, .35), (60000, .18, .50), (300000, .16, 1.0),
            (900000, .16, 1.5)
        ]:
            r = ret(ms)
            if r is not None:
                score += max(-1, min(1, r / scale)) * w
        return max(-1, min(1, score))

    def kalshi_score(self, k):
        """Multi-horizon Kalshi microstructure score. No $1 threshold."""
        p = safe_float(k.get("price"))
        if p is None:
            return None
        centered = (p - 0.5) * 2.0
        momentum = (
            0.10 * max(-1, min(1, (safe_float(k.get("kalshi_ret_5s"), 0) or 0) / 0.015)) +
            0.18 * max(-1, min(1, (safe_float(k.get("kalshi_ret_15s"), 0) or 0) / 0.025)) +
            0.18 * max(-1, min(1, (safe_float(k.get("kalshi_ret_30s"), 0) or 0) / 0.04)) +
            0.22 * max(-1, min(1, (safe_float(k.get("kalshi_ret_60s"), 0) or 0) / 0.06)) +
            0.12 * max(-1, min(1, (safe_float(k.get("kalshi_ret_300s"), 0) or 0) / 0.10))
        )
        depth = (
            0.20 * (safe_float(k.get("depth_imbalance_1"), 0) or 0) +
            0.25 * (safe_float(k.get("depth_imbalance_3"), 0) or 0) +
            0.30 * (safe_float(k.get("depth_imbalance_5"), 0) or 0) +
            0.25 * (safe_float(k.get("depth_imbalance_10"), k.get("depth_imbalance", 0)) or 0)
        )
        flow = (
            0.45 * (safe_float(k.get("trade_imbalance_15s"), 0) or 0) +
            0.55 * (safe_float(k.get("trade_imbalance_60s"), k.get("trade_imbalance", 0)) or 0)
        )
        spread = safe_float(k.get("spread"), 0.0) or 0.0
        # Penalize wide markets, but don't let the spread dominate direction.
        spread_penalty = min(0.15, spread)
        series_bias = ((safe_float(k.get("series_history_up_rate"), 0.5) or 0.5) - 0.5) * 0.25
        return max(-1.0, min(1.0,
            0.24*centered + 0.26*momentum + 0.22*depth +
            0.20*flow + series_bias - spread_penalty
        ))

    def _persistence_stats(self):
        vals = [x for x in self.signal_points if x is not None]
        dirs = list(self.signal_dir_points)
        if not vals:
            return 0.0, 0, 0.0
        avg = sum(vals) / len(vals)
        avg_abs = sum(abs(x) for x in vals) / len(vals)
        consistency = min(1.0, abs(avg) / max(avg_abs, 0.05))
        target = 1 if avg > 0 else -1
        streak = 0
        for d in reversed(dirs):
            if d == target:
                streak += 1
            elif d != 0:
                break
        return consistency, streak, avg

    def direction_persistence(self, score, record=True):
        if record and score is not None:
            self.signal_points.append(float(score))
            self.signal_dir_points.append(0 if abs(score) < 0.02 else (1 if score > 0 else -1))
        return self._persistence_stats()

    def combined_signal_score(self, coin_score, kalshi_score, x, k, brti_price, record_history=True):
        if coin_score is None or kalshi_score is None:
            return None, {}
        coin_k = (coin_score * kalshi_score)
        flow = safe_float(k.get("trade_imbalance_60s"), k.get("trade_imbalance", 0)) or 0.0
        depth = safe_float(k.get("depth_imbalance_5"), k.get("depth_imbalance", 0)) or 0.0
        agreement = max(-1.0, min(1.0, coin_score * ((safe_float(k.get("price"), 0.5) or 0.5)-0.5)*2.0))
        brti_confirm = 0.0
        if brti_price is not None and x.get("price"):
            # BRTI > Coinbase can be corroborating context only; its sign alone never decides.
            brti_confirm = max(-1.0, min(1.0, ((float(brti_price)/float(x["price"]))-1.0)/0.0025))
        score = (
            0.28 * coin_score +
            0.38 * kalshi_score +
            0.10 * flow +
            0.08 * depth +
            0.06 * agreement +
            0.04 * brti_confirm
        )
        persistence, streak, persisted_score = self.direction_persistence(score, record=record_history)
        # A reversal between closely spaced samples is explicitly penalized.
        reversal_penalty = 0.0
        if len(self.signal_points) >= 3:
            a,b,c = list(self.signal_points)[-3:]
            if a*b < 0 or b*c < 0:
                reversal_penalty = -0.12
        score = max(-1.0, min(1.0, score + reversal_penalty))
        diagnostics = {
            "flow": flow, "depth": depth, "agreement": agreement,
            "brti_confirm": brti_confirm, "persistence": persistence,
            "streak": streak, "reversal_penalty": reversal_penalty,
            "persisted_score": persisted_score,
        }
        return score, diagnostics

    def raw_model_prob(self, x, base, seconds_left, score):
        if x.get("price") is None or base is None or score is None:
            return None
        # Directional evidence drives the probability; volatility controls how confident
        # we can be in the projection over the remaining contract horizon.
        secs = max(1.0, float(seconds_left or 1.0))
        vol = max(safe_float(x.get("vol"), 0.02) or 0.02, 0.005)
        horizon = math.sqrt(secs / 60.0)
        confidence_scale = min(1.25, max(0.35, 0.75 + 0.20*horizon))
        z = max(-3.5, min(3.5, score * 2.8 * confidence_scale))
        # Slightly shrink toward the Kalshi base-rate-neutral midpoint rather than instant flip.
        return max(0.02, min(0.98, 0.5 + 0.46 * math.tanh(z/2.0)))

    def adaptive_probability(self, coin_score, x, k, raw_prob, brti_price):
        if raw_prob is None:
            return None, None, None
        feats = LEARNER.make_features(coin_score, x, k, brti_price)
        # Inject the engine's live reversal penalty into the final feature slot.
        if self.signal_points and len(self.signal_points) >= 3:
            recent = list(self.signal_points)[-3:]
            feats[-1] = -1.0 if (recent[0]*recent[1] < 0 or recent[1]*recent[2] < 0) else 0.0
        learned = LEARNER.predict(feats)
        final = raw_prob
        if LEARNER.enabled and LEARNER.n >= LEARNER.min_examples:
            final = (1.0-LEARNER.blend)*raw_prob + LEARNER.blend*learned
        return max(0.01, min(0.99, final)), feats, learned
    def raw_model_prob(self, x, base, proj, seconds_left):
        if x["price"] is None or base is None or proj is None:
            return None
        vol = max(x.get("vol") or .02, .005)
        seconds_left = max(1.0, float(seconds_left or 1.0))
        sd = max(x["price"] * vol * math.sqrt(seconds_left / 60) / 100, x["price"] * .00005)
        z = (proj - base) / sd
        return max(0.01, min(0.99, 0.5 * (1 + math.erf(z / math.sqrt(2)))))

    def get_boundary_price(self, qstart):
        ex = COINBASE.snapshot()
        ticks = ex.get("ticks", [])
        cand = [(abs(t-qstart*1000), v) for t, v, _ in ticks if abs(t-qstart*1000) <= 5000]
        return min(cand)[1] if cand else ex.get("price")

    def grade_quarter(self, close_price, qstart, resolved_result=None, resolved_settlement=None):
        if self.q_open is None or close_price is None or self.q_open.get("base") is None:
            return
        base = self.q_open["base"]
        result = str(resolved_result or "").strip().lower()
        settle = safe_float(resolved_settlement)
        if result in ("yes", "up", "true", "1") or settle == 100:
            actual = "UP"
        elif result in ("no", "down", "false", "0") or settle == 0:
            actual = "DOWN"
        else:
            actual = "UP" if close_price > base else "DOWN" if close_price < base else "FLAT"
        called = self.q_open.get("direction")
        correct = called in ("UP", "DOWN") and actual in ("UP", "DOWN") and called == actual

        hist_append({
            "quarter_start_iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(qstart)),
            "base": base, "price_open": self.q_open.get("price", ""),
            "proj_open": self.q_open.get("proj", "") or "",
            "score_open": self.q_open.get("score", ""),
            "direction_open": called, "price_close": close_price,
            "direction_actual": actual, "correct": str(correct),
        })
        self.session_total += 1
        if correct:
            self.session_correct += 1
            self.lastq.set(f"CORRECT • {called} • close ${close_price:,.2f}")
        else:
            self.session_incorrect += 1
            self.lastq.set(f"INCORRECT • called {called} • was {actual}")

        # Train only after a completed contract, using representative feature snapshots
        # from across the contract rather than only the opening tick.
        ticker = self.q_open.get("ticker", "")
        adaptive_open = self.q_open.get("adaptive_prob")
        feats = self.q_open.get("adaptive_features")
        samples = list(self.contract_learning_samples)
        if feats is not None:
            samples.insert(0, (time.time(), self.q_open.get("seconds_left") or 900, list(feats), adaptive_open))
        if actual in ("UP", "DOWN") and samples:
            y = 1.0 if actual == "UP" else 0.0
            # Pick opening, middle, and late (but >10s before close) samples. This captures
            # persistent direction/flow changes without training hundreds of correlated ticks.
            samples = sorted(samples, key=lambda z: z[1], reverse=True)
            idxs = sorted(set([0, len(samples)//2, max(0, len(samples)-1)]))
            chosen = [samples[i] for i in idxs[:3]]
            errors = []
            preds = []
            for _, _, sf, sp in chosen:
                pp, err = LEARNER.update(sf, y, ticker=ticker)
                preds.append(pp)
                errors.append(err)
            avg_pred = sum(preds)/len(preds) if preds else adaptive_open
            append_dict(ADAPTIVE_PREDICTIONS, ADAPTIVE_FIELDS, {
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "ticker": ticker,
                "prediction": avg_pred,
                "actual": y,
                "correct": str((avg_pred >= 0.5) == (y == 1.0)) if avg_pred is not None else "",
                "feature_names": json.dumps(LEARNER.feature_names),
                "features_json": json.dumps(
                    {"selected_samples": [s[2] for s in chosen], "seconds_left": [s[1] for s in chosen]},
                    separators=(",", ":")
                ),
                "learner_error": sum(errors)/len(errors) if errors else "",
            })
        self.contract_learning_samples.clear()

        k = self.q_open.get("kalshi", {})
        append_session_round({
            "session_id": self.session_id,
            "quarter_start_iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(qstart)),
            "quarter_end_iso": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "base_price": base, "price_open": self.q_open.get("price", ""),
            "price_close": close_price, "forecast_open": self.q_open.get("proj", "") or "",
            "momentum_score": self.q_open.get("score", ""),
            "model_prob_up": self.q_open.get("model_prob_up", ""),
            "up_price": self.q_open.get("up_price", ""),
            "down_price": self.q_open.get("down_price", ""),
            "signal": self.q_open.get("signal", ""),
            "direction_called": called, "direction_actual": actual,
            "correct": str(correct), "edge_up": self.q_open.get("edge_up", ""),
            "edge_down": self.q_open.get("edge_down", ""),
            "confidence": self.q_open.get("confidence", ""),
            "kalshi_ticker": k.get("ticker", ""), "kalshi_yes": k.get("yes", ""),
            "kalshi_bid": k.get("bid", ""), "kalshi_ask": k.get("ask", ""),
            "kalshi_depth_imbalance": k.get("depth_imbalance", ""),
            "kalshi_trade_imbalance": k.get("trade_imbalance", ""),
            "kalshi_volume": k.get("volume", ""),
            "kalshi_open_interest": k.get("open_interest", ""),
            "seconds_left": self.q_open.get("seconds_left", ""),
        })
        self.persist_session()
        self.update_all_time()
        self.recompute_calibration()
        self.adaptivevar.set(LEARNER.label())
        self.sessionlbl.set(
            f"{self.session_correct}/{self.session_total} correct "
            f"({self.session_correct/self.session_total*100:.1f}%)"
        )

    def persist_session(self):
        rows = load_csv(SESSION_CSV)
        rows = [r for r in rows if r.get("session_id") != self.session_id]
        rows.append({
            "session_id": self.session_id,
            "session_start": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.session_start)),
            "session_end": time.strftime("%Y-%m-%d %H:%M:%S"),
            "quarters": self.session_total, "correct": self.session_correct,
            "incorrect": self.session_incorrect,
            "hit_rate": (self.session_correct/self.session_total if self.session_total else ""),
        })
        with open(SESSION_CSV, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=SESSION_FIELDS)
            w.writeheader(); w.writerows(rows)

    def recompute_calibration(self):
        rows = hist_load(1000)
        graded = [r for r in rows if r.get("correct") in ("True", "False")]
        self.hitn = len(graded)
        if self.hitn < MIN_GRADED_FOR_CALIB:
            self.hitrate = None; self.calib = 1.0
            self.hitlbl.set(f"{self.hitn}/{MIN_GRADED_FOR_CALIB} graded")
            self.calibvar.set("×1.00 (inactive)")
            return
        hits = sum(r["correct"] == "True" for r in graded)
        hr = hits / self.hitn; self.hitrate = hr
        self.calib = max(.75, min(CALIB_CAP, .75 + hr*.75))
        self.hitlbl.set(f"{hr*100:.1f}% • {self.hitn} graded")
        self.calibvar.set(f"×{self.calib:.2f}")

    def update_all_time(self):
        graded = [r for r in load_csv(HIST) if r.get("correct") in ("True", "False")]
        hits = sum(r.get("correct") == "True" for r in graded)
        self.alltimelbl.set(
            f"{hits}/{len(graded)} correct ({hits/len(graded)*100:.1f}%)"
            if graded else "0/0"
        )

    def persist_market_data(self, ex, k, seconds_left):
        now_iso = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
        append_dict(MARKET_TICKS_CSV, TICK_FIELDS, {
            "timestamp": now_iso, "coinbase_price": ex.get("price"),
            "kalshi_ticker": k.get("ticker"), "kalshi_yes": k.get("price"),
            "kalshi_bid": k.get("yes_bid"), "kalshi_ask": k.get("yes_ask"),
            "kalshi_no_bid": k.get("no_bid"), "kalshi_no_ask": k.get("no_ask"),
            "kalshi_last_price": k.get("last_price"), "kalshi_spread": k.get("spread"),
            "kalshi_volume": k.get("volume"), "kalshi_volume_24h": k.get("volume_24h"),
            "kalshi_open_interest": k.get("open_interest"), "kalshi_liquidity": k.get("liquidity"),
            "kalshi_depth_yes": k.get("depth_yes_total"), "kalshi_depth_no": k.get("depth_no_total"),
            "depth_imbalance": k.get("depth_imbalance"),
            "depth_imbalance_1": k.get("depth_imbalance_1"), "depth_imbalance_3": k.get("depth_imbalance_3"),
            "depth_imbalance_5": k.get("depth_imbalance_5"), "depth_imbalance_10": k.get("depth_imbalance_10"),
            "trade_buy_volume": k.get("trade_buy_volume"), "trade_sell_volume": k.get("trade_sell_volume"),
            "trade_imbalance": k.get("trade_imbalance"), "trade_imbalance_15s": k.get("trade_imbalance_15s"),
            "trade_imbalance_60s": k.get("trade_imbalance_60s"), "trade_rate_60s": k.get("trade_rate_60s"),
            "trade_volume_60s": k.get("trade_volume_60s"),
            "seconds_left": seconds_left, "series_up_rate": k.get("series_history_up_rate"),
            "series_history_count": k.get("series_history_count"),
        })
        if k.get("ticker"):
            append_dict(KALSHI_SNAPSHOTS_CSV, SNAPSHOT_FIELDS, {
                "timestamp": now_iso,
                "ticker": k.get("ticker"),
                "event_ticker": k.get("event_ticker"),
                "series_ticker": k.get("series_ticker"),
                "title": k.get("title"),
                "subtitle": k.get("subtitle"),
                "status": k.get("status_label"),
                "open_time": k.get("open_time"),
                "close_time": k.get("close_time"),
                "expiration_time": k.get("expiration_time"),
                "result": k.get("result"),
                "settlement_value": k.get("settlement_value"),
                "volume": k.get("volume"),
                "volume_24h": k.get("volume_24h"),
                "open_interest": k.get("open_interest"),
                "liquidity": k.get("liquidity"),
                "yes_bid": k.get("yes_bid"),
                "yes_ask": k.get("yes_ask"),
                "no_bid": k.get("no_bid"),
                "no_ask": k.get("no_ask"),
                "raw_market_json": json.dumps(k.get("raw_market", {}), separators=(",", ":")),
                "raw_event_json": json.dumps(k.get("event_details", {}), separators=(",", ":")),
                "raw_series_json": json.dumps(k.get("series_details", {}), separators=(",", ":")),
                "series_recent_markets_json": json.dumps(k.get("series_recent_markets", []), separators=(",", ":")),
            })
            append_dict(KALSHI_BOOK_CSV, BOOK_FIELDS, {
                "captured_at": now_iso, "ticker": k.get("ticker"),
                "yes_levels": json.dumps(k.get("orderbook_yes", [])),
                "no_levels": json.dumps(k.get("orderbook_no", [])),
                "yes_depth_total": k.get("depth_yes_total"),
                "no_depth_total": k.get("depth_no_total"),
                "depth_imbalance": k.get("depth_imbalance"),
                "raw_json": json.dumps(k.get("raw_orderbook", {}), separators=(",", ":")),
            })

            # Persist only unseen public trades by trade ID.
            seen = getattr(self, "_saved_trade_ids", set())
            for tr in k.get("recent_trades", []):
                tid = tr.get("id")
                if tid and tid in seen:
                    continue
                if tid:
                    seen.add(tid)
                append_dict(KALSHI_TRADES_CSV, TRADE_FIELDS, {
                    "captured_at": now_iso,
                    "ticker": k.get("ticker"),
                    "trade_id": tid,
                    "trade_timestamp": tr.get("ts"),
                    "yes_price": tr.get("price"),
                    "size": tr.get("size"),
                    "side": tr.get("side"),
                    "raw_json": json.dumps(tr, separators=(",", ":")),
                })
            self._saved_trade_ids = seen

    def refresh(self):
        if self.paused:
            self.after(250, self.refresh)
            return

        now = time.time()
        ex = COINBASE.snapshot()
        k = KALSHI.snapshot()
        brti = BRTI_OCR.snapshot()

        p = safe_float(ex.get("price"))
        kp = safe_float(k.get("price"))
        ocrp = safe_float(brti.get("price"))
        self._update_ocr_display(ocrp, p, kp)

        close_ts = k.get("close_time")
        seconds_left = max(0.0, close_ts-now) if close_ts else None

        self.clock.set(
            f"{int(seconds_left)//60:02d}:{int(seconds_left)%60:02d}"
            if seconds_left is not None else "searching…"
        )
        self.coin_status.set(
            "COINBASE: " +
            (f"${p:,.2f} • {ex.get('status')}" if p is not None else ex.get("status", "—"))
        )
        self.tickervar.set(k.get("ticker") or "searching…")
        self.yesvar.set("—" if kp is None else f"{kp*100:.1f}¢")
        if k.get("yes_bid") is None and k.get("yes_ask") is None:
            self.bidaskvar.set("—")
        else:
            bid = k.get("yes_bid")
            ask = k.get("yes_ask")
            self.bidaskvar.set(
                f"{bid*100:.1f}¢ / {ask*100:.1f}¢"
                if bid is not None and ask is not None
                else f"{bid*100:.1f}¢ / —" if bid is not None else f"— / {ask*100:.1f}¢"
            )
        self.kstatusvar.set(
            f"KALSHI: {k.get('status','—')} • {k.get('status_label') or 'open'}"
        )

        # Contract lifecycle follows Kalshi's actual contract timestamps.
        contract_open = k.get("open_time") or (int(now) - (int(now) % 900))
        active_ticker = k.get("ticker")
        ticker = active_ticker

        if self.q_start is None and active_ticker:
            self.q_start = contract_open
            self.last_round_ticker = active_ticker
            self.last_round_close = k.get("close_time")
            self.signal_points.clear(); self.signal_dir_points.clear(); self.contract_learning_samples.clear()
            if not self.manual_base and p is not None:
                self.base = self.get_boundary_price(contract_open) or p
                self.base_ts = now
                self.baseval.set("$" + format(self.base, ",.2f"))
                self.baselbl.set(
                    f"AUTO BASE • {time.strftime('%H:%M:%S', time.localtime(contract_open))}"
                )
        elif active_ticker and self.last_round_ticker and active_ticker != self.last_round_ticker:
            close = self.get_boundary_price(
                self.last_round_close or int(now) - (int(now) % 900)
            ) or p
            self.grade_quarter(
                close, self.q_start, resolved_result=(k.get("result") or k.get("last_closed_result")),
                resolved_settlement=(k.get("settlement_value") if k.get("settlement_value") is not None else k.get("last_closed_settlement")),
            )
            self.q_start = contract_open
            self.q_open = None
            self.last_round_ticker = active_ticker
            self.signal_points.clear(); self.signal_dir_points.clear(); self.contract_learning_samples.clear()
            self.last_round_close = k.get("close_time")
            if not self.manual_base and p is not None:
                self.base = self.get_boundary_price(contract_open) or p
                self.base_ts = now
                self.baseval.set("$" + format(self.base, ",.2f"))
                self.baselbl.set(
                    f"AUTO BASE • {time.strftime('%H:%M:%S', time.localtime(contract_open))}"
                )
        elif (
            active_ticker is None and self.last_round_ticker and
            self.last_round_close and now >= self.last_round_close and self.q_open is not None
        ):
            close = self.get_boundary_price(self.last_round_close) or p
            self.grade_quarter(
                close, self.q_start, resolved_result=(k.get("result") or k.get("last_closed_result")),
                resolved_settlement=(k.get("settlement_value") if k.get("settlement_value") is not None else k.get("last_closed_settlement")),
            )
            self.q_start = None
            self.q_open = None
            self.last_round_ticker = None
            self.last_round_close = None

        if p is not None:
            x = self.btc_features(ex)
            cscore = self.coinbase_score(ex)
            kscore = self.kalshi_score(k)
            signal_source_ts = (k.get("last_ts"), ex.get("last_ts"), brti.get("ts"))
            new_signal_sample = signal_source_ts != self._last_signal_source_ts
            self._last_signal_source_ts = signal_source_ts
            score, diag = self.combined_signal_score(
                cscore, kscore, x, k, ocrp, record_history=new_signal_sample
            )
            if not new_signal_sample:
                pz, st, av = self._persistence_stats()
                diag["persistence"], diag["streak"], diag["persisted_score"] = pz, st, av
            secs = seconds_left if seconds_left is not None else 900.0
            raw_prob = self.raw_model_prob(x, self.base, secs, score)
            model_prob, adaptive_features, learned_prob = self.adaptive_probability(
                cscore, x, k, raw_prob, ocrp
            )
            if adaptive_features is not None and ticker is not None and seconds_left is not None and seconds_left > 10:
                last_sample_t = self.contract_learning_samples[-1][0] if self.contract_learning_samples else None
                if last_sample_t is None or now - last_sample_t >= 3.0:
                    self.contract_learning_samples.append(
                        (now, seconds_left, list(adaptive_features), learned_prob)
                    )
        else:
            x = {}
            cscore = kscore = score = raw_prob = model_prob = learned_prob = None
            adaptive_features = None
            diag = {}

        self.coin_scorev.set("—" if cscore is None else f"{cscore:+.2f}")
        self.kalshi_scorev.set("—" if kscore is None else f"{kscore:+.2f}")
        if score is None:
            self.mix_scorev.set("—")
        else:
            self.mix_scorev.set(
                f"{score:+.2f} • persistence {diag.get('persistence',0):.2f}"
            )
        self.prob.set("—" if model_prob is None else f"{model_prob*100:.1f}%")

        self.projp.set("—")
        if self.base is not None and p is not None and score is not None:
            # Projection is explicitly a directional projection, not a one-dollar trigger.
            horizon = max(1.0, float(seconds_left or 900.0))
            vol = max(safe_float(x.get("vol"), 0.02) or 0.02, 0.005)
            trend = (safe_float(x.get("slope"), 0.0) or 0.0) / 100.0
            magnitude = max(-3.0, min(3.0,
                (0.70*score + 0.20*max(-1,min(1,trend/.003))) *
                vol * math.sqrt(horizon/60.0)
            ))
            proj = p * (1.0 + magnitude/100.0)
        else:
            proj = None

        direction = "WAITING"
        if score is not None:
            direction = "UP" if score > 0.05 else "DOWN" if score < -0.05 else "FLAT"

        self.d.set(direction)
        if self.base is not None and proj is not None:
            diff = proj - self.base
            self.vsbase.set(f"{diff:+,.2f} ({diff/self.base*100:+.3f}%)")
            self.projp.set("$" + format(proj, ",.2f"))
        else:
            self.vsbase.set("—")

        depth = safe_float(k.get("depth_imbalance"))
        flow = safe_float(k.get("trade_imbalance"))
        self.depthvar.set("—" if depth is None else f"{depth:+.2f}")
        self.flowvar.set("—" if flow is None else f"{flow:+.2f}")
        self.volvar.set("—" if k.get("volume") is None else f"{k.get('volume')}")
        self.oitvar.set("—" if k.get("open_interest") is None else f"{k.get('open_interest')}")
        self.bookvar.set(
            "—" if depth is None else
            f"YES {k.get('depth_yes_total',0):,.0f} / NO {k.get('depth_no_total',0):,.0f}"
        )
        recent = k.get("recent_trades", [])
        last_tr = recent[-1] if recent else None
        self.lasttradevar.set(
            "—" if not last_tr else
            f"{(last_tr.get('price') or 0)*100:.1f}¢ × {last_tr.get('size',0):g}"
        )

        persistence = safe_float(diag.get("persistence"), 0.0) or 0.0
        streak = int(diag.get("streak", 0) or 0)
        agreement = safe_float(diag.get("agreement"), 0.0) or 0.0
        reversal = abs(safe_float(diag.get("reversal_penalty"), 0.0) or 0.0)

        edge_up = edge_down = None
        confidence = None
        if model_prob is not None and kp is not None:
            edge_up = model_prob - kp
            edge_down = kp - model_prob
            direction_ok = (
                (model_prob > 0.5 and score is not None and score > 0) or
                (model_prob < 0.5 and score is not None and score < 0)
            )
            confidence = min(
                0.995,
                0.50 +
                abs(model_prob-0.5)*0.80 +
                persistence*0.12 +
                min(0.08, streak/50.0) +
                (0.04 if agreement > 0.15 else 0.0) -
                reversal*0.15
            )
            self.confvar.set(f"{confidence*100:.0f}%")
            self.edgevar.set(f"UP {edge_up:+.3f} • DOWN {edge_down:+.3f}")

            # Require persistent directional evidence. A one-tick spike cannot instantly fire a BUY.
            buy_up = (
                model_prob >= 0.55 and edge_up >= MIN_EDGE and
                score is not None and score >= MIN_SIGNAL_SCORE and
                persistence >= 0.55 and streak >= MIN_PERSISTENCE and
                direction_ok and reversal < 0.10
            )
            buy_down = (
                model_prob <= 0.45 and edge_down >= MIN_EDGE and
                score is not None and score <= -MIN_SIGNAL_SCORE and
                persistence >= 0.55 and streak >= MIN_PERSISTENCE and
                direction_ok and reversal < 0.10
            )
            if confidence < MIN_CONFIDENCE:
                buy_up = buy_down = False
            if buy_up:
                self.signal.set("BUY UP")
                self.edgevar.set(f"BUY UP • edge {edge_up:+.3f}")
            elif buy_down:
                self.signal.set("BUY DOWN")
                self.edgevar.set(f"BUY DOWN • edge {edge_down:+.3f}")
            else:
                self.signal.set("NO EDGE / WAIT")
        else:
            self.signal.set("WAITING FOR DATA")
            self.edgevar.set("—")
            self.confvar.set("—")

        self.persist_market_data(ex, k, seconds_left)

        if p is not None or kp is not None or ocrp is not None:
            self.graph_points.append((now, p, kp, ocrp))
            self.depth_points.append((now, depth))
            self.flow_points.append((now, flow))
            self.draw_graph()
            self.draw_micrograph()

        # Save the exact feature state at the beginning of every contract.
        if self.q_open is None and p is not None and score is not None and self.base is not None:
            self.q_open = {
                "base": self.base, "price": p, "proj": proj, "score": score,
                "direction": direction, "model_prob_up": model_prob,
                "up_price": kp, "down_price": (1-kp if kp is not None else None),
                "signal": self.signal.get(), "edge_up": edge_up, "edge_down": edge_down,
                "confidence": confidence if model_prob is not None else None,
                "adaptive_features": adaptive_features,
                "adaptive_prob": learned_prob,
                "seconds_left": seconds_left, "ticker": ticker,
                "kalshi": dict(k),
            }

        health = []
        if p is not None: health.append("CB")
        if kp is not None: health.append("K")
        if ocrp is not None: health.append("BRTI")
        if k.get("orderbook_yes") or k.get("orderbook_no"): health.append("BOOK")
        if k.get("recent_trades"): health.append("TRADES")
        if k.get("series_details"): health.append("SERIES")
        self.datahealth.set("OK " + "+".join(health) if health else "WAITING")

        self.info.delete("1.0", "end")
        self.info.insert("end", f"{self.coin_status.get()}\n{self.kstatusvar.get()}\n")
        self.info.insert("end", f"Ticker={ticker or '—'}  Series={k.get('series_ticker') or '—'}  Event={k.get('event_ticker') or '—'}\n")
        self.info.insert("end", f"Title={k.get('title') or '—'}\n")
        self.info.insert("end", f"Open={self._fmt_time(k.get('open_time'))}  Close={self._fmt_time(k.get('close_time'))}  Remain={self.clock.get()}\n")
        self.info.insert("end", f"YES={self._c(kp)} BID={self._c(k.get('yes_bid'))} ASK={self._c(k.get('yes_ask'))} NO BID={self._c(k.get('no_bid'))} NO ASK={self._c(k.get('no_ask'))}\n")
        self.info.insert("end", f"Volume={k.get('volume','—')} 24h={k.get('volume_24h','—')} OI={k.get('open_interest','—')} Liquidity={k.get('liquidity','—')}\n")
        self.info.insert("end", f"Depth 1/3/5/10={k.get('depth_imbalance_1',0):+.2f}/{k.get('depth_imbalance_3',0):+.2f}/{k.get('depth_imbalance_5',0):+.2f}/{k.get('depth_imbalance_10',0):+.2f}\n")
        self.info.insert("end", f"Trade flow 15s/60s={k.get('trade_imbalance_15s',0):+.2f}/{k.get('trade_imbalance_60s',0):+.2f}  trade-rate60={k.get('trade_rate_60s',0):.1f}/min\n")
        self.info.insert("end", f"Kalshi momentum 5s/15s/30s/60s/300s={k.get('kalshi_ret_5s',0):+.3f}/{k.get('kalshi_ret_15s',0):+.3f}/{k.get('kalshi_ret_30s',0):+.3f}/{k.get('kalshi_ret_60s',0):+.3f}/{k.get('kalshi_ret_300s',0):+.3f} pct\n")
        self.info.insert("end", f"Direction score={score if score is not None else '—'}  persistence={persistence:.2f} streak={streak} agreement={agreement:+.2f} reversal={reversal:.2f}\n")
        self.info.insert("end", f"Series history: {k.get('series_history_count',0)} resolved • UP rate={((k.get('series_history_up_rate') or 0.5)*100):.1f}% • avg vol={k.get('series_history_avg_volume','—')}\n")
        if model_prob is not None:
            self.info.insert("end", f"Model P(UP)={model_prob*100:.1f}%  Kalshi={self._c(kp)}  edge UP={edge_up if edge_up is not None else '—'}  edge DOWN={edge_down if edge_down is not None else '—'}\n")
        self.info.insert("end", f"Adaptive learner: {LEARNER.label()}\n")
        self.info.insert("end", "Kalshi raw market/event/series/orderbook/trade payloads are persisted for research and adaptation.\n")
        if brti.get("error"):
            self.info.insert("end", f"BRTI OCR: {brti.get('error')}\n")
        if k.get("error"):
            self.info.insert("end", f"Kalshi error: {k.get('error')}\n")

        self.after(250, self.refresh)
    @staticmethod
    def _c(v):
        return "—" if v is None else f"{v*100:.1f}¢"

    @staticmethod
    def _fmt_time(v):
        return "—" if not v else time.strftime("%H:%M:%S", time.localtime(v))

    def draw_graph(self):
        self.graph.delete("all")
        pts = list(self.graph_points)
        if len(pts) < 2:
            return
        W = max(self.graph.winfo_width(), 900)
        H = max(self.graph.winfo_height(), 330)
        pad = 48

        btc = [v for _, v, _, _ in pts if v is not None]
        ocr = [v for _, _, _, v in pts if v is not None]
        kal = [v for _, _, v, _ in pts if v is not None]
        if btc:
            blo, bhi = min(btc), max(btc)
            # Include base in range so the horizontal line always appears.
            if self.base is not None:
                blo, bhi = min(blo, self.base), max(bhi, self.base)
            margin = max((bhi-blo)*0.08, 5)
            blo -= margin; bhi += margin
        else:
            blo, bhi = 0, 1
        bspan = max(bhi-blo, 1)

        klo, khi = ((min(kal), max(kal)) if kal else (0, 1))
        klo = max(0.0, klo - .03); khi = min(1.0, khi + .03)
        kspan = max(khi-klo, .02)

        for j in range(5):
            y = pad+(H-2*pad)*j/4
            self.graph.create_line(pad, y, W-pad, y, fill="#202936")
            bv = bhi-(bhi-blo)*j/4
            kv = khi-(khi-klo)*j/4
            self.graph.create_text(6, y, text=f"${bv:,.0f}", anchor="w", fill="#6f7d8c", font=("Arial",8))
            self.graph.create_text(W-6, y, text=f"{kv*100:.0f}¢", anchor="e", fill="#6f7d8c", font=("Arial",8))

        def xy_for(i, v, lo, span):
            x = pad+(W-2*pad)*i/(len(pts)-1)
            y = H-pad-(H-2*pad)*(v-lo)/span
            return x, y

        def draw_series(index, lo, span, fill):
            segment = []
            for i, item in enumerate(pts):
                v = item[index]
                if v is None:
                    if len(segment) >= 4:
                        self.graph.create_line(*segment, fill=fill, width=2, smooth=True)
                    segment = []
                    continue
                x, y = xy_for(i, v, lo, span)
                segment.extend([x, y])
            if len(segment) >= 4:
                self.graph.create_line(*segment, fill=fill, width=2, smooth=True)

        if btc:
            draw_series(1, blo, bspan, "#4aa3ff")
        if ocr:
            draw_series(3, blo, bspan, "#5ad66f")
        if kal:
            draw_series(2, klo, kspan, "#ff9f43")

        # Horizontal base-price line on BTC axis.
        if self.base is not None and blo <= self.base <= bhi:
            by = H-pad-(H-2*pad)*(self.base-blo)/bspan
            self.graph.create_line(pad, by, W-pad, by, fill="#d9d36c", width=2, dash=(7, 4))
            self.graph.create_text(
                pad+5, by-5, text=f"BASE ${self.base:,.2f}",
                anchor="sw", fill="#d9d36c", font=("Arial",10,"bold")
            )

        self.graph.create_text(
            pad+4, 8, text=f"Coinbase ${btc[-1]:,.2f}" if btc else "Coinbase —",
            anchor="nw", fill="#4aa3ff", font=("Arial",11,"bold")
        )
        self.graph.create_text(
            W-pad-4, 8, text=f"Kalshi YES {kal[-1]*100:.1f}¢" if kal else "Kalshi —",
            anchor="ne", fill="#ff9f43", font=("Arial",11,"bold")
        )
        # BRTI OCR uses the BTC/USD axis and has its own green line.
        if ocr:
            self.graph.create_text(
                pad+180, 8, text=f"BRTI OCR ${ocr[-1]:,.2f}",
                anchor="nw", fill="#5ad66f", font=("Arial",11,"bold")
            )
        self.graph.create_text(8, H-8, text="COINBASE BTC/USD", anchor="sw", fill="#4aa3ff", font=("Arial",9))
        self.graph.create_text(W*0.5, H-8, text="BRTI OCR", anchor="s", fill="#5ad66f", font=("Arial",9))
        self.graph.create_text(W-8, H-8, text="KALSHI YES", anchor="se", fill="#ff9f43", font=("Arial",9))

    def draw_micrograph(self):
        self.micrograph.delete("all")
        depth = list(self.depth_points)
        flow = list(self.flow_points)
        if len(depth) < 2:
            return
        W = max(self.micrograph.winfo_width(), 900); H = max(self.micrograph.winfo_height(), 180)
        pad = 38
        series = [depth, flow]
        labels = [("DEPTH", "#a9e34b"), ("TRADE FLOW", "#d98cff")]
        self.micrograph.create_line(pad, H/2, W-pad, H/2, fill="#343b47")
        for arr, (label, fill), row in zip(series, labels, [0, 1]):
            pts = [(i, v) for i, (_, v) in enumerate(arr) if v is not None]
            if not pts:
                continue
            vals = [v for _, v in pts]
            lo, hi = -1.0, 1.0
            xy = []
            for i, v in pts:
                x = pad+(W-2*pad)*i/max(1,len(arr)-1)
                y = H-pad-(H-2*pad)*(v-lo)/(hi-lo)
                xy.extend([x, y])
            if len(xy) >= 4:
                self.micrograph.create_line(*xy, fill=fill, width=2, smooth=True)
            self.micrograph.create_text(
                pad+5, 8 + row*15, text=f"{label}: {vals[-1]:+.2f}",
                anchor="nw", fill=fill, font=("Arial",10,"bold")
            )
        self.micrograph.create_text(6, H/2-2, text="+", anchor="w", fill="#6f7d8c", font=("Arial",8))
        self.micrograph.create_text(6, H-6, text="-", anchor="w", fill="#6f7d8c", font=("Arial",8))

    def pause(self):
        self.paused = not self.paused

    def _scroll(self, units):
        try:
            c = self.scroll._parent_canvas
            c.yview_scroll(int(units), "units")
        except Exception:
            pass

    def _on_mousewheel(self, event):
        if getattr(event, "delta", 0):
            self._scroll(-3 if event.delta > 0 else 3)

    def quit(self):
        try:
            self.persist_session()
            save_session(
                self.session_start, self.session_total,
                self.session_correct, self.session_incorrect, self.session_id,
            )
        except Exception:
            pass
        COINBASE.stop()
        KALSHI.stop()
        BRTI_OCR.stop()
        self.destroy()


if __name__ == "__main__":
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    App().mainloop()
