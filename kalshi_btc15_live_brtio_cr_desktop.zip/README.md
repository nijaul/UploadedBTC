# BTC + Kalshi BTC 15-Minute Adaptive Desktop Engine

This Windows desktop build uses Kalshi's public API as the authoritative Kalshi source. Optional desktop OCR is included as a diagnostic/capture layer and never replaces Kalshi API data.

## Live market inputs

The program keeps **Coinbase BTC-USD** and **Kalshi BTC 15-minute prediction markets** as independent live data sources.

### Main graph
- **Blue line:** Coinbase BTC/USD live price.
- **Green line:** BRTI BTC/USD from optional desktop OCR.
- **Orange line:** Kalshi YES 15-minute contract price/probability.
- **Yellow dashed horizontal line:** **BASE BTC PRICE** for the active 15-minute contract.
- Coinbase and BRTI use the left BTC/USD axis; Kalshi uses the right cents/probability axis.
- OCR never replaces or overrides Coinbase/Kalshi API data.

The two lines are intentionally not forced onto the same numeric scale.

## Automatic Kalshi ticker discovery

No ticker is entered manually.

At startup and on rollover the program queries the public Kalshi markets endpoint, selects an active Bitcoin 15-minute market based on market metadata/timing, and switches to the next contract automatically.

The active contract's open/close timestamps drive the round lifecycle and time-remaining display.

## Kalshi data collected

For the active contract the collector attempts to obtain and continuously refresh:

- market title/subtitle
- series ticker and event ticker
- open/close/expiration time
- status/result/settlement fields when present
- YES and NO bid/ask
- last/YES price
- total volume and 24h volume when exposed
- open interest
- liquidity when exposed
- order-book levels on YES and NO
- total visible YES/NO depth
- order-book depth imbalance
- recent public trades
- trade count/size
- buy/sell trade-flow totals when side information is available
- trade-flow imbalance
- last trade timestamp
- raw market/order-book/event/series JSON for audit/forward compatibility

A secondary microstructure graph shows live order-book depth imbalance and trade-flow imbalance.

## Persistent learning

The engine stores its observations under `data/`:

- `market_engine_ticks.csv` — combined Coinbase/Kalshi time series
- `kalshi_market_snapshots.csv` — market metadata and raw JSON
- `kalshi_trades.csv` — newly observed public trades
- `kalshi_orderbook_snapshots.csv` — book levels/depth and raw JSON
- `quarter_history.csv` — completed-contract outcomes
- `session_rounds.csv` — per-round model state and Kalshi features
- `sessions.csv` — session performance
- `adaptive_predictions.csv` — completed examples used for the learner
- `adaptive_model.json` — persistent online-model weights/state

The adaptive learner updates only after a 15-minute contract has completed. It learns from:

1. Coinbase directional score
2. Kalshi YES probability
3. Kalshi bid/ask spread
4. Kalshi order-book depth imbalance
5. Kalshi trade-flow imbalance
6. Kalshi volume/activity

After enough completed examples, the learned probability is blended into the existing model forecast. This is deliberately conservative: the learned component is inactive until the configured minimum sample count is reached.

## Base price

By default the engine captures a Coinbase BTC price near the **Kalshi contract open time** and uses it as the active contract's base price.

That base is drawn as a horizontal line across the main graph.

A manual base can still be entered for research/testing. Press **Auto Base** to return control to automatic contract-open base capture.

## Windows

Run:

`RUN_ENGINE.bat`

The desktop program uses only public market-data endpoints and does not place trades.

## API note

The code is written to tolerate common Kalshi v2 response field names and saves raw payloads so the data can be inspected when schemas change. This package was produced without live web verification in the build environment, so Kalshi's current public endpoint availability/rate limits should be validated when deployed.


## Optional BRTI OCR capture

BRTI OCR can run simultaneously with the Kalshi API and Coinbase feed. It is a **third, independent live BTC/USD reference feed**.

- **Select BRTI Region** lets you drag-select the BRTI price on your desktop.
- **Start / Stop OCR** enables or disables continuous BRTI capture.
- **Capture OCR Now** performs one manual capture.
- The **green BRTI OCR line** is drawn live on the BTC/USD axis.
- The API/coinbase feeds remain authoritative for the model and adaptive learning.
- OCR observations are stored separately in `data/ocr_captures.csv` for comparison/audit.
- The selected OCR screen region is saved back to `config.json`.
- `mss`, `pytesseract`, and `Pillow` are used only for the optional OCR layer.

Configure the capture rectangle under the `ocr.region` object:

```json
"ocr": {
  "enabled": false,
  "interval_seconds": 1.0,
  "region": {
    "left": 0,
    "top": 0,
    "width": 400,
    "height": 120
  }
}
```

Set `enabled` to `true` to have OCR begin automatically at launch, or leave it false and use the desktop buttons when desired.
