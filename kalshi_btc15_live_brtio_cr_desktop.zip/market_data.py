import json
import threading
import time
from collections import deque
from pathlib import Path
from urllib.parse import urlencode
import urllib.request

try:
    import websocket
except ImportError:
    websocket = None

BASE = Path(__file__).resolve().parent
DATA = BASE.parent / "data"
DATA.mkdir(exist_ok=True)


class MarketFeed:
    def __init__(self, name, maxlen=20000):
        self.name = name
        self.lock = threading.Lock()
        self.price = self.bid = self.ask = self.last_size = None
        self.buy_volume = self.sell_volume = 0.0
        self.last_ts = 0
        self.status = "DISCONNECTED"
        self.error = ""
        self.ticks = deque(maxlen=maxlen)
        self.running = False
        self.thread = None

    def snapshot(self):
        with self.lock:
            return {
                "name": self.name,
                "price": self.price,
                "bid": self.bid,
                "ask": self.ask,
                "last_size": self.last_size,
                "buy_volume": self.buy_volume,
                "sell_volume": self.sell_volume,
                "last_ts": self.last_ts,
                "status": self.status,
                "error": self.error,
                "ticks": list(self.ticks),
            }

    def set(self, price, ts=None, bid=None, ask=None, size=None, side=None):
        if price is None:
            return
        now = int((ts or time.time()) * 1000)
        with self.lock:
            self.price = float(price)
            self.last_ts = now
            if bid is not None:
                self.bid = float(bid)
            if ask is not None:
                self.ask = float(ask)
            if size is not None:
                self.last_size = float(size)
            if side == "buy" and size is not None:
                self.buy_volume += float(size)
            elif side == "sell" and size is not None:
                self.sell_volume += float(size)
            self.ticks.append((now, float(price), side or ""))
            self.status = "LIVE"
            self.error = ""


class CoinbaseFeed(MarketFeed):
    """Public Coinbase BTC-USD market data; no trading credentials required."""
    WS_URL = "wss://advanced-trade-ws.coinbase.com"
    REST_URL = "https://api.coinbase.com/v2/prices/{product}/spot"

    def __init__(self, product="BTC-USD"):
        super().__init__("COINBASE BTC-USD")
        self.product = product

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def _rest_once(self):
        try:
            with urllib.request.urlopen(
                self.REST_URL.format(product=self.product), timeout=5
            ) as r:
                obj = json.loads(r.read().decode("utf-8"))
            amount = (obj.get("data") or {}).get("amount")
            if amount is not None:
                self.set(float(amount))
                return True
        except Exception as exc:
            with self.lock:
                self.error = str(exc)
        return False

    def _ws_loop(self):
        if websocket is None:
            raise RuntimeError("websocket-client is not installed")
        ws = websocket.create_connection(
            self.WS_URL, timeout=10, enableTrace=False,
            origin="https://www.coinbase.com",
        )
        ws.settimeout(10)
        ws.send(json.dumps({
            "type": "subscribe",
            "product_ids": [self.product],
            "channel": "ticker",
        }))
        try:
            while self.running:
                msg = ws.recv()
                if not msg:
                    continue
                data = json.loads(msg)
                for ev in data.get("events", []):
                    for t in ev.get("tickers", []):
                        if t.get("product_id") != self.product:
                            continue
                        p = t.get("price")
                        if p is not None:
                            self.set(
                                p,
                                bid=t.get("best_bid"),
                                ask=t.get("best_ask"),
                                size=t.get("last_size"),
                            )
        finally:
            try:
                ws.close()
            except Exception:
                pass

    def _loop(self):
        while self.running:
            try:
                with self.lock:
                    self.status = "CONNECTING WS"
                self._ws_loop()
            except Exception as exc:
                with self.lock:
                    self.error = str(exc)
                    self.status = "WS FAILED • REST FALLBACK"
                self._rest_once()
                for _ in range(5):
                    if not self.running:
                        return
                    time.sleep(1)



class OptionalOCRCapture:
    """
    Optional desktop-screen OCR capture.

    OCR is diagnostic/reference data only. It never feeds the Kalshi model
    or overrides the Kalshi API value. Capture can be manual or periodic.
    """
    def __init__(self, region=None, interval_seconds=1.0):
        self.region = region or {}
        self.interval_seconds = max(0.25, float(interval_seconds))
        self.enabled = False
        self.running = False
        self.last_value = None
        self.last_text = ""
        self.last_ts = None
        self.status = "OFF"
        self.error = ""
        self.thread = None
        self.lock = threading.Lock()

    @staticmethod
    def _parse_price(text):
        if not text:
            return None
        cleaned = text.replace(",", " ").replace("$", " ")
        # Common OCR forms: 64, 64¢, 0.64, $0.64, 64%
        import re
        candidates = re.findall(r"(?<!\d)(?:0?\.\d{1,4}|\d{1,3}(?:\.\d{1,3})?)(?!\d)", cleaned)
        vals = []
        for token in candidates:
            try:
                x = float(token)
            except ValueError:
                continue
            if 0 <= x <= 1:
                vals.append(x)
            elif 0 <= x <= 100:
                vals.append(x / 100.0)
        # Prefer a percentage/cents-like value over stray digits.
        return vals[-1] if vals else None

    def capture_once(self):
        try:
            import mss
            import pytesseract
            from PIL import Image, ImageOps
        except ImportError as exc:
            with self.lock:
                self.status = "OCR DEPENDENCY MISSING"
                self.error = str(exc)
            return None

        try:
            with mss.mss() as sct:
                monitor = {
                    "left": int(self.region.get("left", 0)),
                    "top": int(self.region.get("top", 0)),
                    "width": int(self.region.get("width", 400)),
                    "height": int(self.region.get("height", 120)),
                }
                shot = sct.grab(monitor)
                img = Image.frombytes("RGB", shot.size, shot.rgb)
                # Mild preprocessing improves recognition of cents / percentages.
                img = ImageOps.grayscale(img)
                img = ImageOps.autocontrast(img)
                img = img.resize((img.width * 2, img.height * 2))
                text = pytesseract.image_to_string(
                    img, config="--psm 7", timeout=2
                ).strip()
                value = self._parse_price(text)
            with self.lock:
                self.last_text = text
                self.last_value = value
                self.last_ts = time.time()
                self.error = ""
                self.status = "ON • CAPTURED" if self.enabled else "MANUAL CAPTURED"
            return value
        except Exception as exc:
            with self.lock:
                self.error = str(exc)
                self.status = "OCR ERROR"
            return None

    def start(self):
        if self.running:
            return
        self.enabled = True
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.enabled = False
        self.running = False
        with self.lock:
            self.status = "OFF"

    def toggle(self):
        if self.enabled:
            self.stop()
        else:
            self.start()

    def snapshot(self):
        with self.lock:
            return {
                "enabled": self.enabled,
                "running": self.running,
                "value": self.last_value,
                "text": self.last_text,
                "ts": self.last_ts,
                "status": self.status,
                "error": self.error,
            }

    def _loop(self):
        while self.running:
            self.capture_once()
            end = time.time() + self.interval_seconds
            while self.running and time.time() < end:
                time.sleep(0.1)



class BRTIOCRCapture:
    """
    Optional BRTI price OCR capture for the Windows desktop.

    This is an independent reference feed. It never replaces Coinbase or
    Kalshi API values and never enters the adaptive learner.
    """
    def __init__(self, region=None, interval_seconds=1.0, min_price=1000.0,
                 max_price=1000000.0, max_jump_pct=2.0):
        self.region = region or {}
        self.interval_seconds = max(0.25, float(interval_seconds))
        self.min_price = float(min_price)
        self.max_price = float(max_price)
        self.max_jump_pct = float(max_jump_pct)
        self.enabled = False
        self.running = False
        self.price = None
        self.raw = ""
        self.last_ts = None
        self.status = "OFF"
        self.error = ""
        self.reads = 0
        self.valid = 0
        self.rejected = 0
        self.history = deque(maxlen=30000)
        self.thread = None
        self.lock = threading.Lock()

    @staticmethod
    def _parse_price(text):
        if not text:
            return None
        import re
        cleaned = text.replace(",", "").replace(" ", "")
        cleaned = cleaned.translate(str.maketrans({
            "O":"0", "o":"0", "I":"1", "l":"1", "|":"1"
        }))
        # Prefer BTC/USD-style 5-7 digit values.
        matches = re.findall(r"(?<!\d)(\d{4,7}(?:\.\d{1,2})?)(?!\d)", cleaned)
        if not matches:
            return None
        try:
            return float(matches[-1])
        except ValueError:
            return None

    def set_region(self, region):
        with self.lock:
            self.region = dict(region or {})

    def capture_once(self):
        try:
            import mss
            import pytesseract
            from PIL import Image, ImageOps, ImageEnhance
        except ImportError as exc:
            with self.lock:
                self.status = "OCR DEPENDENCY MISSING"
                self.error = str(exc)
            return None

        with self.lock:
            region = dict(self.region)
        if region.get("width", 0) <= 0 or region.get("height", 0) <= 0:
            with self.lock:
                self.status = "SELECT BRTI REGION"
            return None

        try:
            with mss.mss() as sct:
                monitor = {
                    "left": int(region.get("left", 0)),
                    "top": int(region.get("top", 0)),
                    "width": int(region.get("width", 400)),
                    "height": int(region.get("height", 120)),
                }
                shot = sct.grab(monitor)
                img = Image.frombytes("RGB", shot.size, shot.rgb).convert("L")
                img = img.resize(
                    (img.width * 3, img.height * 3),
                    Image.Resampling.LANCZOS,
                )
                img = ImageOps.autocontrast(img)
                img = ImageEnhance.Sharpness(img).enhance(2.0)
                text = pytesseract.image_to_string(
                    img,
                    config="--psm 7 -c tessedit_char_whitelist=0123456789$.,OolI|"
                ).strip()
                value = self._parse_price(text)

            ok = value is not None and self.min_price <= value <= self.max_price
            with self.lock:
                if ok and self.price is not None:
                    ok = abs(value - self.price) / max(self.price, 1.0) * 100 <= self.max_jump_pct
                self.reads += 1
                now = time.time()
                if ok:
                    self.price = float(value)
                    self.raw = text.replace("\n", " ")
                    self.last_ts = now
                    self.history.append((int(now * 1000), float(value)))
                    self.valid += 1
                    self.status = "ON • BRTI LIVE"
                    self.error = ""
                else:
                    self.rejected += 1
                    self.status = "BRTI OCR rejected / waiting"
            return value if ok else None
        except Exception as exc:
            with self.lock:
                self.error = str(exc)
                self.status = "BRTI OCR ERROR"
            return None

    def start(self):
        if self.running:
            return
        self.enabled = True
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.enabled = False
        self.running = False
        with self.lock:
            self.status = "OFF"

    def snapshot(self):
        with self.lock:
            hist = list(self.history)
            return {
                "enabled": self.enabled,
                "running": self.running,
                "price": self.price,
                "raw": self.raw,
                "ts": self.last_ts,
                "status": self.status,
                "error": self.error,
                "reads": self.reads,
                "valid": self.valid,
                "rejected": self.rejected,
                "history": hist,
            }

    def _loop(self):
        while self.running:
            self.capture_once()
            deadline = time.time() + self.interval_seconds
            while self.running and time.time() < deadline:
                time.sleep(0.1)


class KalshiBTC15Feed(MarketFeed):
    """
    Public Kalshi BTC 15-minute market data collector.

    Automatically discovers the active BTC 15-minute market and refreshes:
      - market/series/event metadata when available
      - YES/NO bid/ask/last
      - order book depth on both sides
      - recent public trades
      - volume/open interest/liquidity fields when exposed
      - timing and result/settlement fields
      - raw JSON payloads for forward-compatible auditing

    No trading/authentication credentials are used.
    """
    DEFAULT_BASES = [
        "https://api.elections.kalshi.com/trade-api/v2",
        "https://api.kalshi.com/trade-api/v2",
    ]

    def __init__(self, poll_seconds=1.0, base_urls=None, depth_levels=10, trade_limit=100):
        super().__init__("KALSHI BTC 15M")
        self.poll_seconds = float(max(0.5, poll_seconds))
        self.base_urls = base_urls or self.DEFAULT_BASES
        self.base_url = self.base_urls[0]
        self.depth_levels = int(max(3, depth_levels))
        self.trade_limit = int(max(20, trade_limit))

        self.ticker = None
        self.event_ticker = None
        self.series_ticker = None
        self.title = ""
        self.subtitle = ""
        self.category = ""
        self.status_label = ""
        self.rules = ""
        self.open_time = None
        self.close_time = None
        self.expiration_time = None
        self.result = None
        self.settlement_value = None

        self.volume = None
        self.volume_24h = None
        self.open_interest = None
        self.liquidity = None

        self.yes_bid = self.yes_ask = self.no_bid = self.no_ask = None
        self.last_price = None

        self.orderbook_yes = []
        self.orderbook_no = []
        self.depth_yes_total = 0.0
        self.depth_no_total = 0.0
        self.depth_imbalance = 0.0
        self.best_bid_size = None
        self.best_ask_size = None

        self.trade_count = 0
        self.trade_buy_volume = 0.0
        self.trade_sell_volume = 0.0
        self.trade_imbalance = 0.0
        self.last_trade_ts = None
        self.recent_trades = deque(maxlen=500)

        self.series_details = {}
        self.event_details = {}
        self.raw_market = {}
        self.raw_orderbook = {}
        self.raw_trades = []
        self.raw_series = {}
        self.raw_event = {}

        self._last_discovery = 0.0
        self._discover_every = 15.0
        self._last_trade_ids = deque(maxlen=2000)
        self._last_trade_poll = 0.0
        self._metadata_ticker = None
        self._last_metadata_fetch = 0.0

    @staticmethod
    def _get(obj, *paths, default=None):
        for path in paths:
            cur = obj
            ok = True
            for part in path.split("."):
                if isinstance(cur, dict) and part in cur:
                    cur = cur[part]
                else:
                    ok = False
                    break
            if ok and cur is not None:
                return cur
        return default

    @staticmethod
    def _parse_time(v):
        if v is None:
            return None
        if isinstance(v, (int, float)):
            # Accept epoch seconds and epoch milliseconds.
            if v > 1e12:
                return float(v) / 1000.0
            if v > 1e9:
                return float(v)
            return None
        s = str(v).replace("Z", "+00:00")
        try:
            from datetime import datetime
            return datetime.fromisoformat(s).timestamp()
        except Exception:
            return None

    @staticmethod
    def _num(v, default=None):
        try:
            return float(v)
        except Exception:
            return default

    @staticmethod
    def _cents_to_prob(v):
        if v is None:
            return None
        x = KalshiBTC15Feed._num(v)
        if x is None:
            return None
        return max(0.0, min(1.0, x / 100.0 if abs(x) > 1.0 else x))

    @staticmethod
    def _is_btc_15m(m):
        blob = " ".join(
            str(m.get(k, ""))
            for k in (
                "ticker", "event_ticker", "series_ticker", "title",
                "subtitle", "category", "market_type",
            )
        ).lower()
        btc = ("bitcoin" in blob) or ("btc" in blob)
        fifteen = any(x in blob for x in (
            "15 minute", "15-minute", "15 min", "15min", "15m"
        ))
        if btc and fifteen:
            return True
        # Some Kalshi payloads expose a duration field more reliably than text.
        duration = self._num(
            self._get(m, "duration_minutes", "duration_min", "duration"),
            None,
        )
        return btc and duration is not None and 14 <= duration <= 16

    def _request_json(self, path, params=None):
        last = None
        for base in self.base_urls:
            url = base.rstrip("/") + "/" + path.lstrip("/")
            if params:
                url += "?" + urlencode(params)
            try:
                req = urllib.request.Request(
                    url,
                    headers={
                        "Accept": "application/json",
                        "User-Agent": "kalshi-btc15-desktop/2.0",
                    },
                )
                with urllib.request.urlopen(req, timeout=8) as r:
                    data = json.loads(r.read().decode("utf-8"))
                self.base_url = base
                return data
            except Exception as exc:
                last = exc
        raise RuntimeError(str(last) if last else "Kalshi request failed")

    def _discover(self):
        data = self._request_json(
            "markets", {"status": "open", "limit": 1000}
        )
        markets = data.get("markets") if isinstance(data, dict) else None
        if not isinstance(markets, list):
            raise RuntimeError("Kalshi /markets response did not contain markets[]")

        now = time.time()
        candidates = []
        for m in markets:
            if not isinstance(m, dict) or not self._is_btc_15m(m):
                continue
            open_ts = self._parse_time(
                self._get(m, "open_time", "open_ts", "open_time_ms")
            )
            close_ts = self._parse_time(
                self._get(m, "close_time", "close_ts", "close_time_ms")
            )
            if open_ts and now + 2 < open_ts:
                continue
            if close_ts and close_ts <= now:
                continue
            ticker = self._get(m, "ticker")
            if not ticker:
                continue
            # Current interval: the open contract with the nearest future close.
            close_key = close_ts if close_ts else now + 10**9
            candidates.append((close_key, ticker, m))

        if not candidates:
            raise RuntimeError("No active Kalshi BTC 15-minute market was found")
        candidates.sort(key=lambda x: x[0])
        return candidates[0][1], candidates[0][2]

    def _load_market(self, ticker):
        data = self._request_json(f"markets/{ticker}")
        return data.get("market", data)

    def _load_orderbook(self, ticker):
        data = self._request_json(f"markets/{ticker}/orderbook")
        return data.get("orderbook", data)

    def _load_trades(self, ticker):
        # Public endpoint in the v2 API family. If unavailable, market data remains usable.
        data = self._request_json(
            f"markets/{ticker}/trades",
            {"limit": self.trade_limit},
        )
        rows = data.get("trades") if isinstance(data, dict) else None
        return rows if isinstance(rows, list) else []

    def _load_event_or_series(self, ticker, event_ticker, series_ticker):
        event = {}
        series = {}
        if event_ticker:
            try:
                d = self._request_json(f"events/{event_ticker}")
                event = d.get("event", d)
            except Exception:
                event = {}
        if series_ticker:
            try:
                d = self._request_json(f"series/{series_ticker}")
                series = d.get("series", d)
            except Exception:
                series = {}
        return event, series

    def _apply_market(self, m):
        with self.lock:
            self.raw_market = m if isinstance(m, dict) else {}
            self.ticker = self._get(m, "ticker")
            self.event_ticker = self._get(m, "event_ticker")
            self.series_ticker = self._get(m, "series_ticker")
            self.title = self._get(m, "title", default="") or ""
            self.subtitle = self._get(m, "subtitle", "sub_title", default="") or ""
            self.category = self._get(m, "category", default="") or ""
            self.status_label = self._get(m, "status", "market_status", default="") or ""
            self.rules = self._get(m, "rules", "rules_primary", default="") or ""

            self.open_time = self._parse_time(
                self._get(m, "open_time", "open_ts", "open_time_ms")
            )
            self.close_time = self._parse_time(
                self._get(m, "close_time", "close_ts", "close_time_ms")
            )
            self.expiration_time = self._parse_time(
                self._get(m, "expiration_time", "expiration_ts", "expiration_time_ms")
            )
            self.result = self._get(m, "result", "market_result")
            self.settlement_value = self._get(
                m, "settlement_value", "settlement_value_cents"
            )

            self.volume = self._get(m, "volume", "volume_contracts")
            self.volume_24h = self._get(
                m, "volume_24h", "volume_24_hour", "volume_24h_contracts"
            )
            self.open_interest = self._get(
                m, "open_interest", "open_interest_contracts"
            )
            self.liquidity = self._get(
                m, "liquidity", "liquidity_dollars", "liquidity_contracts"
            )

            self.yes_bid = self._cents_to_prob(
                self._get(m, "yes_bid", "yes_bid_price")
            )
            self.yes_ask = self._cents_to_prob(
                self._get(m, "yes_ask", "yes_ask_price")
            )
            self.no_bid = self._cents_to_prob(
                self._get(m, "no_bid", "no_bid_price")
            )
            self.no_ask = self._cents_to_prob(
                self._get(m, "no_ask", "no_ask_price")
            )
            self.last_price = self._cents_to_prob(
                self._get(m, "last_price", "yes_price", "last_trade_price")
            )

    def _apply_book(self, b):
        if not isinstance(b, dict):
            return
        yes = self._get(b, "yes", "yes_bids", "yes_bids_levels", default=[])
        no = self._get(b, "no", "no_bids", "no_bids_levels", default=[])
        if not isinstance(yes, list):
            yes = []
        if not isinstance(no, list):
            no = []

        def norm(rows):
            out = []
            for row in rows:
                if isinstance(row, (list, tuple)) and len(row) >= 2:
                    price = self._cents_to_prob(row[0])
                    size = self._num(row[1])
                elif isinstance(row, dict):
                    price = self._cents_to_prob(
                        self._get(row, "price", "yes_price", "no_price")
                    )
                    size = self._num(
                        self._get(row, "count", "quantity", "size", "contracts")
                    )
                else:
                    continue
                if price is not None:
                    out.append((price, size or 0.0))
            return out[: self.depth_levels]

        y = norm(yes)
        n = norm(no)
        with self.lock:
            self.raw_orderbook = b
            self.orderbook_yes = y
            self.orderbook_no = n
            self.depth_yes_total = sum(size for _, size in y)
            self.depth_no_total = sum(size for _, size in n)
            total = self.depth_yes_total + self.depth_no_total
            self.depth_imbalance = (
                (self.depth_yes_total - self.depth_no_total) / total if total else 0.0
            )
            self.best_bid_size = y[0][1] if y else None
            self.best_ask_size = n[0][1] if n else None

            if y:
                self.yes_bid = max(p for p, _ in y)
            if n:
                self.no_bid = max(p for p, _ in n)
                self.yes_ask = min(1.0 - p for p, _ in n)
            if self.yes_bid is not None:
                self.no_ask = 1.0 - self.yes_bid

    def _apply_trades(self, trades):
        if not isinstance(trades, list):
            return
        newest = sorted(
            trades,
            key=lambda x: (
                self._parse_time(self._get(x, "created_time", "timestamp", "ts"))
                or 0
            )
        )
        with self.lock:
            self.raw_trades = trades
        for tr in newest[:100]:
            tid = self._get(tr, "trade_id", "id", "tid")
            if tid and tid in self._last_trade_ids:
                continue
            ts = self._parse_time(
                self._get(tr, "created_time", "timestamp", "ts")
            ) or time.time()
            yes_price = self._cents_to_prob(
                self._get(tr, "yes_price", "price", "last_price")
            )
            size = self._num(self._get(tr, "count", "quantity", "size", "contracts"), 0.0)
            taker = str(self._get(tr, "taker_side", "side", default="")).lower()
            # Public trade schemas can expose buy/sell as taker side or yes/no side.
            side = (
                "buy" if taker in ("buy", "yes", "bid")
                else "sell" if taker in ("sell", "no", "ask")
                else ""
            )
            with self.lock:
                self.recent_trades.append({
                    "id": tid,
                    "ts": ts,
                    "price": yes_price,
                    "size": size,
                    "side": side,
                })
                self.trade_count += 1
                if side == "buy":
                    self.trade_buy_volume += size
                elif side == "sell":
                    self.trade_sell_volume += size
                total = self.trade_buy_volume + self.trade_sell_volume
                self.trade_imbalance = (
                    (self.trade_buy_volume - self.trade_sell_volume) / total
                    if total else 0.0
                )
                self.last_trade_ts = ts
            if tid:
                self._last_trade_ids.append(tid)

    def _set_mid(self):
        with self.lock:
            p = self.last_price
            if p is None:
                if self.yes_bid is not None and self.yes_ask is not None:
                    p = (self.yes_bid + self.yes_ask) / 2.0
                elif self.yes_bid is not None:
                    p = self.yes_bid
                elif self.yes_ask is not None:
                    p = self.yes_ask
        if p is not None:
            self.set(p, bid=self.yes_bid, ask=self.yes_ask)

    def snapshot(self):
        s = super().snapshot()
        with self.lock:
            s.update({
                "ticker": self.ticker,
                "event_ticker": self.event_ticker,
                "series_ticker": self.series_ticker,
                "title": self.title,
                "subtitle": self.subtitle,
                "category": self.category,
                "status_label": self.status_label,
                "rules": self.rules,
                "open_time": self.open_time,
                "close_time": self.close_time,
                "expiration_time": self.expiration_time,
                "result": self.result,
                "settlement_value": self.settlement_value,
                "volume": self.volume,
                "volume_24h": self.volume_24h,
                "open_interest": self.open_interest,
                "liquidity": self.liquidity,
                "yes_bid": self.yes_bid,
                "yes_ask": self.yes_ask,
                "no_bid": self.no_bid,
                "no_ask": self.no_ask,
                "orderbook_yes": list(self.orderbook_yes),
                "orderbook_no": list(self.orderbook_no),
                "depth_yes_total": self.depth_yes_total,
                "depth_no_total": self.depth_no_total,
                "depth_imbalance": self.depth_imbalance,
                "best_bid_size": self.best_bid_size,
                "best_ask_size": self.best_ask_size,
                "trade_count": self.trade_count,
                "trade_buy_volume": self.trade_buy_volume,
                "trade_sell_volume": self.trade_sell_volume,
                "trade_imbalance": self.trade_imbalance,
                "last_trade_ts": self.last_trade_ts,
                "recent_trades": list(self.recent_trades),
                "series_details": dict(self.series_details),
                "event_details": dict(self.event_details),
                "raw_market": dict(self.raw_market) if isinstance(self.raw_market, dict) else {},
            })
        return s

    def _loop(self):
        while self.running:
            try:
                now = time.time()
                if self.ticker is None or now - self._last_discovery >= self._discover_every:
                    ticker, _metadata = self._discover()
                    if ticker != self.ticker:
                        with self.lock:
                            self.ticker = ticker
                            self.recent_trades.clear()
                            self._last_trade_ids.clear()
                            self.trade_count = 0
                            self.trade_buy_volume = 0.0
                            self.trade_sell_volume = 0.0
                        self.status = f"DISCOVERED {ticker}"
                    self._last_discovery = now

                if not self.ticker:
                    time.sleep(self.poll_seconds)
                    continue

                market = self._load_market(self.ticker)
                self._apply_market(market)

                event_ticker = self.event_ticker
                series_ticker = self.series_ticker
                if (
                    self.ticker != self._metadata_ticker
                    or time.time() - self._last_metadata_fetch >= 60
                ):
                    try:
                        event, series = self._load_event_or_series(
                            self.ticker, event_ticker, series_ticker
                        )
                        with self.lock:
                            self.event_details = event
                            self.series_details = series
                            self.raw_event = event if isinstance(event, dict) else {}
                            self.raw_series = series if isinstance(series, dict) else {}
                        self._metadata_ticker = self.ticker
                        self._last_metadata_fetch = time.time()
                    except Exception:
                        pass

                try:
                    self._apply_book(self._load_orderbook(self.ticker))
                except Exception:
                    pass

                # Recent trades are fetched repeatedly so cumulative flow and latest trades evolve live.
                try:
                    trades = self._load_trades(self.ticker)
                    self._apply_trades(trades)
                except Exception:
                    # Some deployments may not expose the public trades route.
                    pass

                self._set_mid()
                with self.lock:
                    if self.close_time and time.time() >= self.close_time:
                        self.ticker = None
                        self.status = "ROUND ENDED • REDISCOVERING"
                    else:
                        self.status = f"LIVE • {self.ticker}"
            except Exception as exc:
                with self.lock:
                    self.error = str(exc)
                    self.status = "KALSHI ERROR • RETRYING"
            time.sleep(self.poll_seconds)

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def seconds_left(self):
        with self.lock:
            close = self.close_time
        return max(0.0, close - time.time()) if close else None
