# BRTI UP/DOWN 15-Min Web App v8

GitHub-ready web dashboard for the BRTI UP/DOWN engine.

## Inputs
- **BRTI:** screen capture + OCR only. There is **no CME BRTI API adapter** in this project.
- **Coinbase BTC-USD:** public WebSocket market-data stream, used as the independent 50% input.
- Engine weighting remains **50% BRTI OCR / 50% Coinbase**.

## OCR capture architecture
The selected BRTI rectangle is locked to the captured source video coordinates. After selection, the source video is kept alive **off-screen** rather than being hidden with `display:none`. This avoids browsers pausing frame advancement for a hidden video element and keeps OCR independent of dashboard scrolling.

The visible dashboard shows only the selected BRTI crop while OCR is active.

## Time
The 15-minute cycle uses an absolute synchronized network-time anchor and fixed :00/:15/:30/:45 boundaries. The display clock is derived from that anchor rather than accumulating a JavaScript interval.

## Run locally
Open `index.html` from a local web server. Screen capture and WebSocket features generally work best from HTTPS or localhost.

## GitHub Pages
Upload the repository contents to the root of a GitHub repository and enable GitHub Pages from the main branch/root.
