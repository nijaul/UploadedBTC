const $=id=>document.getElementById(id);
const state={brti:null,cb:null,base:null,baseTs:null,history:[],divergence:[],ocrHistory:[],cbHistory:[],ticks:0,session:{total:0,correct:0},all:{total:0,correct:0},lastResult:'—',stream:null,ocrWorker:null,ocrWorkers:[],ocrWorkerReady:null,ocrTimer:null,region:null,ws:null,drag:null,selecting:false,clockOffsetMs:0,clockSynced:false,lastClockSync:0,clockAnchorPerf:0,clockAnchorServer:0,ocrBusy:false,ocrWorkerIndex:0,ocrLastAccepted:0,ocrCount:0,ocrRate:0,ocrRateWindow:[],lastOcrAt:0,lastNewPriceAt:0,newPriceCount:0,newPriceRate:0,newPriceWindow:[],captureFrames:0,captureRate:0,captureWindow:[],lastRecognized:null,lastOcrText:'',ocrLatency:0};
const weights=[[1000,.04,.20],[5000,.08,.20],[15000,.10,.25],[30000,.10,.35],[60000,.16,.50],[300000,.18,1],[900000,.18,1.5]];
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function now(){return state.clockSynced&&state.clockAnchorServer?state.clockAnchorServer+(performance.now()-state.clockAnchorPerf):Date.now()+state.clockOffsetMs}
async function syncClock(){
  const sent=Date.now();
  try{
    const r=await fetch('https://api.coinbase.com/v2/time?cb='+Math.random(),{cache:'no-store'});
    const received=Date.now();
    if(!r.ok)throw new Error('time '+r.status);
    const j=await r.json();
    const serverMs=Number(j?.data?.epoch)*1000 || Date.parse(j?.data?.iso||'');
    if(!Number.isFinite(serverMs))throw new Error('invalid server time');
    const midpoint=sent+(received-sent)/2;
    state.clockOffsetMs=serverMs-midpoint;
    state.clockAnchorPerf=performance.now();state.clockAnchorServer=serverMs;
    state.clockSynced=true;state.lastClockSync=Date.now();
    $('clockStatus').textContent=`SYNCED • ${state.clockOffsetMs>=0?'+':''}${state.clockOffsetMs.toFixed(0)} ms`;
  }catch(e){console.warn('Clock sync:',e);if(!state.clockSynced)$('clockStatus').textContent='LOCAL CLOCK FALLBACK'}
  render();
}
function formatPrice(v){return Number.isFinite(v)?'$'+v.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}):'—'}
function cycle(){const n=now(),q=900000;return Math.floor(n/q)*q}
function ret(hist,ms){const t=now()-ms;for(let i=hist.length-1;i>=0;i--)if(hist[i].t<=t)return hist[i].p;return null}
function score(hist){if(hist.length<2)return null;const p=hist.at(-1).p;let s=0;for(const [ms,w,scale] of weights){const old=ret(hist,ms);if(old)s+=clamp(((p/old-1)*100)/scale,-1,1)*w}const vals=hist.slice(-20).map(x=>x.p);if(vals.length>2){const mean=vals.reduce((a,b)=>a+b,0)/vals.length;const sd=Math.sqrt(vals.reduce((a,b)=>a+(b-mean)**2,0)/vals.length);if(sd>0)s+=clamp((p-mean)/sd,-2,2)*.05}return clamp(s,-1,1)}
function forecast(mix,left){if(mix==null)return null;const p=state.brti??state.cb;if(p==null)return null;const sec=Math.max(1,left/1000),scale=Math.sqrt(sec/900);return p*(1+mix*.0025*scale)}
function prob(proj,left){if(proj==null||state.base==null)return null;const sec=Math.max(1,left/1000),edge=(proj/state.base-1)*100,vol=Math.max(.08,Math.abs((state.brti??proj)/state.base-1)*100);return clamp(50+edge/Math.max(vol,.05)*12+Math.max(0,(900-sec)/900)*Math.sign(edge)*3,1,99)}
function persist(){localStorage.setItem('brti_engine_web_v13',JSON.stringify({history:state.history.slice(-5000),divergence:state.divergence.slice(-5000),session:state.session,all:state.all,lastResult:state.lastResult,base:state.base,baseTs:state.baseTs}))}
function load(){try{const x=JSON.parse(localStorage.getItem('brti_engine_web_v13')||localStorage.getItem('brti_engine_web_v12')||'null');if(x){state.history=x.history||[];state.divergence=x.divergence||[];state.session=x.session||{total:0,correct:0};state.all=x.all||{total:0,correct:0};state.lastResult=x.lastResult||'—';state.base=x.base??null;state.baseTs=x.baseTs??null}}catch(e){console.warn(e)}}
function addTick(type,p){if(!Number.isFinite(p)||p<=0)return;const t=now(),h=type==='brti'?state.ocrHistory:state.cbHistory;h.push({t,p});if(h.length>3000)h.shift();if(type==='brti')state.brti=p;else state.cb=p;state.ticks++;const last=state.history.at(-1);if(last&&Math.abs(last.t-t)<20)last[type==='brti'?'brti':'cb']=p;else state.history.push({t,brti:type==='brti'?p:state.brti,cb:type==='cb'?p:state.cb});if(state.brti!=null&&state.cb!=null)state.divergence.push({t,d:state.brti-state.cb});if(state.history.length>5000)state.history.shift();if(state.divergence.length>5000)state.divergence.shift();persist();render()}
function draw(canvas,series,mode){if(!canvas)return;const ctx=canvas.getContext('2d');const rect=canvas.getBoundingClientRect(),d=Math.max(1,devicePixelRatio||1),w=Math.max(10,Math.floor(rect.width)),h=Math.max(10,Math.floor(rect.height));if(canvas.width!==w*d||canvas.height!==h*d){canvas.width=w*d;canvas.height=h*d}ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,w,h);ctx.fillStyle='#0b1219';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#22303d';ctx.lineWidth=1;for(let i=1;i<5;i++){const y=i*h/5;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}if(!series.length){ctx.fillStyle='#7f94a5';ctx.font='13px system-ui';ctx.fillText('Waiting for live data…',16,25);return}const vals=mode==='price'?series.flatMap(x=>[x.brti,x.cb]).filter(Number.isFinite):series.map(x=>x.d).filter(Number.isFinite);if(!vals.length){ctx.fillStyle='#7f94a5';ctx.font='13px system-ui';ctx.fillText('Waiting for live data…',16,25);return}let min=Math.min(...vals),max=Math.max(...vals);if(min===max){const pad=Math.max(Math.abs(min)*.001,1);min-=pad;max+=pad}const pad=(max-min)*.12;min-=pad;max+=pad;const x=i=>series.length===1?w/2:i*(w-16)/(series.length-1)+8,y=v=>h-16-(v-min)/(max-min)*(h-32);ctx.font='11px system-ui';ctx.fillStyle='#8fa4b5';ctx.fillText(formatPrice(max),8,13);ctx.fillText(formatPrice(min),8,h-3);function line(key,stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2.5;ctx.beginPath();let started=false;series.forEach((o,i)=>{const v=o[key];if(!Number.isFinite(v)){started=false;return}const X=x(i),Y=y(v);if(!started){ctx.moveTo(X,Y);started=true}else ctx.lineTo(X,Y)});ctx.stroke()}if(mode==='price'){line('brti','#55a7ff');line('cb','#ffad52')}else{line('d','#b86cff');if(min<0&&max>0){const zy=y(0);ctx.strokeStyle='#526273';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,zy);ctx.lineTo(w,zy);ctx.stroke()}}}
function drawCharts(){draw($('priceChart'),state.history,'price');draw($('divChart'),state.divergence,'div')}
function videoContentRect(){const wrap=$('previewWrap'),v=$('preview'),wr=wrap.getBoundingClientRect();if(!v.videoWidth||!v.videoHeight)return{left:0,top:0,width:wr.width,height:wr.height};const vr=v.getBoundingClientRect(),ar=v.videoWidth/v.videoHeight,bar=vr.width/vr.height;let width=vr.width,height=vr.height,left=vr.left-wr.left,top=vr.top-wr.top;if(bar>ar){height=vr.height;width=height*ar;left+=(vr.width-width)/2}else if(bar<ar){width=vr.width;height=width/ar;top+=(vr.height-height)/2}return{left,top,width,height}}
function showRegion(r){const b=$('ocrBox');if(!r){b.style.display='none';return}const cr=videoContentRect();b.style.left=cr.left+r.x*cr.width+'px';b.style.top=cr.top+r.y*cr.height+'px';b.style.width=r.w*cr.width+'px';b.style.height=r.h*cr.height+'px';b.style.display='block'}
function setupDrag(){const wrap=$('previewWrap');if(wrap.dataset.dragReady)return;wrap.dataset.dragReady='1';const point=e=>{const cr=videoContentRect(),wr=wrap.getBoundingClientRect();return{x:clamp(e.clientX-(wr.left+cr.left),0,cr.width),y:clamp(e.clientY-(wr.top+cr.top),0,cr.height),w:cr.width,h:cr.height}};wrap.addEventListener('pointerdown',e=>{if(!state.stream||!state.selecting)return;e.preventDefault();wrap.setPointerCapture?.(e.pointerId);const p=point(e);state.drag={sx:p.x,sy:p.y,cw:p.w,ch:p.h};showRegion({x:p.x/p.w,y:p.y/p.h,w:0,h:0})});wrap.addEventListener('pointermove',e=>{if(!state.drag)return;e.preventDefault();const p=point(e),d=state.drag,x=Math.min(d.sx,p.x),y=Math.min(d.sy,p.y),w=Math.abs(p.x-d.sx),h=Math.abs(p.y-d.sy);showRegion({x:x/d.cw,y:y/d.ch,w:w/d.cw,h:h/d.ch})});const end=e=>{if(!state.drag)return;const p=point(e),d=state.drag,x=Math.min(d.sx,p.x),y=Math.min(d.sy,p.y),w=Math.abs(p.x-d.sx),h=Math.abs(p.y-d.sy);state.drag=null;if(w<10||h<8){$('regionInfo').textContent='Drag a larger box around the BRTI price';return}state.region={x:x/d.cw,y:y/d.ch,w:w/d.cw,h:h/d.ch};state.selecting=false;showRegion(state.region);$('regionInfo').textContent='Selected BRTI price region';$('status').textContent='OCR STARTING…';switchToCropPreview();runOCR()};wrap.addEventListener('pointerup',end);wrap.addEventListener('pointercancel',end)}
function selectRegion(){if(!state.stream){$('regionInfo').textContent='Start BRTI OCR first';return}const v=$('preview'),c=$('cropPreview');v.style.display='block';c.style.display='none';setupDrag();state.selecting=true;$('status').textContent='DRAG A BOX AROUND BRTI PRICE';$('regionInfo').textContent='Drag directly over the BRTI price in the preview';$('dragHint').style.display='flex';$('ocrBox').style.display='none'}
async function startOCR(){try{if(!navigator.mediaDevices?.getDisplayMedia)throw new Error('Screen capture is not supported in this browser.');if(state.stream)stopOCR();state.stream=await navigator.mediaDevices.getDisplayMedia({video:{frameRate:{ideal:15,max:30},width:{ideal:1920},height:{ideal:1080}},audio:false});const v=$('preview');v.srcObject=state.stream;v.muted=true;v.playsInline=true;v.style.position='';v.style.left='';v.style.top='';v.style.width='';v.style.height='';v.style.opacity='';v.style.pointerEvents='';v.style.display='block';$('cropPreview').style.display='none';setupDrag();state.stream.getVideoTracks()[0].addEventListener('ended',stopOCR);await waitVideo();$('ocrStatus').textContent='SCREEN CAPTURE READY';selectRegion()}catch(e){$('status').textContent='OCR ERROR';$('regionInfo').textContent=e.message||'Screen capture cancelled';console.error(e)}}
function waitVideo(){return new Promise(resolve=>{const v=$('preview');if(v.readyState>=2&&v.videoWidth)resolve();else v.onloadedmetadata=()=>resolve()})}
function stopOCR(){if(state.ocrTimer)clearTimeout(state.ocrTimer);state.ocrTimer=null;if(state.stream)state.stream.getTracks().forEach(t=>t.stop());state.stream=null;state.region=null;state.selecting=false;state.captureWindow=[];state.captureRate=0;state.newPriceWindow=[];state.newPriceRate=0;const v=$('preview');v.srcObject=null;v.style.position='';v.style.left='';v.style.top='';v.style.width='';v.style.height='';v.style.opacity='';v.style.pointerEvents='';v.style.display='none';$('cropPreview').style.display='none';$('ocrBox').style.display='none';$('ocrStatus').textContent='OCR OFF';$('status').textContent='READY';$('regionInfo').textContent='No region selected';$('dragHint').style.display='flex'}
async function ensureOCRWorker(){
  if(state.ocrWorkers.length)return state.ocrWorkers;
  if(state.ocrWorkerReady)return state.ocrWorkerReady;
  if(!window.Tesseract)throw new Error('Tesseract.js failed to load.');
  state.ocrWorkerReady=(async()=>{
    const make=async()=>{
      const w=await Tesseract.createWorker('eng',1,{logger:m=>{}});
      await w.setParameters({tessedit_char_whitelist:'0123456789.,$',tessedit_pageseg_mode:'7',preserve_interword_spaces:'0',classify_bln_numeric_mode:'1'});
      return w;
    };
    state.ocrWorkers=await Promise.all([make(),make()]);
    state.ocrWorker=state.ocrWorkers[0];
    return state.ocrWorkers;
  })();
  return state.ocrWorkerReady;
}

function cropCanvas(){const v=$('preview'),out=$('cropPreview'),r=state.region;if(!v.videoWidth||!r)return null;const rx=Math.max(0,Math.floor(r.x*v.videoWidth)),ry=Math.max(0,Math.floor(r.y*v.videoHeight)),rw=Math.min(v.videoWidth-rx,Math.max(20,Math.floor(r.w*v.videoWidth))),rh=Math.min(v.videoHeight-ry,Math.max(14,Math.floor(r.h*v.videoHeight)));out.width=rw;out.height=rh;const ctx=out.getContext('2d',{willReadFrequently:true});ctx.drawImage(v,rx,ry,rw,rh,0,0,rw,rh);return out}
function preprocess(src){const c=document.createElement('canvas');c.width=src.width*2;c.height=src.height*2;const x=c.getContext('2d',{willReadFrequently:true});x.imageSmoothingEnabled=false;x.drawImage(src,0,0,c.width,c.height);const img=x.getImageData(0,0,c.width,c.height),d=img.data;for(let i=0;i<d.length;i+=4){const g=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];const v=g>150?255:g<85?0:g;d[i]=d[i+1]=d[i+2]=v}x.putImageData(img,0,0);return c}
function acceptOCR(p){
  if(!Number.isFinite(p)||p<1000||p>1000000)return false;
  const previous=state.brti;
  state.lastRecognized=p;
  const changed=previous==null || Math.abs(p-previous)>=0.01;
  if(previous!=null && Math.abs(p-previous)>Math.max(250,previous*.01)) return false;
  addTick('brti',p);
  const t=performance.now();
  state.ocrCount++;
  state.ocrRateWindow.push(t);
  state.lastOcrAt=Date.now();
  if(changed){
    state.ocrLastAccepted=t;
    state.newPriceCount++;
    state.newPriceWindow.push(t);
    state.lastNewPriceAt=Date.now();
  }
  state.ocrRateWindow=state.ocrRateWindow.filter(x=>t-x<10000);
  state.newPriceWindow=state.newPriceWindow.filter(x=>t-x<10000);
  state.ocrRate=state.ocrRateWindow.length/10;
  state.newPriceRate=state.newPriceWindow.length/10;
  return changed;
}
function updateCaptureRate(){
  const t=performance.now();
  state.captureWindow.push(t);
  state.captureWindow=state.captureWindow.filter(x=>t-x<1000);
  state.captureRate=state.captureWindow.length;
  state.captureFrames++;
}

async function runOCR(){
  if(!state.stream||!state.region||state.ocrBusy)return;
  state.ocrBusy=true;
  const started=performance.now();
  try{
    updateCaptureRate();
    const workers=await ensureOCRWorker();
    const rawCanvas=cropCanvas();
    if(!rawCanvas)throw new Error('No video frame');
    $('cropPreview').style.display='block';
    const processed=preprocess(rawCanvas);
    const worker=workers[state.ocrWorkerIndex++%workers.length];
    const res=await worker.recognize(processed);
    const raw=(res.data.text||'').trim();
    state.lastOcrText=raw;
    const nums=(raw.replace(/,/g,'').match(/\$?\s*(\d{2,7}(?:\.\d{1,2})?)/g)||[])
      .map(s=>parseFloat(s.replace(/[^0-9.]/g,'')))
      .filter(p=>p>=1000&&p<=1000000);
    const changed=nums.length?acceptOCR(nums[0]):false;
    state.ocrLatency=performance.now()-started;
    const t=performance.now();
    state.ocrRateWindow=state.ocrRateWindow.filter(x=>t-x<10000);
    state.newPriceWindow=state.newPriceWindow.filter(x=>t-x<10000);
    state.ocrRate=state.ocrRateWindow.length/10;
    state.newPriceRate=state.newPriceWindow.length/10;
    const age=state.lastNewPriceAt?Math.round(Date.now()-state.lastNewPriceAt):null;
    $('ocrDetail').textContent=`CAP ${state.captureRate.toFixed(0)}fps • OCR ${state.ocrRate.toFixed(1)}/s • NEW ${state.newPriceRate.toFixed(1)}/s • LAT ${Math.round(state.ocrLatency)}ms • ${age==null?'no new price':age+'ms ago'}`;
    $('ocrStatus').textContent=changed?'NEW PRICE':'OCR LIVE';
    $('status').textContent=changed?'OCR NEW PRICE':'OCR LIVE';
  }catch(e){
    console.warn('OCR:',e);
    $('status').textContent='OCR RETRYING';
    $('ocrStatus').textContent='OCR ERROR';
  }finally{state.ocrBusy=false}
  if(state.stream&&state.region)state.ocrTimer=setTimeout(runOCR,Math.max(80,Number($('interval').value)||200));
}

function connectCoinbase(){if(state.ws)return;try{const ws=new WebSocket('wss://advanced-trade-ws.coinbase.com');state.ws=ws;ws.onopen=()=>{$('cbStatus').textContent='LIVE';ws.send(JSON.stringify({type:'subscribe',product_ids:['BTC-USD'],channel:'ticker'}))};ws.onmessage=e=>{try{const d=JSON.parse(e.data);for(const ev of d.events||[])for(const t of ev.tickers||[])if(t.product_id==='BTC-USD'){const p=Number(t.price);if(Number.isFinite(p))addTick('cb',p)}}catch{}};ws.onerror=()=>{try{ws.close()}catch{}};ws.onclose=()=>{state.ws=null;$('cbStatus').textContent='RECONNECTING…';setTimeout(connectCoinbase,3000)}}catch{state.ws=null;setTimeout(connectCoinbase,3000)}}
async function fallbackCoinbase(){try{const r=await fetch('https://api.coinbase.com/v2/prices/BTC-USD/spot?cb='+Math.random(),{cache:'no-store'});if(!r.ok)throw new Error('REST '+r.status);const j=await r.json(),p=Number(j?.data?.amount);if(Number.isFinite(p))addTick('cb',p)}catch(e){console.warn('Coinbase fallback:',e)}}
function render(){
  const n=now(), end=cycle()+900000, left=end-n;
  $('clockValue').textContent=new Date(n).toLocaleTimeString();
  $('clockStatus').textContent=state.clockSynced ? `SYNCED • ${state.clockOffsetMs>=0?'+':''}${state.clockOffsetMs.toFixed(0)} ms` : 'LOCAL CLOCK FALLBACK';
  $('time').textContent=`${Math.max(0,Math.floor(left/60000)).toString().padStart(2,'0')}:${Math.max(0,Math.floor((left%60000)/1000)).toString().padStart(2,'0')}`;
  $('cycle').textContent=new Date(cycle()).toLocaleTimeString();
  $('brti').textContent=formatPrice(state.brti); $('coinbase').textContent=formatPrice(state.cb);
  if(state.brti!=null&&state.cb!=null){const d=state.brti-state.cb;$('diff').textContent=(d>=0?'+':'-')+formatPrice(Math.abs(d));$('diffPct').textContent=(d/state.cb*100).toFixed(4)+'%';$('divNow').textContent=(d>=0?'+':'-')+formatPrice(Math.abs(d));}
  else {$('diff').textContent='—';$('diffPct').textContent='—';$('divNow').textContent='—';}
  const os=score(state.ocrHistory),cs=score(state.cbHistory),mix=(os!=null&&cs!=null)?0.5*os+0.5*cs:null;
  $('ocrScore').textContent=os==null?'—':os.toFixed(3); $('cbScore').textContent=cs==null?'—':cs.toFixed(3); $('mixScore').textContent=mix==null?'—':mix.toFixed(3)+' • 50/50';
  const proj=forecast(mix,left),p=prob(proj,left);
  $('base').textContent=formatPrice(state.base); $('baseTime').textContent=state.baseTs?new Date(state.baseTs).toLocaleTimeString():'not set';
  const input=$('baseInput'); if(document.activeElement!==input) input.value=state.base??'';
  $('forecast').textContent=formatPrice(proj);
  if(proj!=null&&state.base!=null){const d=proj-state.base;$('vsBase').textContent=`${d>=0?'+':''}$${d.toFixed(2)} (${(d/state.base*100).toFixed(3)}%)`;$('direction').textContent=d>0?'UP':d<0?'DOWN':'FLAT';}
  else {$('vsBase').textContent='—';$('direction').textContent='—';}
  let sig='WAITING',edge='—';
  if(p!=null){const up=p/100,down=1-up;if(proj>state.base&&up-.5>=.03){sig='BUY UP';edge=`+${(up-.5).toFixed(3)}`;}else if(proj<state.base&&down-.5>=.03){sig='BUY DOWN';edge=`+${(down-.5).toFixed(3)}`;}}
  $('prob').textContent=p==null?'—':p.toFixed(1)+'%'; $('signal').textContent=sig; $('edge').textContent=edge;
  $('confidence').textContent=mix==null?'—':`${Math.round(50+Math.abs(mix)*45)}%`;
  $('session').textContent=`${state.session.correct}/${state.session.total}`; $('alltime').textContent=`${state.all.correct}/${state.all.total}`; $('lastResult').textContent=state.lastResult; $('ticks').textContent=state.ticks;
  $('ocrStatus').textContent=state.stream?(state.region?'OCR LIVE':'SELECT REGION'):'OCR OFF'; if(state.stream&&state.region){const age=state.lastNewPriceAt?Math.round(Date.now()-state.lastNewPriceAt):null; $('ocrDetail').textContent=`CAP ${state.captureRate.toFixed(0)}fps • OCR ${state.ocrRate.toFixed(1)}/s • NEW ${state.newPriceRate.toFixed(1)}/s • ${age==null?'no new price':age+'ms ago'}`;} $('cbStatus').textContent=state.cb?'LIVE':(state.ws?'CONNECTED':'DISCONNECTED');
  drawCharts();
}
function switchToCropPreview(){const v=$('preview'),c=$('cropPreview');
  // Keep the capture video actively rendering off-screen. Do NOT use display:none: some browsers stop advancing hidden video frames, which can freeze OCR.
  v.style.position='fixed';v.style.left='-10000px';v.style.top='0';v.style.width='2px';v.style.height='2px';v.style.opacity='0.01';v.style.pointerEvents='none';v.style.display='block';
  c.style.display='block';$('dragHint').style.display='none';$('ocrBox').style.display='none';
}
$('startScreen').onclick=startOCR;
$('stopScreen').onclick=stopOCR;
$('selectRegion').onclick=selectRegion;
$('setBase').onclick=()=>{if(state.brti!=null){state.base=state.brti;state.baseTs=now();$('baseInput').value=state.base;persist();render();}};
$('clearBase').onclick=()=>{state.base=null;state.baseTs=null;$('baseInput').value='';persist();render();};
$('applyBase').onclick=()=>{const p=parseFloat(String($('baseInput').value).replace(/,/g,''));if(Number.isFinite(p)&&p>0){state.base=p;state.baseTs=now();$('baseInput').value=p;persist();render();}else $('baseInput').focus();};
$('baseInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('applyBase').click();}});
$('exportCsv').onclick=()=>{const rows=[['timestamp','brti_ocr','coinbase_btcusd','difference','difference_pct']];state.history.forEach(x=>rows.push([new Date(x.t).toISOString(),x.brti??'',x.cb??'',x.brti!=null&&x.cb!=null?x.brti-x.cb:'',x.brti!=null&&x.cb!=null?(x.brti-x.cb)/x.cb:'']));const blob=new Blob([rows.map(r=>r.join(',')).join('\n')],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='brti_coinbase_history.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
window.addEventListener('resize',()=>{drawCharts();if(state.region&&!state.selecting)showRegion(state.region);});
load(); syncClock(); fallbackCoinbase(); connectCoinbase();
setInterval(()=>{if(Date.now()-state.lastClockSync>30000)syncClock();},10000);
setInterval(render,250); render();
