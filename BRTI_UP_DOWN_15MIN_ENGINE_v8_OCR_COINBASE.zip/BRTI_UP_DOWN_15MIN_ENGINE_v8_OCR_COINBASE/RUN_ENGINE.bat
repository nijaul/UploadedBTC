@echo off
cd /d "%~dp0"
py app\engine.py
if errorlevel 1 pause
