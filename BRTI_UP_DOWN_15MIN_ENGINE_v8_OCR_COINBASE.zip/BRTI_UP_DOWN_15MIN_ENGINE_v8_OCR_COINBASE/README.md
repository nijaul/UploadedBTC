# BRTI UP/DOWN 15-Minute Engine — OCR + Coinbase 50/50

This build uses **BRTI screen OCR as the BRTI source**. There is **NO CME BRTI API adapter, NO CME BRTI WebSocket, and NO BRTI API fallback** in this build.

## Two live price streams

- **BRTI OCR (50%)** — the selected screen region remains the BRTI input.
- **Coinbase BTC-USD (50%)** — public Coinbase market data is collected independently.

When both streams are live, the directional engine combines them **exactly 50% OCR + 50% Coinbase**. Coinbase never replaces, overrides, or takes priority over OCR. If Coinbase is temporarily unavailable, the dashboard clearly shows that the second 50% input is unavailable rather than silently treating Coinbase as the preferred source.

## Live detailed graph

- **Blue line = BRTI OCR**
- **Orange line = Coinbase BTC-USD**
- The main graph continuously plots both prices.
- A separate purple graph plots **BRTI OCR − Coinbase** so the divergence is visible.
- The dashboard displays OCR score, Coinbase score, and the combined 50/50 score.

## Coinbase connection

The app uses the public Coinbase Advanced Trade market-data WebSocket. If that WebSocket is blocked by a firewall, proxy, DNS filter, or local network, the app uses Coinbase's public BTC-USD spot-price REST endpoint as a market-price fallback. No Coinbase trading/API credentials are required.

## Scrolling

The dashboard uses a scrollable frame with global Windows mouse-wheel, trackpad, and legacy wheel-button bindings. The scroll increment is increased so a 1920×1080 display can move through the entire dashboard.

## Session logging

Completed 15-minute rounds continue to be written immediately to:
- `data/brti_quarter_history.csv`
- `data/brti_session_rounds.csv`
- `data/brti_sessions.csv`
- `data/brti_engine_ticks.csv`
- `data/up_contract_ticks.csv`

## Important

This is a research/prototype analytics engine, not a validated probability or order-execution system. The 50/50 weighting is an explicit model rule and should be validated using the logged outcomes before real-money use.
