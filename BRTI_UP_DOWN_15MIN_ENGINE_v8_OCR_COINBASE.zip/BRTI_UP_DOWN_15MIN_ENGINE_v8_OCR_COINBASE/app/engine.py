import csv,json,math,re,time,threading,tkinter as tk
from statistics import mean
from pathlib import Path
from collections import deque
import customtkinter as ctk
import mss,pytesseract
from PIL import Image,ImageOps,ImageEnhance
from market_data import CoinbaseFeed

BASE=Path(__file__).resolve().parent
CFG=json.loads((BASE/"config.json").read_text())
if CFG.get("tesseract_cmd"): pytesseract.pytesseract.tesseract_cmd=CFG["tesseract_cmd"]
DATA=BASE.parent/"data";DATA.mkdir(exist_ok=True);CSV=DATA/"brti_engine_ticks.csv"
HIST=DATA/"brti_quarter_history.csv"
HIST_FIELDS=["quarter_start_iso","base","price_open","proj_open","score_open","direction_open",
             "price_close","direction_actual","correct"]
SESSION_CSV=DATA/"brti_sessions.csv"
SESSION_ROUNDS_CSV=DATA/"brti_session_rounds.csv"
SESSION_FIELDS=["session_id","session_start","session_end","quarters","correct","incorrect","hit_rate"]
ROUND_FIELDS=["session_id","quarter_start_iso","quarter_end_iso","base_price","price_open","price_close","forecast_open","momentum_score","model_prob_up","up_price","down_price","signal","direction_called","direction_actual","correct","edge_up","edge_down","confidence"]
MIN_GRADED_FOR_CALIB=CFG.get("min_graded_for_calibration",20)
CALIB_CAP=CFG.get("calibration_cap",1.5)

def hist_append(row):
 new=not HIST.exists() or HIST.stat().st_size==0
 with open(HIST,"a",newline="",encoding="utf-8") as f:
  w=csv.DictWriter(f,fieldnames=HIST_FIELDS)
  if new:w.writeheader()
  w.writerow(row)

def hist_load(n=500):
 if not HIST.exists():return []
 with open(HIST,newline="",encoding="utf-8") as f:
  rows=list(csv.DictReader(f))
 return rows[-n:]

CONTRACT_MIN=CFG.get("contract_min",0.0)
CONTRACT_MAX=CFG.get("contract_max",1.0)
CONTRACT_MAX_JUMP=CFG.get("contract_max_jump_abs",0.20)
MIN_EDGE=CFG.get("min_edge_dollars",0.03)
COINBASE=CoinbaseFeed(CFG.get("exchange_product","BTC-USD"))

def parse_contract(t):
 # Handles "$0.62", "0.62", "62", "62¢" style OCR reads of a Yes/No
 # contract price and normalizes to a dollar fraction between 0 and 1.
 s=t.replace(",","").replace(" ","").strip()
 s=s.translate(str.maketrans({"O":"0","o":"0","I":"1","l":"1","|":"1"}))
 s=s.replace("¢","").replace("%","").replace("$","")
 m=re.search(r"(\d{1,3}(?:\.\d{1,2})?)",s)
 if not m:return None
 v=float(m.group(1))
 return round(v/100,4) if v>1.5 else round(v,4)

class ContractReader:
 def __init__(self,name,csv_path):
  self.name=name;self.region=None;self.running=False;self.paused=False
  self.price=None;self.raw="";self.last_ts=0;self.reads=self.valid=self.rejected=0
  self.lock=threading.Lock();self.status=f"Select {name} region"
  self.f=open(csv_path,"a",newline="",encoding="utf-8");self.w=csv.writer(self.f)
  if csv_path.stat().st_size==0:self.w.writerow(["timestamp_ms","price","ocr_text","accepted"])
 def set_region(self,r):
  self.region=r
  if not self.running:self.running=True;threading.Thread(target=self.loop,daemon=True).start()
 def stop(self):
  self.running=False
  try:self.f.close()
  except:pass
 def loop(self):
  with mss.mss() as sct:
   while self.running:
    t0=time.perf_counter()
    if self.region and not self.paused:
     try:
      sh=sct.grab(self.region);im=Image.frombytes("RGB",sh.size,sh.rgb).convert("L")
      im=im.resize((im.width*3,im.height*3),Image.Resampling.LANCZOS);im=ImageOps.autocontrast(im);im=ImageEnhance.Sharpness(im).enhance(2)
      txt=pytesseract.image_to_string(im,config="--psm 7 -c tessedit_char_whitelist=0123456789$.,%¢OolI|")
      v=parse_contract(txt);self.reads+=1;ok=False
      if v is not None and CONTRACT_MIN<=v<=CONTRACT_MAX and (self.price is None or abs(v-self.price)<=CONTRACT_MAX_JUMP):ok=True
      now=int(time.time()*1000)
      if ok:
       with self.lock:self.price=v;self.raw=txt.strip().replace("\n"," ");self.last_ts=now;self.valid+=1
       self.status=f"LIVE • reading {self.name}"
      else:self.rejected+=1;self.status=f"OCR rejected / waiting ({self.name})"
      self.w.writerow([now,v if v is not None else "",txt.strip(),int(ok)]);self.f.flush()
     except Exception:self.status=f"OCR error ({self.name})"
    time.sleep(max(0,(CFG["capture_interval_ms"]-(time.perf_counter()-t0)*1000)/1000))
 def snap(self):
  with self.lock:p=self.price;ts=self.last_ts;raw=self.raw
  return {"price":p,"ts":ts,"raw":raw,"reads":self.reads,"valid":self.valid,"rejected":self.rejected,
          "status":self.status,"age":int(time.time()*1000-ts) if ts else None}

UP=ContractReader("UP contract",DATA/"up_contract_ticks.csv")

class Engine:
 def __init__(self):
  self.region=None;self.running=False;self.paused=False;self.price=None;self.raw="";self.last_ts=0
  self.reads=self.valid=self.rejected=0;self.h=deque(maxlen=30000);self.lock=threading.Lock()
  self.status="Select BRTI price region"
  self.f=open(CSV,"a",newline="",encoding="utf-8");self.w=csv.writer(self.f)
  if CSV.stat().st_size==0:self.w.writerow(["timestamp_ms","price","ocr_text","accepted"])
 def set_region(self,r):
  self.region=r
  if not self.running:self.running=True;threading.Thread(target=self.loop,daemon=True).start()
 def stop(self):
  self.running=False
  try:self.f.close()
  except:pass
 def parse(self,t):
  s=t.replace(",","").replace("$","").replace(" ","").strip()
  s=s.translate(str.maketrans({"O":"0","o":"0","I":"1","l":"1","|":"1"}))
  m=re.search(r"(\d{2,7}(?:\.\d{1,4})?)",s);return float(m.group(1)) if m else None
 def loop(self):
  with mss.mss() as sct:
   while self.running:
    t0=time.perf_counter()
    if self.region and not self.paused:
     try:
      sh=sct.grab(self.region);im=Image.frombytes("RGB",sh.size,sh.rgb).convert("L")
      im=im.resize((im.width*3,im.height*3),Image.Resampling.LANCZOS);im=ImageOps.autocontrast(im);im=ImageEnhance.Sharpness(im).enhance(2)
      txt=pytesseract.image_to_string(im,config="--psm 7 -c tessedit_char_whitelist=0123456789$,.OolI|")
      v=self.parse(txt);self.reads+=1;ok=False
      if v is not None and CFG["min_price"]<=v<=CFG["max_price"] and (self.price is None or abs(v-self.price)/self.price*100<=CFG["max_jump_pct"]):ok=True
      now=int(time.time()*1000)
      if ok:
       with self.lock:self.price=v;self.raw=txt.strip().replace("\n"," ");self.last_ts=now;self.h.append((now,v));self.valid+=1
       self.status="LIVE • reading BRTI"
      else:self.rejected+=1;self.status="OCR rejected / waiting"
      self.w.writerow([now,v or "",txt.strip(),int(ok)]);self.f.flush()
     except Exception:self.status="OCR error"
    time.sleep(max(0,(CFG["capture_interval_ms"]-(time.perf_counter()-t0)*1000)/1000))
 def snap(self):
  with self.lock:h=list(self.h);p=self.price;ts=self.last_ts;raw=self.raw
  def ret(ms):
   if not p or not h:return None
   old=next((v for t,v in reversed(h) if t<=ts-ms),None)
   return None if old is None else (p/old-1)*100
  w=[v for t,v in h if t>=ts-60000];rr=[w[i]/w[i-1]-1 for i in range(1,len(w))] if len(w)>1 else []
  vol=math.sqrt(sum(x*x for x in rr)/len(rr))*100 if rr else None;pers=sum(x>0 for x in rr)/len(rr)*100 if rr else None
  r5=ret(5000);r15=ret(15000);vel=None if r5 is None else r5/5;acc=None if vel is None or r15 is None else (vel-r15/15)/10
  # Trend slope in percent per minute from a 60s linear regression.
  slope=None
  if len(h)>=8:
   pts=[(t,v) for t,v in h if t>=ts-60000]
   if len(pts)>=8:
    t0=pts[0][0];xs=[(t-t0)/60000 for t,v in pts];ys=[v for t,v in pts];mx=mean(xs);my=mean(ys);den=sum((a-mx)**2 for a in xs)
    slope=(sum((a-mx)*(b-my) for a,b in zip(xs,ys))/den/my*100) if den and my else None
  # RSI-like momentum on 1-minute samples, bounded 0..100.
  rsi=None
  if len(rr)>=14:
   gains=[max(z,0) for z in rr[-14:]];loss=[-min(z,0) for z in rr[-14:]];ag=mean(gains);al=mean(loss);rsi=100 if al==0 else 100-(100/(1+ag/al))
  hi=max(w) if w else p;lo=min(w) if w else p;range_pos=((p-lo)/(hi-lo)) if hi and lo and hi>lo else .5
  return {"price":p,"ts":ts,"raw":raw,"reads":self.reads,"valid":self.valid,"rejected":self.rejected,
          "ret":{m:ret(m) for m in [1000,5000,15000,30000,60000,300000,900000]},"vol":vol,"pers":pers,"vel":vel,"acc":acc,
          "slope":slope,"rsi":rsi,"range_pos":range_pos,"high":hi,"low":lo,"status":self.status,"age":int(time.time()*1000-ts) if ts else None,"history":h}
E=Engine()

class Selector(tk.Toplevel):
 def __init__(self,master,done,label="Drag a box around the target, then press Enter"):
  super().__init__(master);self.done=done;self.attributes("-fullscreen",True);self.attributes("-alpha",.25);self.configure(bg="black")
  self.c=tk.Canvas(self,bg="black",highlightthickness=0,cursor="crosshair");self.c.pack(fill="both",expand=True);self.s=None;self.e=None;self.r=None
  self.c.create_text(40,30,anchor="nw",text=label,fill="white",font=("Arial",22,"bold"))
  self.c.create_text(40,60,anchor="nw",text="Enter = confirm   Esc = cancel",fill="#aaaaaa",font=("Arial",13))
  self.c.bind("<ButtonPress-1>",self.down);self.c.bind("<B1-Motion>",self.move);self.c.bind("<ButtonRelease-1>",self.up);self.bind("<Return>",self.accept);self.bind("<Escape>",lambda e:self.destroy());self.focus_force()
 def down(self,e):self.s=(e.x_root,e.y_root)
 def move(self,e):
  if self.s:
   if self.r:self.c.delete(self.r)
   self.r=self.c.create_rectangle(*self.s,e.x_root,e.y_root,outline="red",width=3)
 def up(self,e):self.e=(e.x_root,e.y_root)
 def accept(self,e=None):
  if self.s and self.e:
   x,y=self.s;X,Y=self.e;r={"left":min(x,X),"top":min(y,Y),"width":abs(X-x),"height":abs(Y-y)}
   if r["width"]>5 and r["height"]>5:self.done(r)
  self.destroy()

def save_session(start, total, correct, incorrect, session_id):
 new=not SESSION_CSV.exists() or SESSION_CSV.stat().st_size==0
 with open(SESSION_CSV,"a",newline="",encoding="utf-8") as f:
  w=csv.DictWriter(f,fieldnames=SESSION_FIELDS)
  if new:w.writeheader()
  w.writerow({"session_id":session_id,"session_start":time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(start)),"session_end":time.strftime("%Y-%m-%d %H:%M:%S"),"quarters":total,"correct":correct,"incorrect":incorrect,"hit_rate":(correct/total if total else "")})

def append_session_round(row):
 new=not SESSION_ROUNDS_CSV.exists() or SESSION_ROUNDS_CSV.stat().st_size==0
 with open(SESSION_ROUNDS_CSV,"a",newline="",encoding="utf-8") as f:
  w=csv.DictWriter(f,fieldnames=ROUND_FIELDS)
  if new:w.writeheader()
  w.writerow(row)

class App(ctk.CTk):
 def __init__(self):
  super().__init__();self.title("BRTI → 15-Min UP/DOWN Engine");self.geometry("1000x850");self.minsize(820,600);self.protocol("WM_DELETE_WINDOW",self.quit)
  self.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
  self.bind_all("<Shift-MouseWheel>", self._on_mousewheel, add="+")
  self.bind_all("<Button-4>", lambda e: self._scroll(-3), add="+")
  self.bind_all("<Button-5>", lambda e: self._scroll(3), add="+")
  self.base=None;self.base_ts=None
  self.q_start=None;self.q_open=None;self.last_result=None
  self.up_override=None;self.up_capture_enabled=True
  self.last_boundary_price=None
  self.graph_points=deque(maxlen=900)
  self.score_history=deque(maxlen=300)
  self.session_total=0;self.session_correct=0;self.session_incorrect=0
  self.session_start=time.time()
  self.session_id=time.strftime("%Y%m%d_%H%M%S",time.localtime(self.session_start))
  COINBASE.start()
  self.calib=1.0;self.hitrate=None;self.hitn=0
  self.p=ctk.StringVar(value="—");self.d=ctk.StringVar(value="SET BASE PRICE");self.prob=ctk.StringVar(value="—");self.clock=ctk.StringVar(value="—")
  self.baselbl=ctk.StringVar(value="not set");self.projp=ctk.StringVar(value="—");self.vsbase=ctk.StringVar(value="—")
  self.hitlbl=ctk.StringVar(value="no graded quarters yet");self.calibvar=ctk.StringVar(value="×1.00 (inactive)");self.lastq=ctk.StringVar(value="—")
  self.upvar=ctk.StringVar(value="—");self.modelprob=ctk.StringVar(value="—")
  self.signal=ctk.StringVar(value="WAITING FOR DATA");self.edgevar=ctk.StringVar(value="—")
  self.upoverride=ctk.StringVar(value="");self.up_status=ctk.StringVar(value="UP capture active")
  self.sessionlbl=ctk.StringVar(value="0 / 0 correct");self.alltimelbl=ctk.StringVar(value="0 / 0 correct");self.confvar=ctk.StringVar(value="—")
  self.ocr_scorev=ctk.StringVar(value="—");self.coin_scorev=ctk.StringVar(value="—");self.mix_scorev=ctk.StringVar(value="—")
  self.scroll=ctk.CTkScrollableFrame(self, fg_color="transparent")
  self.scroll.pack(fill="both",expand=True,padx=4,pady=4)
  self._content=self.scroll
  self.make();self.recompute_calibration();self.update_all_time();self.after(250,self.refresh)
  self.bind("<F5>",lambda e:self.select_brti());self.bind("<F6>",lambda e:self.select_up());self.bind("<F7>",lambda e:self.resume_up())
  self.bind("<F8>",lambda e:self.select_all());self.bind("<F9>",lambda e:self.pause());self.bind("<F10>",lambda e:self.quit())
  self.select_all()
 def make(self):
  ctk.CTkLabel(self._content,text="₿ BRTI → 15-MINUTE ENGINE",font=("Arial",25,"bold")).pack(pady=(16,3))
  ctk.CTkLabel(self._content,text="Screen OCR → validated price stream → directional forecast vs your base price",text_color="#8b98a9").pack()
  ctk.CTkLabel(self._content,textvariable=self.p,font=("Arial",45,"bold")).pack(pady=10)
  bf=ctk.CTkFrame(self._content);bf.pack(fill="x",padx=18,pady=(0,8))
  ctk.CTkLabel(bf,text="Base price:").pack(side="left",padx=(8,4))
  self.base_entry=ctk.CTkEntry(bf,placeholder_text="e.g. 64250.00",width=140);self.base_entry.pack(side="left",padx=4)
  self.base_entry.bind("<Return>",lambda e:self.set_base())
  ctk.CTkButton(bf,text="Set Base",width=90,command=self.set_base).pack(side="left",padx=4)
  ctk.CTkButton(bf,text="Clear",width=70,command=self.clear_base).pack(side="left",padx=4)
  ctk.CTkLabel(bf,textvariable=self.baselbl,text_color="#8b98a9").pack(side="left",padx=10)
  row=ctk.CTkFrame(self._content);row.pack(fill="x",padx=18)
  for title,var in [("FORECAST vs BASE",self.d),("MOMENTUM SCORE",self.prob),("TIME LEFT",self.clock)]:
   b=ctk.CTkFrame(row);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text=title,text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=var,font=("Arial",21,"bold")).pack(pady=5)
  row2=ctk.CTkFrame(self._content);row2.pack(fill="x",padx=18,pady=(5,0))
  b=ctk.CTkFrame(row2);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="BASE PRICE",text_color="#8b98a9").pack(pady=(8,0));self.baseval=ctk.CTkLabel(b,text="—",font=("Arial",18,"bold"));self.baseval.pack(pady=5)
  b=ctk.CTkFrame(row2);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="PROJECTED PRICE @15m",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.projp,font=("Arial",18,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row2);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="PROJECTED vs BASE",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.vsbase,font=("Arial",18,"bold")).pack(pady=5)
  row3=ctk.CTkFrame(self._content);row3.pack(fill="x",padx=18,pady=(5,0))
  b=ctk.CTkFrame(row3);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="HISTORICAL HIT RATE",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.hitlbl,font=("Arial",15,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row3);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="SELF-CALIBRATION",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.calibvar,font=("Arial",15,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row3);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="LAST QUARTER RESULT",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.lastq,font=("Arial",15,"bold")).pack(pady=5)
  mrow=ctk.CTkFrame(self._content);mrow.pack(fill="x",padx=18,pady=(5,0))
  self.api_exv=ctk.StringVar(value="COINBASE MARKET: —");self.api_diffv=ctk.StringVar(value="OCR − COINBASE: —")
  for var in (self.api_exv,self.api_diffv): ctk.CTkLabel(mrow,textvariable=var,font=("Arial",14,"bold")).pack(side="left",padx=10,pady=5)
  srow=ctk.CTkFrame(self._content);srow.pack(fill="x",padx=18,pady=(2,0))
  for title,var in [("OCR 50%",self.ocr_scorev),("COINBASE 50%",self.coin_scorev),("COMBINED",self.mix_scorev)]:
   ctk.CTkLabel(srow,text=title,text_color="#8b98a9").pack(side="left",padx=(10,2),pady=4);ctk.CTkLabel(srow,textvariable=var,font=("Arial",13,"bold")).pack(side="left",padx=(0,14),pady=4)
  ctk.CTkLabel(self._content,text="LIVE BRTI PRICE",text_color="#8b98a9").pack(pady=(10,0))
  self.graph=ctk.CTkCanvas(self._content,height=190,background="#10151c",highlightthickness=1,highlightbackground="#293241")
  self.graph.pack(fill="x",padx=18,pady=(2,4))
  self.diffgraph=ctk.CTkCanvas(self._content,height=120,background="#0d1218",highlightthickness=1,highlightbackground="#293241")
  self.diffgraph.pack(fill="x",padx=18,pady=(0,8))
  orow=ctk.CTkFrame(self._content);orow.pack(fill="x",padx=18,pady=(2,4))
  ctk.CTkLabel(orow,text="UP PRICE OVERRIDE:").pack(side="left",padx=(8,4))
  self.up_entry=ctk.CTkEntry(orow,textvariable=self.upoverride,placeholder_text="e.g. 0.62",width=120);self.up_entry.pack(side="left",padx=4)
  self.up_entry.bind("<Return>",lambda e:self.set_up_override())
  ctk.CTkButton(orow,text="SET OVERRIDE",width=120,command=self.set_up_override).pack(side="left",padx=4)
  ctk.CTkButton(orow,text="RESUME UP CAPTURE",width=145,command=self.resume_up).pack(side="left",padx=4)
  ctk.CTkLabel(orow,textvariable=self.up_status,text_color="#8b98a9").pack(side="left",padx=8)
  ctk.CTkLabel(self._content,text="UP contract price (DOWN = $1.00 − UP)",text_color="#8b98a9").pack(pady=(8,0))
  row4=ctk.CTkFrame(self._content);row4.pack(fill="x",padx=18,pady=(2,0))
  b=ctk.CTkFrame(row4);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="UP CONTRACT",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.upvar,font=("Arial",20,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row4);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="DOWN (1 − UP)",text_color="#8b98a9").pack(pady=(8,0));self.downval=ctk.CTkLabel(b,text="—",font=("Arial",20,"bold"));self.downval.pack(pady=5)
  b=ctk.CTkFrame(row4);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="MODEL PROB. OF UP",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.modelprob,font=("Arial",20,"bold")).pack(pady=5)
  row5=ctk.CTkFrame(self._content);row5.pack(fill="x",padx=18,pady=(5,0))
  b=ctk.CTkFrame(row5);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="SIGNAL",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.signal,font=("Arial",22,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row5);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="EDGE vs CONTRACT PRICE",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.edgevar,font=("Arial",18,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row5);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="CONFIDENCE",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.confvar,font=("Arial",18,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row5);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="SESSION",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.sessionlbl,font=("Arial",15,"bold")).pack(pady=5)
  b=ctk.CTkFrame(row5);b.pack(side="left",fill="both",expand=True,padx=5,pady=5);ctk.CTkLabel(b,text="ALL-TIME",text_color="#8b98a9").pack(pady=(8,0));ctk.CTkLabel(b,textvariable=self.alltimelbl,font=("Arial",15,"bold")).pack(pady=5)
  f=ctk.CTkFrame(self._content);f.pack(fill="x",padx=18,pady=10);self.l={}
  for i,(n,m) in enumerate([("1s",1000),("5s",5000),("15s",15000),("30s",30000),("1m",60000),("5m",300000),("15m",900000)]):
   b=ctk.CTkFrame(f);b.grid(row=i//4,column=i%4,padx=5,pady=5,sticky="nsew");ctk.CTkLabel(b,text=n,text_color="#8b98a9").pack(pady=(5,0));v=ctk.CTkLabel(b,text="—",font=("Arial",16,"bold"));v.pack(pady=5);self.l[m]=v
  for c in range(4):f.grid_columnconfigure(c,weight=1)
  self.info=ctk.CTkTextbox(self._content,height=190);self.info.pack(fill="both",expand=True,padx=18,pady=5)
  b=ctk.CTkFrame(self._content);b.pack(pady=7)
  ctk.CTkButton(b,text="Select BRTI + UP (F8)",command=self.select_all).pack(side="left",padx=5)
  ctk.CTkButton(b,text="BRTI (F5)",width=90,command=self.select_brti).pack(side="left",padx=5)
  ctk.CTkButton(b,text="UP (F6)",width=90,command=self.select_up).pack(side="left",padx=5)
  ctk.CTkButton(b,text="Resume UP (F7)",width=105,command=self.resume_up).pack(side="left",padx=5)
  ctk.CTkButton(b,text="Pause (F9)",command=self.pause).pack(side="left",padx=5)
  ctk.CTkButton(b,text="Quit (F10)",command=self.quit).pack(side="left",padx=5)
  ctk.CTkLabel(self._content,text="Prototype analytics only — not a validated probability or order system",text_color="#687487").pack(pady=6)
 def select_brti(self):
  self.withdraw()
  def done(r):E.set_region(r);self.deiconify()
  self.after(100,lambda:Selector(self,done,label="1) Drag a box around the BRTI price"))
 def select_up(self):
  self.withdraw()
  def done(r):UP.set_region(r);self.deiconify()
  self.after(100,lambda:Selector(self,done,label="2) Drag a box around the UP contract price"))
 def set_up_override(self):
  raw=self.up_entry.get().strip().replace("$","").replace(",","")
  try:
   v=float(raw)
   if v>1.5:v=v/100
   if not 0<=v<=1:raise ValueError
  except ValueError:
   self.up_status.set("invalid UP price");return
  self.up_override=v;self.up_capture_enabled=False;UP.paused=True
  self.up_status.set(f"OVERRIDE ACTIVE • UP ${v:.2f} • capture stopped")
 def resume_up(self):
  self.up_override=None;self.up_capture_enabled=True;UP.paused=False;self.upoverride.set("");self.up_status.set("UP capture active • select region if needed")
  if UP.region is None:self.select_up()
 def select_all(self):
  self.withdraw()
  def step2(r):
   UP.set_region(r);UP.paused=False;self.up_capture_enabled=True;self.up_override=None;self.up_status.set("UP capture active")
   self.deiconify()
  def step1(r):
   E.set_region(r);self.after(150,lambda:Selector(self,step2,label="2) Drag a box around the UP contract price"))
  self.after(100,lambda:Selector(self,step1,label="1) Drag a box around the BRTI price"))
 def pause(self):
  paused=not E.paused;E.paused=UP.paused=paused
  E.status="PAUSED" if paused else "LIVE • reading BRTI"
 def set_base(self):
  raw=self.base_entry.get().strip().replace(",","").replace("$","")
  try:
   v=float(raw)
   if v<=0:raise ValueError
  except ValueError:
   self.baselbl.set("invalid base price — enter a number");return
  self.base=v;self.base_ts=time.strftime("%H:%M:%S")
  self.baseval.configure(text="$"+format(v,",.2f"))
  self.baselbl.set(f"set at {self.base_ts}")
 def clear_base(self):
  self.base=None;self.base_ts=None;self.base_entry.delete(0,"end")
  self.baseval.configure(text="—");self.baselbl.set("not set")
 def score(self,x):
  # Multi-factor score: multi-horizon momentum, trend slope, persistence,
  # acceleration, breakout location and volatility-adjusted move. It is a
  # heuristic until the logged quarter outcomes are statistically calibrated.
  vals=x.get("vals",[]);s=0.0
  weights=[(1000,.04),(5000,.08),(15000,.10),(30000,.10),(60000,.16),(300000,.18),(900000,.18)]
  for m,w in weights:
   r=x["ret"].get(m)
   if r is not None:s+=max(-1,min(1,r/.20))*w
  if x.get("slope") is not None:s+=max(-1,min(1,x["slope"]/.06))*.10
  if x.get("acc") is not None:s+=max(-1,min(1,x["acc"]/.004))*.05
  if x.get("pers") is not None:s+=(x["pers"]-50)/50*.08
  if x.get("rsi") is not None:s+=((x["rsi"]-50)/50)*.07
  if x.get("range_pos") is not None:s+=(x["range_pos"]-.5)*.10
  # Penalize extreme volatility unless momentum is strong and aligned.
  vol=x.get("vol")
  if vol is not None and abs(s)<.25:s*=max(.55,min(1.0,.12/max(vol,.12)))
  return max(-1,min(1,s))
 def coinbase_score(self, ex):
  """Independent exchange-side directional score. It is deliberately
  weighted exactly 50% with the OCR/BRTI score when both streams are live."""
  ticks=ex.get("ticks",[]) if ex else []
  p=ex.get("price") if ex else None
  if p is None or len(ticks)<2:return None
  now=ex.get("last_ts") or int(time.time()*1000)
  def ret(ms):
   old=next((v for t,v,_ in reversed(ticks) if t<=now-ms),None)
   return None if old is None or old==0 else (p/old-1)*100
  s=0.0
  for ms,w,scale in [(1000,.08,.20),(5000,.12,.20),(15000,.15,.25),(30000,.15,.35),(60000,.18,.50),(300000,.16,1.00),(900000,.16,1.50)]:
   r=ret(ms)
   if r is not None:s+=max(-1,min(1,r/scale))*w
  bid=ex.get("bid");ask=ex.get("ask")
  if bid is not None and ask is not None and ask>bid:
   mid=(bid+ask)/2
   s+=max(-1,min(1,(p-mid)/max(ask-bid,0.01)))*.05
  return max(-1,min(1,s))

 def forecast(self,x,seconds_left,q):
  p=x["price"]
  if p is None:return None
  vol=max(x.get("vol") or .02,.005)
  # Use momentum bias plus trend; cap projected move to avoid runaway OCR-driven forecasts.
  trend=(x.get("slope") or 0)/100
  bias=(max(-1,min(1,q))*0.65 + max(-1,min(1,trend/.003))*0.20 + ((x.get("pers") or 50)-50)/50*0.15)*self.calib
  horizon_vol=vol*math.sqrt(max(seconds_left,1)/60)
  move_pct=max(-3,min(3,bias*horizon_vol))
  return p*(1+move_pct/100)
 def prob_up_pct(self,x,seconds_left,proj):
  p=x["price"]
  if p is None or self.base is None:return None
  vol=max(x.get("vol") or .02,.005)
  horizon_vol=vol*math.sqrt(max(seconds_left,1)/60)
  sd=max(p*horizon_vol/100,p*0.00005)
  # Directional mean combines projected endpoint and current distance from base.
  mean_price=proj
  z=(mean_price-self.base)/sd
  return max(0.5,min(99.5,50*(1+math.erf(z/math.sqrt(2)))))
 def update_all_time(self):
  try:
   rows=hist_load(100000)
   graded=[r for r in rows if r.get("correct") in ("True","False")]
   hits=sum(r.get("correct")=="True" for r in graded)
   self.alltimelbl.set(f"{hits}/{len(graded)} correct ({(hits/len(graded)*100):.1f}%)" if graded else "0 / 0 correct")
  except Exception:
   self.alltimelbl.set("—")

 def persist_session(self):
  # Rewrite/update the current session summary immediately after every graded quarter.
  rows=[]
  if SESSION_CSV.exists():
   with open(SESSION_CSV,newline="",encoding="utf-8") as f: rows=list(csv.DictReader(f))
  rows=[r for r in rows if r.get("session_id")!=self.session_id]
  rows.append({"session_id":self.session_id,"session_start":time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(self.session_start)),"session_end":time.strftime("%Y-%m-%d %H:%M:%S"),"quarters":self.session_total,"correct":self.session_correct,"incorrect":self.session_incorrect,"hit_rate":(self.session_correct/self.session_total if self.session_total else "")})
  with open(SESSION_CSV,"w",newline="",encoding="utf-8") as f:
   w=csv.DictWriter(f,fieldnames=SESSION_FIELDS);w.writeheader();w.writerows(rows)

 def recompute_calibration(self):
  rows=hist_load(500)
  graded=[r for r in rows if r.get("correct") in ("True","False")]
  self.hitn=len(graded)
  if self.hitn<MIN_GRADED_FOR_CALIB:
   self.hitrate=None;self.calib=1.0
   self.hitlbl.set(f"{self.hitn}/{MIN_GRADED_FOR_CALIB} graded quarters (need more data)")
   self.calibvar.set("×1.00 (inactive)")
   return
  hits=sum(1 for r in graded if r["correct"]=="True")
  hr=hits/self.hitn;self.hitrate=hr
  self.calib=max(0.75,min(CALIB_CAP,0.75+hr*0.75))
  self.hitlbl.set(f"{hr*100:.1f}% correct over {self.hitn} graded quarters")
  self.calibvar.set(f"×{self.calib:.2f}")
 def get_boundary_price(self, qstart):
  h=E.snap().get("history",[])
  if not h:return None
  # Prefer the closest valid BRTI read to the exact quarter boundary within 2 seconds.
  cand=[(abs(t-qstart*1000),t,v) for t,v in h if abs(t-qstart*1000)<=2000]
  return min(cand)[2] if cand else None
 def grade_quarter(self, close_price, qstart):
  if self.q_open is None or close_price is None:return
  base=self.q_open.get("base")
  if base is None:return
  actual="UP" if close_price>base else "DOWN" if close_price<base else "FLAT"
  called=self.q_open.get("direction")
  correct=called in ("UP","DOWN") and actual in ("UP","DOWN") and called==actual
  hist_append({"quarter_start_iso":time.strftime("%Y-%m-%dT%H:%M:%S",time.localtime(qstart)),"base":base,
               "price_open":self.q_open.get("price",""),"proj_open":self.q_open.get("proj","") or "",
               "score_open":self.q_open.get("score","") if self.q_open.get("score") is not None else "",
               "direction_open":called,"price_close":close_price,"direction_actual":actual,"correct":str(correct)})
  self.session_total+=1
  if correct:self.session_correct+=1;self.lastq.set(f"CORRECT • {called} • close ${close_price:,.2f}")
  else:self.session_incorrect+=1;self.lastq.set(f"INCORRECT • called {called} • was {actual}")
  # Persist the complete round immediately so a crash/restart cannot erase the session.
  append_session_round({
   "session_id":self.session_id,
   "quarter_start_iso":time.strftime("%Y-%m-%dT%H:%M:%S",time.localtime(qstart)),
   "quarter_end_iso":time.strftime("%Y-%m-%dT%H:%M:%S"),
   "base_price":base,
   "price_open":self.q_open.get("price",""),
   "price_close":close_price,
   "forecast_open":self.q_open.get("proj","") or "",
   "momentum_score":self.q_open.get("score","") if self.q_open.get("score") is not None else "",
   "model_prob_up":self.q_open.get("model_prob_up","") if self.q_open.get("model_prob_up") is not None else "",
   "up_price":self.q_open.get("up_price","") if self.q_open.get("up_price") is not None else "",
   "down_price":self.q_open.get("down_price","") if self.q_open.get("down_price") is not None else "",
   "signal":self.q_open.get("signal",""),
   "direction_called":called,
   "direction_actual":actual,
   "correct":str(correct),
   "edge_up":self.q_open.get("edge_up","") if self.q_open.get("edge_up") is not None else "",
   "edge_down":self.q_open.get("edge_down","") if self.q_open.get("edge_down") is not None else "",
   "confidence":self.q_open.get("confidence","") if self.q_open.get("confidence") is not None else ""
  })
  self.persist_session();self.update_all_time();self.recompute_calibration();self.sessionlbl.set(f"{self.session_correct}/{self.session_total} correct ({(self.session_correct/self.session_total*100):.1f}%)")
 def refresh(self):
  x=E.snap(); now=time.time(); left=900-(int(now)%900); self.clock.set(f"{left//60:02d}:{left%60:02d}")
  ex=COINBASE.snapshot()
  p=x["price"]
  if p is not None and ex.get("price") is not None:
   diff=p-ex["price"]; self.api_diffv.set(f"OCR − COINBASE: ${diff:+,.2f}")
  else: self.api_diffv.set("OCR − COINBASE: —")
  self.api_exv.set("COINBASE API: " + (f"${ex['price']:,.2f} • {ex['status']}" if ex.get('price') is not None else ex['status']))
  qs=int(now)-(int(now)%900)
  # Automatically make the exact quarter-boundary BRTI reading the new base price.
  if self.q_start is None:
   self.q_start=qs
   if self.base is None and p is not None:
    self.base=p;self.base_ts=time.strftime("%H:%M:%S",time.localtime(qs));self.baseval.configure(text="$"+format(p,",.2f"));self.baselbl.set(f"INITIAL BASE • {self.base_ts}")
  elif qs!=self.q_start:
   close=self.get_boundary_price(qs)
   if close is None:close=p
   self.grade_quarter(close,self.q_start)
   self.q_start=qs;self.q_open=None
   if close is not None:
    self.base=close;self.base_ts=time.strftime("%H:%M:%S",time.localtime(qs));self.baseval.configure(text="$"+format(close,",.2f"));self.baselbl.set(f"AUTO BASE • {self.base_ts}")
  if p is not None:
   self.p.set("$"+format(p,",.2f"))
   ocr_q=self.score(x)
   coin_q=self.coinbase_score(ex)
   q=(0.50*ocr_q + 0.50*coin_q) if coin_q is not None else ocr_q
   self.ocr_scorev.set(f"{ocr_q:+.2f}")
   self.coin_scorev.set("—" if coin_q is None else f"{coin_q:+.2f}")
   self.mix_scorev.set(f"{q:+.2f} • 50/50")
   proj=self.forecast(x,left,q)
  else:q=None;proj=None;self.p.set("—")
  self.projp.set("—" if proj is None else "$"+format(proj,",.2f"))
  if self.base is None:direction="WAITING FOR BASE"
  elif proj is None:direction="WAITING"
  else:direction="UP" if proj>self.base else "DOWN" if proj<self.base else "FLAT"
  self.d.set(direction)
  if self.base is not None and proj is not None:
   diff=proj-self.base;self.vsbase.set(f"{diff:+,.2f} ({diff/self.base*100:+.3f}%)")
  else:self.vsbase.set("—")
  # Up price: screen capture OR manual override. Down is always complement.
  ux=UP.snap();up_price=self.up_override if self.up_override is not None else ux["price"]
  if self.up_override is None:self.upvar.set("—" if up_price is None else f"${up_price:.2f}")
  else:self.upvar.set(f"${up_price:.2f} OVERRIDE")
  down_price=None if up_price is None else round(1-up_price,4);self.downval.configure(text="—" if down_price is None else f"${down_price:.2f}")
  mprob=self.prob_up_pct(x,left,proj) if p is not None and proj is not None and self.base is not None else None
  self.modelprob.set("—" if mprob is None else f"{mprob:.1f}%")
  # Contract-aware edge: UP price is an implied probability proxy; DOWN = 1-UP.
  if mprob is None or up_price is None:
   self.signal.set("WAITING FOR DATA");self.edgevar.set("—");self.confvar.set("—")
  else:
   edge_up=mprob/100-up_price;edge_down=(1-mprob/100)-down_price
   # Require both probability edge and directional confirmation.
   conf=min(99.0,50+abs(q or 0)*45)
   self.confvar.set(f"{conf:.0f}%")
   if edge_up>=MIN_EDGE and edge_up>=edge_down and direction=="UP":self.signal.set("BUY UP");self.edgevar.set(f"+${edge_up:.2f}")
   elif edge_down>=MIN_EDGE and edge_down>edge_up and direction=="DOWN":self.signal.set("BUY DOWN");self.edgevar.set(f"+${edge_down:.2f}")
   else:self.signal.set("NO EDGE / WAIT");self.edgevar.set(f"UP {edge_up:+.2f} • DOWN {edge_down:+.2f}")
  # Record graph points and draw live chart.
  if p is not None:
   self.graph_points.append((time.time(),p,ex.get("price")));self.draw_graph()
  if self.q_open is None and p is not None:
   # Snapshot every input used for the opening decision. This is the record that will be graded at quarter end.
   open_up=up_price
   open_down=down_price
   open_mprob=mprob
   open_edge_up=(mprob/100-open_up) if mprob is not None and open_up is not None else None
   open_edge_down=((1-mprob/100)-open_down) if mprob is not None and open_down is not None else None
   open_conf=(min(99.0,50+abs(q or 0)*45) if mprob is not None else None)
   self.q_open={"base":self.base,"price":p,"proj":proj,"score":q,"direction":direction,
                "model_prob_up":open_mprob,"up_price":open_up,"down_price":open_down,
                "signal":self.signal.get(),"edge_up":open_edge_up,"edge_down":open_edge_down,"confidence":open_conf}
  for m,v in x["ret"].items():self.l[m].configure(text="—" if v is None else f"{v:+.3f}%")
  self.info.delete("1.0","end");self.info.insert("end",f"OCR BRTI: {x['status']}   Coinbase: {ex['status']}\nReads: {x['reads']:,}   Valid: {x['valid']:,}   Rejected: {x['rejected']:,}\n50/50 inputs → OCR {self.ocr_scorev.get()}   Coinbase {self.coin_scorev.get()}   Combined {self.mix_scorev.get()}\n")
  self.info.insert("end",f"Trend slope: {x.get('slope') if x.get('slope') is not None else '—'} %/min   RSI-like: {x.get('rsi') if x.get('rsi') is not None else '—'}   Range position: {x.get('range_pos',.5):.2f}\n")
  self.info.insert("end",f"Velocity 5s: {x['vel'] if x['vel'] is not None else '—'} %/s   Acceleration: {x['acc'] if x['acc'] is not None else '—'}\n")
  self.info.insert("end",f"1m volatility: {x['vol'] if x['vol'] is not None else '—'}%   1m persistence: {x['pers'] if x['pers'] is not None else '—'}%\n")
  self.info.insert("end",f"Base: {format(self.base,',.2f') if self.base is not None else 'AUTO BASE PENDING'}   Current vs base: {(p-self.base) if p and self.base else 0:+,.2f}\n")
  self.info.insert("end",f"UP: {'OVERRIDE ' if self.up_override is not None else 'CAPTURE '} {('—' if up_price is None else format(up_price,'.2f'))}   DOWN: {'—' if down_price is None else format(down_price,'.2f')}\n")
  self.info.insert("end",f"Session accuracy: {self.session_correct}/{self.session_total} correct • {self.session_incorrect} incorrect\n")
  self.info.insert("end",f"All-time accuracy: {self.alltimelbl.get()}\n")
  self.info.insert("end","The engine now resets the base at each quarter-hour boundary using the closest captured BRTI reading to that boundary. It evaluates momentum across multiple horizons, trend slope, persistence, acceleration, RSI-like momentum, range position and volatility, then compares the resulting UP probability with the observed UP contract price; DOWN is always 1−UP. This remains a research prototype and must be validated on a large logged sample before real-money use.")
  self.after(250,self.refresh)
 def draw_graph(self):
  self.graph.delete("all");self.diffgraph.delete("all");pts=list(self.graph_points)
  valid=[z for z in pts if z[1] is not None or z[2] is not None]
  if len(valid)<2:return
  W=max(self.graph.winfo_width(),700);H=max(self.graph.winfo_height(),220);pad=34
  vals=[v for _,o,c in valid for v in (o,c) if v is not None]
  lo=min(vals);hi=max(vals);span=max(hi-lo,0.01)
  # grid and price labels
  for j in range(5):
   y=pad+(H-2*pad)*j/4;v=hi-(hi-lo)*j/4
   self.graph.create_line(pad,y,W-pad,y,fill="#202936")
   self.graph.create_text(4,y,anchor="w",text=f"${v:,.0f}",fill="#6f7d8c",font=("Arial",8))
  self.graph.create_text(10,8,anchor="nw",text=f"BRTI OCR  ${valid[-1][1]:,.2f}" if valid[-1][1] is not None else "BRTI OCR —",fill="#4aa3ff",font=("Arial",11,"bold"))
  self.graph.create_text(W-10,8,anchor="ne",text=f"Coinbase  ${valid[-1][2]:,.2f}" if valid[-1][2] is not None else "Coinbase —",fill="#ff9f43",font=("Arial",11,"bold"))
  def line(idx,color):
   xy=[]
   for i,(t,o,c) in enumerate(valid):
    v=(o,c)[idx]
    if v is None:
     if len(xy)>=4:self.graph.create_line(*xy,fill=color,width=2,smooth=True)
     xy=[];continue
    x=pad+(W-2*pad)*(i/(len(valid)-1));y=H-pad-(H-2*pad)*(v-lo)/span;xy.extend([x,y])
   if len(xy)>=4:self.graph.create_line(*xy,fill=color,width=2,smooth=True)
  line(0,"#4aa3ff");line(1,"#ff9f43")
  self.graph.create_text(W-10,H-8,anchor="se",text=f"{len(valid)} live points • ${lo:,.2f}–${hi:,.2f}",fill="#9aa7b5",font=("Arial",9))
  # Difference graph: BRTI OCR minus Coinbase. Zero is the center line.
  diffs=[(t,o-c) for t,o,c in valid if o is not None and c is not None]
  if len(diffs)<2:return
  DW=max(self.diffgraph.winfo_width(),700);DH=max(self.diffgraph.winfo_height(),120);dp=28
  dlo=min(v for _,v in diffs);dhi=max(v for _,v in diffs);dspan=max(dhi-dlo,0.01)
  zero=DH-dp-(DH-2*dp)*((0-dlo)/dspan)
  zero=max(dp,min(DH-dp,zero))
  self.diffgraph.create_line(dp,zero,DW-dp,zero,fill="#596575",dash=(4,3))
  self.diffgraph.create_text(5,zero,anchor="w",text="$0",fill="#7c8795",font=("Arial",8))
  self.diffgraph.create_text(10,7,anchor="nw",text=f"BRTI − Coinbase: {diffs[-1][1]:+.2f}",fill="#d7e0ea",font=("Arial",10,"bold"))
  xy=[]
  for i,(t,d) in enumerate(diffs):
   xx=dp+(DW-2*dp)*(i/(len(diffs)-1));yy=DH-dp-(DH-2*dp)*(d-dlo)/dspan;xy.extend([xx,yy])
  if len(xy)>=4:self.diffgraph.create_line(*xy,fill="#b86cff",width=2,smooth=True)
  self.diffgraph.create_text(DW-5,DH-5,anchor="se",text=f"range {dlo:+.2f} to {dhi:+.2f}",fill="#8d99a8",font=("Arial",8))
 def _scroll(self,units):
  try:
   c=self.scroll._parent_canvas
   c.yview_scroll(int(units),"units")
   c.update_idletasks()
  except Exception:pass
 def _on_mousewheel(self,event):
  if getattr(event,"delta",0):self._scroll(-3 if event.delta>0 else 3)
 def quit(self):self.persist_session();save_session(self.session_start,self.session_total,self.session_correct,self.session_incorrect,self.session_id);E.stop();UP.stop();COINBASE.stop();self.destroy()

if __name__=="__main__":
 ctk.set_appearance_mode("dark");ctk.set_default_color_theme("blue");App().mainloop()
