import json, os, threading, time
from collections import deque
from pathlib import Path

try:
    import websocket
except ImportError:
    websocket = None

BASE = Path(__file__).resolve().parent
DATA = BASE.parent / 'data'
DATA.mkdir(exist_ok=True)

class MarketFeed:
    """Generic live market feed container. Stores price/trade/order-book snapshots."""
    def __init__(self, name, maxlen=20000):
        self.name = name
        self.lock = threading.Lock()
        self.price = None
        self.bid = None
        self.ask = None
        self.last_size = None
        self.buy_volume = 0.0
        self.sell_volume = 0.0
        self.last_ts = 0
        self.status = 'DISCONNECTED'
        self.error = ''
        self.ticks = deque(maxlen=maxlen)
        self.running = False
        self.thread = None

    def snapshot(self):
        with self.lock:
            p = self.price
            return {
                'name': self.name, 'price': p, 'bid': self.bid, 'ask': self.ask,
                'last_size': self.last_size, 'buy_volume': self.buy_volume,
                'sell_volume': self.sell_volume, 'last_ts': self.last_ts,
                'status': self.status, 'error': self.error,
                'ticks': list(self.ticks)
            }

    def set(self, price, ts=None, bid=None, ask=None, size=None, side=None):
        if price is None:
            return
        now = int((ts or time.time()) * 1000)
        with self.lock:
            self.price = float(price)
            self.last_ts = now
            if bid is not None: self.bid = float(bid)
            if ask is not None: self.ask = float(ask)
            if size is not None: self.last_size = float(size)
            if side == 'buy' and size is not None: self.buy_volume += float(size)
            if side == 'sell' and size is not None: self.sell_volume += float(size)
            self.ticks.append((now, float(price), side or ''))
            self.status = 'LIVE'
            self.error = ''

class CoinbaseFeed(MarketFeed):
    """Public Coinbase BTC-USD market-price feed.

    Uses the public Advanced Trade WebSocket ticker when available, with a
    public Coinbase spot-price REST fallback so the engine can still receive
    live market data if a local WebSocket connection is blocked. No trading
    credentials are used.
    """
    WS_URL = 'wss://advanced-trade-ws.coinbase.com'
    REST_URL = 'https://api.coinbase.com/v2/prices/{product}/spot'
    def __init__(self, product='BTC-USD'):
        super().__init__('COINBASE BTC-USD')
        self.product = product

    def start(self):
        if self.running: return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def _rest_once(self):
        try:
            import urllib.request
            with urllib.request.urlopen(self.REST_URL.format(product=self.product), timeout=5) as r:
                obj=json.loads(r.read().decode('utf-8'))
            amount=(obj.get('data') or {}).get('amount')
            if amount is not None:
                self.set(float(amount))
                return True
        except Exception as exc:
            self.error=str(exc)
        return False

    def _ws_loop(self):
        if websocket is None:
            raise RuntimeError('websocket-client is not installed')
        ws=websocket.create_connection(self.WS_URL, timeout=10, enableTrace=False,
                                       origin='https://www.coinbase.com')
        ws.settimeout(10)
        ws.send(json.dumps({
            'type':'subscribe',
            'product_ids':[self.product],
            'channel':'ticker'
        }))
        while self.running:
            try:
                msg=ws.recv()
                if not msg: continue
                data=json.loads(msg)
                for ev in data.get('events',[]):
                    for t in ev.get('tickers',[]):
                        if t.get('product_id') != self.product: continue
                        p=t.get('price')
                        if p is not None:
                            self.set(p, bid=t.get('best_bid'), ask=t.get('best_ask'), size=t.get('last_size'))
            except Exception:
                raise
        try: ws.close()
        except Exception: pass

    def _loop(self):
        while self.running:
            try:
                self.status='CONNECTING WS'
                self._ws_loop()
                self.status='DISCONNECTED'
            except Exception as exc:
                self.error=str(exc)
                # REST fallback keeps a live price flowing if the WS is blocked.
                self.status='WS FAILED • REST FALLBACK'
                self._rest_once()
                for _ in range(5):
                    if not self.running: return
                    time.sleep(1)
            if self.running and self.last_ts and (time.time()*1000-self.last_ts)>3000:
                self._rest_once()

