import json, threading, time
from collections import deque
from pathlib import Path
from urllib.parse import urlencode
import urllib.request
import ssl

try:
    import websocket
except ImportError:
    websocket = None

BASE = Path(__file__).resolve().parent
DATA = BASE.parent / "data"
DATA.mkdir(exist_ok=True)

class MarketFeed:
    def __init__(self, name, maxlen=20000):
        self.name = name
        self.lock = threading.Lock()
        self.price = self.bid = self.ask = self.last_size = None
        self.buy_volume = self.sell_volume = 0.0
        self.last_ts = 0
        self.status = "DISCONNECTED"
        self.error = ""
        self.ticks = deque(maxlen=maxlen)
        self.running = False
        self.thread = None

    def snapshot(self):
        with self.lock:
            return {
                "name": self.name, "price": self.price, "bid": self.bid, "ask": self.ask,
                "last_size": self.last_size, "buy_volume": self.buy_volume,
                "sell_volume": self.sell_volume, "last_ts": self.last_ts,
                "status": self.status, "error": self.error,
                "ticks": list(self.ticks),
            }

    def set(self, price, ts=None, bid=None, ask=None, size=None, side=None):
        if price is None:
            return
        now = int((ts or time.time()) * 1000)
        with self.lock:
            self.price = float(price)
            self.last_ts = now
            if bid is not None:
                self.bid = float(bid)
            if ask is not None:
                self.ask = float(ask)
            if size is not None:
                self.last_size = float(size)
            if side == "buy" and size is not None:
                self.buy_volume += float(size)
            elif side == "sell" and size is not None:
                self.sell_volume += float(size)
            self.ticks.append((now, float(price), side or ""))
            self.status = "LIVE"
            self.error = ""

class CoinbaseFeed(MarketFeed):
    """Public Coinbase BTC-USD market feed; no trading credentials required."""
    WS_URL = "wss://advanced-trade-ws.coinbase.com"
    REST_URL = "https://api.coinbase.com/v2/prices/{product}/spot"

    def __init__(self, product="BTC-USD"):
        super().__init__("COINBASE BTC-USD")
        self.product = product

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def _rest_once(self):
        try:
            with urllib.request.urlopen(self.REST_URL.format(product=self.product), timeout=5) as r:
                obj = json.loads(r.read().decode("utf-8"))
            amount = (obj.get("data") or {}).get("amount")
            if amount is not None:
                self.set(float(amount))
                return True
        except Exception as exc:
            self.error = str(exc)
        return False

    def _ws_loop(self):
        if websocket is None:
            raise RuntimeError("websocket-client is not installed")
        ws = websocket.create_connection(
            self.WS_URL, timeout=10, enableTrace=False,
            origin="https://www.coinbase.com"
        )
        ws.settimeout(10)
        ws.send(json.dumps({
            "type": "subscribe",
            "product_ids": [self.product],
            "channel": "ticker",
        }))
        while self.running:
            msg = ws.recv()
            if not msg:
                continue
            data = json.loads(msg)
            for ev in data.get("events", []):
                for t in ev.get("tickers", []):
                    if t.get("product_id") != self.product:
                        continue
                    p = t.get("price")
                    if p is not None:
                        self.set(
                            p,
                            bid=t.get("best_bid"),
                            ask=t.get("best_ask"),
                            size=t.get("last_size"),
                        )
        try:
            ws.close()
        except Exception:
            pass

    def _loop(self):
        while self.running:
            try:
                self.status = "CONNECTING WS"
                self._ws_loop()
                self.status = "DISCONNECTED"
            except Exception as exc:
                self.error = str(exc)
                self.status = "WS FAILED • REST FALLBACK"
                self._rest_once()
                for _ in range(5):
                    if not self.running:
                        return
                    time.sleep(1)

class KalshiBTC15Feed(MarketFeed):
    """
    Public Kalshi BTC 15-minute market feed.

    The ticker is discovered automatically. The selector prefers currently-open
    Bitcoin markets whose metadata/ticker indicates a 15-minute product.
    It then polls the market and order book for the live YES quote.
    """
    DEFAULT_BASES = [
        "https://api.elections.kalshi.com/trade-api/v2",
        "https://api.kalshi.com/trade-api/v2",
    ]

    def __init__(self, poll_seconds=1.0, base_urls=None):
        super().__init__("KALSHI BTC 15M")
        self.poll_seconds = float(max(0.5, poll_seconds))
        self.base_urls = base_urls or self.DEFAULT_BASES
        self.base_url = self.base_urls[0]
        self.ticker = None
        self.event_ticker = None
        self.title = ""
        self.subtitle = ""
        self.open_time = None
        self.close_time = None
        self.result = None
        self.volume = None
        self.open_interest = None
        self.yes_bid = self.yes_ask = None
        self.no_bid = self.no_ask = None
        self.orderbook_yes = []
        self.orderbook_no = []
        self._last_discovery = 0
        self._discover_every = 20

    def snapshot(self):
        s = super().snapshot()
        with self.lock:
            s.update({
                "ticker": self.ticker,
                "event_ticker": self.event_ticker,
                "title": self.title,
                "subtitle": self.subtitle,
                "open_time": self.open_time,
                "close_time": self.close_time,
                "result": self.result,
                "volume": self.volume,
                "open_interest": self.open_interest,
                "yes_bid": self.yes_bid,
                "yes_ask": self.yes_ask,
                "no_bid": self.no_bid,
                "no_ask": self.no_ask,
                "orderbook_yes": list(self.orderbook_yes),
                "orderbook_no": list(self.orderbook_no),
            })
        return s

    @staticmethod
    def _get(obj, *paths, default=None):
        for path in paths:
            cur = obj
            ok = True
            for part in path.split("."):
                if isinstance(cur, dict) and part in cur:
                    cur = cur[part]
                else:
                    ok = False
                    break
            if ok and cur is not None:
                return cur
        return default

    @staticmethod
    def _parse_time(v):
        if v is None:
            return None
        if isinstance(v, (int, float)):
            # Kalshi uses epoch timestamps in some payloads and ISO strings in others.
            return float(v) if v > 1e9 else None
        s = str(v).replace("Z", "+00:00")
        try:
            from datetime import datetime
            return datetime.fromisoformat(s).timestamp()
        except Exception:
            return None

    def _request_json(self, path, params=None):
        last = None
        for base in self.base_urls:
            url = base.rstrip("/") + "/" + path.lstrip("/")
            if params:
                url += "?" + urlencode(params)
            try:
                req = urllib.request.Request(
                    url,
                    headers={"Accept": "application/json", "User-Agent": "kalshi-btc15-engine/1.0"},
                )
                with urllib.request.urlopen(req, timeout=8) as r:
                    data = json.loads(r.read().decode("utf-8"))
                self.base_url = base
                return data
            except Exception as exc:
                last = exc
        raise RuntimeError(str(last) if last else "Kalshi request failed")

    @staticmethod
    def _is_btc_15m(m):
        blob = " ".join(str(m.get(k, "")) for k in (
            "ticker", "event_ticker", "title", "subtitle", "category", "series_ticker"
        )).lower()
        if "bitcoin" not in blob and "btc" not in blob:
            return False
        return any(x in blob for x in ("15 minute", "15-minute", "15m", "15 min", "15min"))

    def _discover(self):
        data = self._request_json("markets", {"status": "open", "limit": 1000})
        markets = data.get("markets") if isinstance(data, dict) else None
        if not isinstance(markets, list):
            raise RuntimeError("Kalshi /markets response did not contain a markets list")

        now = time.time()
        candidates = []
        for m in markets:
            if not isinstance(m, dict) or not self._is_btc_15m(m):
                continue
            open_ts = self._parse_time(self._get(m, "open_time", "open_ts", "open_time_ms"))
            close_ts = self._parse_time(self._get(m, "close_time", "close_ts", "close_time_ms"))
            if open_ts and now + 2 < open_ts:
                continue
            if close_ts and close_ts <= now:
                continue
            ticker = self._get(m, "ticker")
            if not ticker:
                continue
            # Prefer the contract that closes soonest: it is the active 15-minute interval.
            distance = close_ts if close_ts else now + 10**9
            candidates.append((distance, ticker, m))
        if not candidates:
            raise RuntimeError("No active Kalshi BTC 15-minute market was found")
        candidates.sort(key=lambda x: x[0])
        return candidates[0][1], candidates[0][2]

    @staticmethod
    def _cents_to_prob(v):
        if v is None:
            return None
        try:
            x = float(v)
        except Exception:
            return None
        # Kalshi market payloads commonly expose *_price in cents.
        if x > 1.0:
            return max(0.0, min(1.0, x / 100.0))
        return max(0.0, min(1.0, x))

    def _load_market(self, ticker):
        data = self._request_json(f"markets/{ticker}")
        return data.get("market", data)

    def _load_orderbook(self, ticker):
        data = self._request_json(f"markets/{ticker}/orderbook")
        return data.get("orderbook", data)

    def _apply_market(self, m):
        with self.lock:
            self.ticker = self._get(m, "ticker")
            self.event_ticker = self._get(m, "event_ticker", "series_ticker")
            self.title = self._get(m, "title", default="") or ""
            self.subtitle = self._get(m, "subtitle", "sub_title", default="") or ""
            self.open_time = self._parse_time(self._get(m, "open_time", "open_ts", "open_time_ms"))
            self.close_time = self._parse_time(self._get(m, "close_time", "close_ts", "close_time_ms"))
            self.result = self._get(m, "result")
            self.volume = self._get(m, "volume")
            self.open_interest = self._get(m, "open_interest", "open_interest_contracts")
            yes_bid = self._get(m, "yes_bid", "yes_bid_price")
            yes_ask = self._get(m, "yes_ask", "yes_ask_price")
            last = self._get(m, "last_price", "yes_price", "last_trade_price")
            self.yes_bid = self._cents_to_prob(yes_bid)
            self.yes_ask = self._cents_to_prob(yes_ask)
            p = self._cents_to_prob(last)
            if p is None and self.yes_bid is not None and self.yes_ask is not None:
                p = (self.yes_bid + self.yes_ask) / 2.0

    def _apply_book(self, b):
        yes = b.get("yes") if isinstance(b, dict) else None
        no = b.get("no") if isinstance(b, dict) else None
        # Some payloads name them yes_bids / no_bids.
        yes = yes if yes is not None else (b.get("yes_bids") if isinstance(b, dict) else None)
        no = no if no is not None else (b.get("no_bids") if isinstance(b, dict) else None)
        if not isinstance(yes, list):
            yes = []
        if not isinstance(no, list):
            no = []
        def norm(rows):
            out = []
            for row in rows:
                if isinstance(row, (list, tuple)) and len(row) >= 2:
                    price = self._cents_to_prob(row[0])
                    try:
                        size = float(row[1])
                    except Exception:
                        size = None
                    if price is not None:
                        out.append((price, size))
                elif isinstance(row, dict):
                    price = self._cents_to_prob(self._get(row, "price", "yes_price", "no_price"))
                    size = self._get(row, "count", "quantity", "size")
                    try:
                        size = float(size) if size is not None else None
                    except Exception:
                        size = None
                    if price is not None:
                        out.append((price, size))
            return out
        y = norm(yes)
        n = norm(no)
        with self.lock:
            self.orderbook_yes = y
            self.orderbook_no = n
            if y:
                self.yes_bid = max(p for p, _ in y)
            if n:
                # A NO bid at x cents implies YES ask at 1-x.
                self.no_bid = max(p for p, _ in n)
                self.yes_ask = min(1.0 - p for p, _ in n)
            self.no_ask = (1.0 - self.yes_bid) if self.yes_bid is not None else None

    def _set_from_market(self):
        with self.lock:
            p = None
            if self.yes_bid is not None and self.yes_ask is not None:
                p = (self.yes_bid + self.yes_ask) / 2.0
            elif self.yes_ask is not None:
                p = self.yes_ask
            elif self.yes_bid is not None:
                p = self.yes_bid
        if p is not None:
            self.set(
                p,
                bid=self.yes_bid,
                ask=self.yes_ask,
            )

    def _loop(self):
        while self.running:
            try:
                now = time.time()
                if self.ticker is None or now - self._last_discovery >= self._discover_every:
                    ticker, metadata = self._discover()
                    if ticker != self.ticker:
                        self.ticker = ticker
                        self.status = f"DISCOVERED {ticker}"
                    self._last_discovery = now
                if not self.ticker:
                    time.sleep(self.poll_seconds)
                    continue
                market = self._load_market(self.ticker)
                self._apply_market(market)
                try:
                    self._apply_book(self._load_orderbook(self.ticker))
                except Exception:
                    # Market endpoint still provides useful last/bid/ask information.
                    pass
                self._set_from_market()
                with self.lock:
                    if self.close_time and time.time() >= self.close_time:
                        self.ticker = None
                        self.status = "ROUND ENDED • REDISCOVERING"
                    else:
                        self.status = f"LIVE • {self.ticker}"
            except Exception as exc:
                self.error = str(exc)
                self.status = "KALSHI ERROR • RETRYING"
            time.sleep(self.poll_seconds)

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def seconds_left(self):
        with self.lock:
            c = self.close_time
        return max(0.0, c - time.time()) if c else None
