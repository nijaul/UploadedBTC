import csv, json, math, time
from statistics import mean
from pathlib import Path
from collections import deque
import tkinter as tk
import customtkinter as ctk

from market_data import CoinbaseFeed, KalshiBTC15Feed

BASE = Path(__file__).resolve().parent
CFG = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
DATA = BASE.parent / "data"
DATA.mkdir(exist_ok=True)

CSV = DATA / "market_engine_ticks.csv"
HIST = DATA / "quarter_history.csv"
SESSION_CSV = DATA / "sessions.csv"
SESSION_ROUNDS_CSV = DATA / "session_rounds.csv"

HIST_FIELDS = [
    "quarter_start_iso", "base", "price_open", "proj_open", "score_open",
    "direction_open", "price_close", "direction_actual", "correct"
]
SESSION_FIELDS = ["session_id", "session_start", "session_end", "quarters", "correct", "incorrect", "hit_rate"]
ROUND_FIELDS = [
    "session_id", "quarter_start_iso", "quarter_end_iso", "base_price",
    "price_open", "price_close", "forecast_open", "momentum_score",
    "model_prob_up", "up_price", "down_price", "signal", "direction_called",
    "direction_actual", "correct", "edge_up", "edge_down", "confidence",
    "kalshi_ticker", "kalshi_yes", "kalshi_bid", "kalshi_ask"
]

MIN_GRADED_FOR_CALIB = CFG.get("min_graded_for_calibration", 20)
CALIB_CAP = CFG.get("calibration_cap", 1.5)
MIN_EDGE = CFG.get("min_edge_dollars", 0.03)

COINBASE = CoinbaseFeed(CFG.get("exchange_product", "BTC-USD"))
KALSHI = KalshiBTC15Feed(
    poll_seconds=CFG.get("kalshi", {}).get("poll_seconds", 1.0),
    base_urls=CFG.get("kalshi", {}).get("api_base_urls"),
)

def hist_append(row):
    new = not HIST.exists() or HIST.stat().st_size == 0
    with open(HIST, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=HIST_FIELDS)
        if new:
            w.writeheader()
        w.writerow(row)

def hist_load(n=500):
    if not HIST.exists():
        return []
    with open(HIST, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))[-n:]

def append_session_round(row):
    new = not SESSION_ROUNDS_CSV.exists() or SESSION_ROUNDS_CSV.stat().st_size == 0
    with open(SESSION_ROUNDS_CSV, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=ROUND_FIELDS)
        if new:
            w.writeheader()
        w.writerow(row)

def save_session(start, total, correct, incorrect, session_id):
    new = not SESSION_CSV.exists() or SESSION_CSV.stat().st_size == 0
    with open(SESSION_CSV, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=SESSION_FIELDS)
        if new:
            w.writeheader()
        w.writerow({
            "session_id": session_id,
            "session_start": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start)),
            "session_end": time.strftime("%Y-%m-%d %H:%M:%S"),
            "quarters": total, "correct": correct, "incorrect": incorrect,
            "hit_rate": (correct / total if total else "")
        })

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("BTC → Kalshi 15-Minute Engine")
        self.geometry("1040x900")
        self.minsize(860, 650)
        self.protocol("WM_DELETE_WINDOW", self.quit)

        self.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
        self.bind_all("<Button-4>", lambda e: self._scroll(-3), add="+")
        self.bind_all("<Button-5>", lambda e: self._scroll(3), add="+")
        self.bind("<F9>", lambda e: self.pause())
        self.bind("<F10>", lambda e: self.quit())

        self.base = None
        self.base_ts = None
        self.q_start = None
        self.q_open = None
        self.graph_points = deque(maxlen=900)

        self.session_start = time.time()
        self.session_id = time.strftime("%Y%m%d_%H%M%S", time.localtime(self.session_start))
        self.session_total = 0
        self.session_correct = 0
        self.session_incorrect = 0

        self.calib = 1.0
        self.hitrate = None
        self.hitn = 0
        self.paused = False

        self.p = ctk.StringVar(value="—")
        self.d = ctk.StringVar(value="WAITING")
        self.prob = ctk.StringVar(value="—")
        self.clock = ctk.StringVar(value="—")
        self.baselbl = ctk.StringVar(value="not set")
        self.baseval = ctk.StringVar(value="—")
        self.projp = ctk.StringVar(value="—")
        self.vsbase = ctk.StringVar(value="—")
        self.hitlbl = ctk.StringVar(value="no graded quarters yet")
        self.calibvar = ctk.StringVar(value="×1.00 (inactive)")
        self.lastq = ctk.StringVar(value="—")
        self.yesvar = ctk.StringVar(value="—")
        self.bidaskvar = ctk.StringVar(value="—")
        self.tickervar = ctk.StringVar(value="searching…")
        self.kstatusvar = ctk.StringVar(value="KALSHI: searching for BTC 15m market")
        self.signal = ctk.StringVar(value="WAITING FOR DATA")
        self.edgevar = ctk.StringVar(value="—")
        self.coin_scorev = ctk.StringVar(value="—")
        self.kalshi_scorev = ctk.StringVar(value="—")
        self.mix_scorev = ctk.StringVar(value="—")
        self.coin_status = ctk.StringVar(value="COINBASE: —")
        self.sessionlbl = ctk.StringVar(value="0 / 0 correct")
        self.alltimelbl = ctk.StringVar(value="0 / 0 correct")
        self.confvar = ctk.StringVar(value="—")

        COINBASE.start()
        KALSHI.start()

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=4, pady=4)
        self._content = self.scroll

        self.make()
        self.recompute_calibration()
        self.update_all_time()
        self.after(250, self.refresh)

    def make(self):
        ctk.CTkLabel(
            self._content, text="₿ BTC + KALSHI 15-MINUTE ENGINE",
            font=("Arial", 25, "bold")
        ).pack(pady=(16, 3))
        ctk.CTkLabel(
            self._content,
            text="Coinbase BTC spot and Kalshi BTC 15-minute contract are independent live inputs",
            text_color="#8b98a9"
        ).pack()
        ctk.CTkLabel(self._content, textvariable=self.p, font=("Arial", 45, "bold")).pack(pady=10)

        bf = ctk.CTkFrame(self._content); bf.pack(fill="x", padx=18, pady=(0, 8))
        ctk.CTkLabel(bf, text="Base BTC price:").pack(side="left", padx=(8, 4))
        self.base_entry = ctk.CTkEntry(bf, placeholder_text="e.g. 64250.00", width=140)
        self.base_entry.pack(side="left", padx=4)
        self.base_entry.bind("<Return>", lambda e: self.set_base())
        ctk.CTkButton(bf, text="Set Base", width=90, command=self.set_base).pack(side="left", padx=4)
        ctk.CTkButton(bf, text="Clear", width=70, command=self.clear_base).pack(side="left", padx=4)
        ctk.CTkLabel(bf, textvariable=self.baselbl, text_color="#8b98a9").pack(side="left", padx=10)

        row = ctk.CTkFrame(self._content); row.pack(fill="x", padx=18)
        for title, var in [
            ("FORECAST vs BASE", self.d),
            ("MODEL P(UP)", self.prob),
            ("TIME LEFT", self.clock),
        ]:
            b = ctk.CTkFrame(row); b.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            ctk.CTkLabel(b, text=title, text_color="#8b98a9").pack(pady=(8,0))
            ctk.CTkLabel(b, textvariable=var, font=("Arial", 21, "bold")).pack(pady=5)

        row2 = ctk.CTkFrame(self._content); row2.pack(fill="x", padx=18, pady=(5,0))
        for title, var in [
            ("BASE PRICE", self.baseval),
            ("PROJECTED PRICE @15m", self.projp),
            ("PROJECTED vs BASE", self.vsbase),
        ]:
            b = ctk.CTkFrame(row2); b.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            ctk.CTkLabel(b, text=title, text_color="#8b98a9").pack(pady=(8,0))
            ctk.CTkLabel(b, textvariable=var, font=("Arial", 18, "bold")).pack(pady=5)

        row3 = ctk.CTkFrame(self._content); row3.pack(fill="x", padx=18, pady=(5,0))
        for title, var in [
            ("KALSHI TICKER", self.tickervar),
            ("KALSHI YES", self.yesvar),
            ("YES BID / ASK", self.bidaskvar),
        ]:
            b = ctk.CTkFrame(row3); b.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            ctk.CTkLabel(b, text=title, text_color="#8b98a9").pack(pady=(8,0))
            ctk.CTkLabel(b, textvariable=var, font=("Arial", 15, "bold")).pack(pady=5)

        ctk.CTkLabel(self._content, textvariable=self.kstatusvar, text_color="#8b98a9").pack(pady=(2,0))
        ctk.CTkLabel(self._content, text="LIVE MARKET GRAPH — left axis = BTC/USD, right axis = Kalshi YES probability", text_color="#8b98a9").pack(pady=(10,0))
        self.graph = ctk.CTkCanvas(
            self._content, height=280, background="#10151c",
            highlightthickness=1, highlightbackground="#293241"
        )
        self.graph.pack(fill="x", padx=18, pady=(2,8))

        srow = ctk.CTkFrame(self._content); srow.pack(fill="x", padx=18, pady=(2,0))
        for title, var in [
            ("COINBASE SCORE 50%", self.coin_scorev),
            ("KALSHI SCORE 50%", self.kalshi_scorev),
            ("COMBINED", self.mix_scorev),
        ]:
            ctk.CTkLabel(srow, text=title, text_color="#8b98a9").pack(side="left", padx=(10,2), pady=4)
            ctk.CTkLabel(srow, textvariable=var, font=("Arial", 13, "bold")).pack(side="left", padx=(0,14), pady=4)

        row4 = ctk.CTkFrame(self._content); row4.pack(fill="x", padx=18, pady=(5,0))
        for title, var in [("SIGNAL", self.signal), ("EDGE", self.edgevar), ("CONFIDENCE", self.confvar)]:
            b = ctk.CTkFrame(row4); b.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            ctk.CTkLabel(b, text=title, text_color="#8b98a9").pack(pady=(8,0))
            ctk.CTkLabel(b, textvariable=var, font=("Arial", 18, "bold")).pack(pady=5)

        r5 = ctk.CTkFrame(self._content); r5.pack(fill="x", padx=18, pady=(5,0))
        for title, var in [("HISTORICAL HIT RATE", self.hitlbl), ("SELF-CALIBRATION", self.calibvar), ("LAST QUARTER", self.lastq)]:
            b = ctk.CTkFrame(r5); b.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            ctk.CTkLabel(b, text=title, text_color="#8b98a9").pack(pady=(8,0))
            ctk.CTkLabel(b, textvariable=var, font=("Arial", 14, "bold")).pack(pady=5)

        self.info = ctk.CTkTextbox(self._content, height=220)
        self.info.pack(fill="both", expand=True, padx=18, pady=5)

        b = ctk.CTkFrame(self._content); b.pack(pady=7)
        ctk.CTkButton(b, text="Pause / Resume (F9)", command=self.pause).pack(side="left", padx=5)
        ctk.CTkButton(b, text="Quit (F10)", command=self.quit).pack(side="left", padx=5)
        ctk.CTkLabel(
            self._content,
            text="Prototype analytics only — Kalshi and Coinbase feeds are independent market data sources",
            text_color="#687487"
        ).pack(pady=6)

    def set_base(self):
        raw = self.base_entry.get().strip().replace(",","").replace("$","")
        try:
            v = float(raw)
            if v <= 0: raise ValueError
        except ValueError:
            self.baselbl.set("invalid base price — enter a number")
            return
        self.base = v
        self.base_ts = time.strftime("%H:%M:%S")
        self.baseval.set("$" + format(v, ",.2f"))
        self.baselbl.set(f"set at {self.base_ts}")

    def clear_base(self):
        self.base = self.base_ts = None
        self.base_entry.delete(0, "end")
        self.baseval.set("—")
        self.baselbl.set("not set")

    def coinbase_score(self, ex):
        ticks = ex.get("ticks", [])
        p = ex.get("price")
        if p is None or len(ticks) < 2:
            return None
        now = ex.get("last_ts") or int(time.time()*1000)
        def ret(ms):
            old = next((v for t,v,_ in reversed(ticks) if t <= now-ms), None)
            return None if old is None or old == 0 else (p/old - 1) * 100
        s = 0.0
        for ms,w,scale in [(1000,.08,.20),(5000,.12,.20),(15000,.15,.25),(30000,.15,.35),(60000,.18,.50),(300000,.16,1.0),(900000,.16,1.5)]:
            r=ret(ms)
            if r is not None: s += max(-1,min(1,r/scale))*w
        return max(-1,min(1,s))

    def kalshi_score(self, k):
        ticks = k.get("ticks", [])
        p = k.get("price")
        if p is None:
            return None
        s = max(-1, min(1, (p - 0.50) * 2.0)) * 0.75
        now = k.get("last_ts") or int(time.time()*1000)
        if len(ticks) >= 2:
            def ret(ms):
                old = next((v for t,v,_ in reversed(ticks) if t <= now-ms), None)
                return None if old is None else p-old
            for ms,w,scale in [(5000,.08,.05),(15000,.10,.08),(30000,.12,.10),(60000,.15,.12),(300000,.15,.15),(900000,.15,.20)]:
                r=ret(ms)
                if r is not None: s += max(-1,min(1,r/scale))*w
        bid=k.get("yes_bid"); ask=k.get("yes_ask")
        if bid is not None and ask is not None and ask >= bid:
            s += max(-1,min(1, (p-(bid+ask)/2)/max(ask-bid,.01))) * .05
        return max(-1,min(1,s))

    def forecast(self, x, seconds_left, q):
        p=x["price"]
        if p is None: return None
        vol=max(x.get("vol") or .02,.005)
        horizon_vol=vol*math.sqrt(max(seconds_left,1)/60)
        trend=(x.get("slope") or 0)/100
        bias=(max(-1,min(1,q))*.65 + max(-1,min(1,trend/.003))*.20)*self.calib
        move_pct=max(-3,min(3,bias*horizon_vol))
        return p*(1+move_pct/100)

    def btc_features(self, ex):
        p=ex.get("price"); ticks=ex.get("ticks",[])
        now=ex.get("last_ts") or int(time.time()*1000)
        if p is None: return {"price":None,"history":[],"ret":{},"vol":None,"slope":None}
        def ret(ms):
            old=next((v for t,v,_ in reversed(ticks) if t<=now-ms),None)
            return None if old is None or old==0 else (p/old-1)*100
        rr=[]
        recent=[v for t,v,_ in ticks if t>=now-60000]
        for i in range(1,len(recent)):
            if recent[i-1]: rr.append(recent[i]/recent[i-1]-1)
        vol=math.sqrt(sum(x*x for x in rr)/len(rr))*100 if rr else None
        slope=None
        pts=[(t,v) for t,v,_ in ticks if t>=now-60000]
        if len(pts)>=8:
            t0=pts[0][0]; xs=[(t-t0)/60000 for t,v in pts]; ys=[v for t,v in pts]
            mx=mean(xs); my=mean(ys); den=sum((a-mx)**2 for a in xs)
            slope=(sum((a-mx)*(b-my) for a,b in zip(xs,ys))/den/my*100) if den and my else None
        return {
            "price":p, "history":[(t,v) for t,v,_ in ticks],
            "ret":{m:ret(m) for m in [1000,5000,15000,30000,60000,300000,900000]},
            "vol":vol, "slope":slope
        }

    def prob_up_pct(self, x, seconds_left, proj):
        if x["price"] is None or self.base is None or proj is None: return None
        vol=max(x.get("vol") or .02,.005)
        sd=max(x["price"]*vol*math.sqrt(max(seconds_left,1)/60)/100,x["price"]*.00005)
        z=(proj-self.base)/sd
        return max(0.5,min(99.5,50*(1+math.erf(z/math.sqrt(2)))))

    def get_boundary_price(self, qstart):
        ex=COINBASE.snapshot()
        ticks=ex.get("ticks",[])
        cand=[(abs(t-qstart*1000),t,v) for t,v,_ in ticks if abs(t-qstart*1000)<=3000]
        return min(cand)[2] if cand else ex.get("price")

    def grade_quarter(self, close_price, qstart):
        if self.q_open is None or close_price is None or self.q_open.get("base") is None: return
        base=self.q_open["base"]
        actual="UP" if close_price>base else "DOWN" if close_price<base else "FLAT"
        called=self.q_open.get("direction")
        correct=called in ("UP","DOWN") and actual in ("UP","DOWN") and called==actual
        hist_append({
            "quarter_start_iso":time.strftime("%Y-%m-%dT%H:%M:%S",time.localtime(qstart)),
            "base":base,"price_open":self.q_open.get("price",""),"proj_open":self.q_open.get("proj","") or "",
            "score_open":self.q_open.get("score",""),"direction_open":called,
            "price_close":close_price,"direction_actual":actual,"correct":str(correct)
        })
        self.session_total += 1
        if correct:
            self.session_correct += 1
            self.lastq.set(f"CORRECT • {called} • close ${close_price:,.2f}")
        else:
            self.session_incorrect += 1
            self.lastq.set(f"INCORRECT • called {called} • was {actual}")
        k=self.q_open.get("kalshi",{})
        append_session_round({
            "session_id":self.session_id,
            "quarter_start_iso":time.strftime("%Y-%m-%dT%H:%M:%S",time.localtime(qstart)),
            "quarter_end_iso":time.strftime("%Y-%m-%dT%H:%M:%S"),
            "base_price":base,"price_open":self.q_open.get("price",""),"price_close":close_price,
            "forecast_open":self.q_open.get("proj","") or "",
            "momentum_score":self.q_open.get("score",""),
            "model_prob_up":self.q_open.get("model_prob_up",""),
            "up_price":self.q_open.get("up_price",""),"down_price":self.q_open.get("down_price",""),
            "signal":self.q_open.get("signal",""),"direction_called":called,
            "direction_actual":actual,"correct":str(correct),
            "edge_up":self.q_open.get("edge_up",""),"edge_down":self.q_open.get("edge_down",""),
            "confidence":self.q_open.get("confidence",""),
            "kalshi_ticker":k.get("ticker",""),"kalshi_yes":k.get("yes",""),
            "kalshi_bid":k.get("bid",""),"kalshi_ask":k.get("ask","")
        })
        self.persist_session(); self.update_all_time(); self.recompute_calibration()
        self.sessionlbl.set(f"{self.session_correct}/{self.session_total} correct ({self.session_correct/self.session_total*100:.1f}%)")

    def persist_session(self):
        rows=[]
        if SESSION_CSV.exists():
            with open(SESSION_CSV,newline="",encoding="utf-8") as f: rows=list(csv.DictReader(f))
        rows=[r for r in rows if r.get("session_id")!=self.session_id]
        rows.append({
            "session_id":self.session_id,
            "session_start":time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(self.session_start)),
            "session_end":time.strftime("%Y-%m-%d %H:%M:%S"),
            "quarters":self.session_total,"correct":self.session_correct,"incorrect":self.session_incorrect,
            "hit_rate":(self.session_correct/self.session_total if self.session_total else "")
        })
        with open(SESSION_CSV,"w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=SESSION_FIELDS); w.writeheader(); w.writerows(rows)

    def recompute_calibration(self):
        rows=hist_load(500)
        graded=[r for r in rows if r.get("correct") in ("True","False")]
        self.hitn=len(graded)
        if self.hitn<MIN_GRADED_FOR_CALIB:
            self.hitrate=None;self.calib=1.0
            self.hitlbl.set(f"{self.hitn}/{MIN_GRADED_FOR_CALIB} graded quarters (need more data)")
            self.calibvar.set("×1.00 (inactive)")
            return
        hits=sum(1 for r in graded if r["correct"]=="True")
        hr=hits/self.hitn;self.hitrate=hr
        self.calib=max(.75,min(CALIB_CAP,.75+hr*.75))
        self.hitlbl.set(f"{hr*100:.1f}% correct over {self.hitn} graded quarters")
        self.calibvar.set(f"×{self.calib:.2f}")

    def update_all_time(self):
        rows=hist_load(100000)
        graded=[r for r in rows if r.get("correct") in ("True","False")]
        hits=sum(r.get("correct")=="True" for r in graded)
        self.alltimelbl.set(f"{hits}/{len(graded)} correct ({hits/len(graded)*100:.1f}%)" if graded else "0 / 0 correct")

    def refresh(self):
        if self.paused:
            self.after(250,self.refresh)
            return
        now=time.time()
        ex=COINBASE.snapshot()
        k=KALSHI.snapshot()

        left=k.get("close_time")
        if left:
            seconds_left=max(0,left-now)
            self.clock.set(f"{int(seconds_left)//60:02d}:{int(seconds_left)%60:02d}")
        else:
            self.clock.set("searching…")

        p=ex.get("price")
        self.coin_status.set(
            "COINBASE: " + (f"${p:,.2f} • {ex.get('status')}" if p is not None else ex.get("status","—"))
        )
        ticker=k.get("ticker")
        self.tickervar.set(ticker or "searching…")
        kp=k.get("price")
        self.yesvar.set("—" if kp is None else f"{kp*100:.1f}¢")
        self.bidaskvar.set(
            "—" if k.get("yes_bid") is None and k.get("yes_ask") is None
            else f"{(k.get('yes_bid')*100 if k.get('yes_bid') is not None else float('nan')):.1f}¢ / {(k.get('yes_ask')*100 if k.get('yes_ask') is not None else float('nan')):.1f}¢"
        )
        self.kstatusvar.set(f"KALSHI: {k.get('status','—')}")

        qs=int(now)-(int(now)%900)
        if self.q_start is None:
            self.q_start=qs
            if self.base is None and p is not None:
                self.base=p; self.baseval.set("$"+format(p,",.2f")); self.baselbl.set(f"INITIAL BASE • {time.strftime('%H:%M:%S',time.localtime(qs))}")
        elif qs != self.q_start:
            close=self.get_boundary_price(qs) or p
            self.grade_quarter(close,self.q_start)
            self.q_start=qs; self.q_open=None
            if close is not None:
                self.base=close
                self.baseval.set("$"+format(close,",.2f"))
                self.baselbl.set(f"AUTO BASE • {time.strftime('%H:%M:%S',time.localtime(qs))}")

        if p is not None:
            self.p.set("$"+format(p,",.2f"))
            x=self.btc_features(ex)
            cscore=self.coinbase_score(ex)
            kscore=self.kalshi_score(k)
            q=(0.50*cscore+0.50*kscore) if cscore is not None and kscore is not None else (cscore if kscore is None else kscore)
            self.coin_scorev.set("—" if cscore is None else f"{cscore:+.2f}")
            self.kalshi_scorev.set("—" if kscore is None else f"{kscore:+.2f}")
            self.mix_scorev.set("—" if q is None else f"{q:+.2f} • 50/50")

            seconds_left=max(1,(k.get("close_time") or (now+900))-now)
            proj=self.forecast(x,seconds_left,q or 0)
            mprob=self.prob_up_pct(x,seconds_left,proj)
            self.prob.set("—" if mprob is None else f"{mprob:.1f}%")
        else:
            x={};q=None;proj=None;mprob=None;self.p.set("—")

        self.projp.set("—" if proj is None else "$"+format(proj,",.2f"))
        if self.base is None: direction="WAITING FOR BASE"
        elif proj is None: direction="WAITING"
        else: direction="UP" if proj>self.base else "DOWN" if proj<self.base else "FLAT"
        self.d.set(direction)

        if self.base is not None and proj is not None:
            diff=proj-self.base
            self.vsbase.set(f"{diff:+,.2f} ({diff/self.base*100:+.3f}%)")
        else:self.vsbase.set("—")

        up_price=kp
        down_price=None if kp is None else 1-kp
        if mprob is None or up_price is None:
            self.signal.set("WAITING FOR DATA");self.edgevar.set("—");self.confvar.set("—")
        else:
            edge_up=mprob/100-up_price
            edge_down=(1-mprob/100)-down_price
            conf=min(99.0,50+abs(q or 0)*45)
            self.confvar.set(f"{conf:.0f}%")
            if edge_up>=MIN_EDGE and edge_up>=edge_down and direction=="UP":
                self.signal.set("BUY UP");self.edgevar.set(f"+${edge_up:.2f}")
            elif edge_down>=MIN_EDGE and edge_down>edge_up and direction=="DOWN":
                self.signal.set("BUY DOWN");self.edgevar.set(f"+${edge_down:.2f}")
            else:
                self.signal.set("NO EDGE / WAIT");self.edgevar.set(f"UP {edge_up:+.2f} • DOWN {edge_down:+.2f}")

        if p is not None or kp is not None:
            self.graph_points.append((now,p,kp))
            self.draw_graph()

        if self.q_open is None and p is not None and q is not None:
            self.q_open={
                "base":self.base,"price":p,"proj":proj,"score":q,"direction":direction,
                "model_prob_up":mprob,"up_price":up_price,"down_price":down_price,
                "signal":self.signal.get(),
                "edge_up":((mprob/100-up_price) if mprob is not None and up_price is not None else None),
                "edge_down":(((1-mprob/100)-down_price) if mprob is not None and down_price is not None else None),
                "confidence":(min(99.0,50+abs(q)*45) if mprob is not None else None),
                "kalshi":{"ticker":ticker,"yes":kp,"bid":k.get("yes_bid"),"ask":k.get("yes_ask")}
            }

        ret=x.get("ret",{})
        for m, varname in [(1000,"1s"),(5000,"5s"),(15000,"15s"),(30000,"30s"),(60000,"1m"),(300000,"5m"),(900000,"15m")]:
            if not hasattr(self,"retvars"): continue
            self.retvars[varname].set("—" if ret.get(m) is None else f"{ret[m]:+.3f}%")

        self.info.delete("1.0","end")
        self.info.insert("end",f"{self.coin_status.get()}\n")
        self.info.insert("end",f"{self.kstatusvar.get()}  •  ticker={ticker or '—'}\n")
        self.info.insert("end",f"Kalshi YES={kp*100:.1f}¢" if kp is not None else "Kalshi YES=—")
        self.info.insert("end",f"  BID={k.get('yes_bid')*100:.1f}¢" if k.get('yes_bid') is not None else "  BID=—")
        self.info.insert("end",f"  ASK={k.get('yes_ask')*100:.1f}¢\n" if k.get('yes_ask') is not None else "  ASK=—\n")
        self.info.insert("end",f"Kalshi close={time.strftime('%H:%M:%S',time.localtime(k['close_time'])) if k.get('close_time') else '—'}  volume={k.get('volume','—')}  open_interest={k.get('open_interest','—')}\n")
        self.info.insert("end",f"Coinbase score={self.coin_scorev.get()}  Kalshi score={self.kalshi_scorev.get()}  Combined={self.mix_scorev.get()}\n")
        self.info.insert("end",f"Base BTC={self.base if self.base is not None else '—'}  Current vs base={(p-self.base):+,.2f}\n" if p is not None and self.base else "Base BTC=—\n")
        self.info.insert("end","Graph: Coinbase BTC/USD and Kalshi YES are plotted as independent live series with independent scales. Kalshi is a contract probability (¢), not a BTC spot-price substitute.\n")
        self.info.insert("end",f"Session accuracy: {self.session_correct}/{self.session_total} correct • {self.session_incorrect} incorrect\n")
        self.info.insert("end",f"All-time accuracy: {self.alltimelbl.get()}\n")
        self.after(250,self.refresh)

    def draw_graph(self):
        self.graph.delete("all")
        pts=list(self.graph_points)
        if len(pts)<2:return
        W=max(self.graph.winfo_width(),800);H=max(self.graph.winfo_height(),280);pad=42
        btc=[v for _,v,_ in pts if v is not None]
        kal=[v for _,_,v in pts if v is not None]
        # left axis BTC
        if btc:
            blo,bhi=min(btc),max(btc); bspan=max(bhi-blo,1.0)
        else: blo,bhi,bspan=0,1,1
        # right axis probability
        klo,khi=(min(kal),max(kal)) if kal else (0,1)
        kspan=max(khi-klo,.02)

        for j in range(5):
            y=pad+(H-2*pad)*j/4
            self.graph.create_line(pad,y,W-pad,y,fill="#202936")
            bv=bhi-(bhi-blo)*j/4
            self.graph.create_text(4,y,text=f"${bv:,.0f}",anchor="w",fill="#6f7d8c",font=("Arial",8))
            kv=khi-(khi-klo)*j/4
            self.graph.create_text(W-4,y,text=f"{kv*100:.0f}¢",anchor="e",fill="#6f7d8c",font=("Arial",8))
        self.graph.create_text(48,8,text=f"Coinbase  ${btc[-1]:,.2f}" if btc else "Coinbase —",anchor="nw",fill="#4aa3ff",font=("Arial",11,"bold"))
        self.graph.create_text(W-48,8,text=f"Kalshi YES  {kal[-1]*100:.1f}¢" if kal else "Kalshi —",anchor="ne",fill="#ff9f43",font=("Arial",11,"bold"))

        def draw_series(index, lo, span, color):
            xy=[]
            for i,(t,b,k) in enumerate(pts):
                v=(b,k)[index]
                if v is None:
                    if len(xy)>=4:self.graph.create_line(*xy,fill=color,width=2,smooth=True)
                    xy=[];continue
                xx=pad+(W-2*pad)*i/(len(pts)-1)
                yy=H-pad-(H-2*pad)*(v-lo)/span
                xy.extend([xx,yy])
            if len(xy)>=4:self.graph.create_line(*xy,fill=color,width=2,smooth=True)
        if btc: draw_series(0,blo,bspan,"#4aa3ff")
        if kal: draw_series(1,klo,kspan,"#ff9f43")
        self.graph.create_text(8,H-8,text="BTC/USD",anchor="sw",fill="#4aa3ff",font=("Arial",9))
        self.graph.create_text(W-8,H-8,text="KALSHI YES",anchor="se",fill="#ff9f43",font=("Arial",9))

    def pause(self):
        self.paused=not self.paused

    def _scroll(self,units):
        try:
            c=self.scroll._parent_canvas
            c.yview_scroll(int(units),"units")
            c.update_idletasks()
        except Exception: pass

    def _on_mousewheel(self,event):
        if getattr(event,"delta",0):
            self._scroll(-3 if event.delta>0 else 3)

    def quit(self):
        try:self.persist_session();save_session(self.session_start,self.session_total,self.session_correct,self.session_incorrect,self.session_id)
        except Exception:pass
        COINBASE.stop();KALSHI.stop();self.destroy()

if __name__=="__main__":
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    App().mainloop()
