# BTC + Kalshi BTC 15-Minute Engine

This build removes the BRTI/OCR pipeline completely.

## Two independent live market lines

The main graph now draws **both sources live at the same time**:

- **Coinbase BTC-USD** = BTC spot price, with its own left-side dollar scale.
- **Kalshi BTC 15-minute YES contract** = contract probability/price, with its own right-side cents scale.

They are intentionally not forced onto a single numeric scale because a Kalshi YES contract price (0–100¢) is not a BTC spot price.

## Automatic Kalshi ticker discovery

You do not enter a ticker in `config.json`.

At startup the program queries Kalshi's public markets endpoint, filters for currently open Bitcoin markets whose metadata indicates a 15-minute product, and chooses the active interval closing soonest. When the interval ends, the feed automatically rediscovers the next BTC 15-minute market.

## Model inputs

Coinbase and Kalshi remain separate inputs:

- Coinbase supplies the BTC spot-price history and the exchange-side momentum score.
- Kalshi supplies its own YES price, bid/ask, order-book information, timing, volume, open interest, and a contract-side score.
- When both are live, the combined directional score is 50% Coinbase + 50% Kalshi.
- The forecast itself remains a BTC-price forecast anchored to the Coinbase spot stream.
- The Kalshi contract price is used as the prediction-market probability/edge input, not as a substitute BTC spot price.

## Public APIs

No trading credentials are required. The app uses public Coinbase market data and public Kalshi market/order-book endpoints.

Note: live API schemas can change. This adapter supports common Kalshi market/order-book field names and retries across two public base URLs, but the environment used to produce this package did not have live web verification enabled.

## Logs

Data are saved under `data/`:
- `market_engine_ticks.csv`
- `quarter_history.csv`
- `session_rounds.csv`
- `sessions.csv`

This is a research/prototype analytics engine, not an order-execution system.
